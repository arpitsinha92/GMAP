using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Dal
{
    public class Menus:Base
    {       
        /// <summary>
        /// Constructor del menu.
        /// </summary>
        /// <param name="mantMensajes">Mensajes de error.</param>
        public Menus(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }

        /// <summary>
        /// M�todo para obtener el menu que se debe cargar seg�n el perfil.
        /// </summary>
        /// <param name="strPerfil">Perfil del usuario logado.</param>
        /// <returns>Dataset con los datos del men�.</returns>
        public DataSet cargarMenu(string strPerfil)
        {
            DataSet menu = new DataSet();

            try
            {
                // Accedemos a la base de datos
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader menuRecuperado = db.ExecuteReader(Constantes.OBTENER_MENU, strPerfil);
                // Cargamos los datos en la tabla
                DataTable menuTabla = new DataTable();
                menuTabla.Load(menuRecuperado);

                menu.Tables.Add(menuTabla);
                
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            // Devolvemos el men�
            return menu;
        }

        /// <summary>
        /// Recuperamos las funciones que tiene el Perfil
        /// </summary>
        /// <param name="strPerfil">Perfil.</param>
        /// <returns>Devuelve un dataset</returns>
        public DataSet obtenerFuncion(string strPerfil)
        {
            DataSet funcion = new DataSet();

            try
            {
                // Accedemos a la base de datos
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader funcionRecuperada = db.ExecuteReader(Constantes.OBTENER_FUNCION, strPerfil);
                // Cargamos los datos en la tabla
                DataTable funcionTabla = new DataTable();
                funcionTabla.Load(funcionRecuperada);

                funcion.Tables.Add(funcionTabla);                
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            // Devolvemos la funci�n
            return funcion;
        }
    }
}