﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Dal
{
    public class Base
    {
        #region variable

        /// <summary>
        /// Variable para manejar los mensajes
        /// </summary>
        private MantMensajes manejador;

        #endregion

        #region Propiedad

        public MantMensajes Manejador
        {
            get { return manejador; }
            set { manejador = value; }
        }


        #endregion
    }
}
