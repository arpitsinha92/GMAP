﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class GestionDepartamentos:Base
    {
        public GestionDepartamentos(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }

        /// <summary>
        /// Obteniene los departamentos que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="dept">datos para realizar el filtro de departamentos</param>
        /// <returns></returns>
        public DataSet buscarDepartamentos(FiltroDepartamento dept)
        {
            DataSet dsPersonas = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_GESTIONDEPARTAMENTOS);
                db.AddInParameter(dbCommand, Constantes.NOMBREDEPARTAMENTO, DbType.String, dept.NombreDepartamento);
                db.AddInParameter(dbCommand, Constantes.OIDEMPRESA, DbType.String, dept.Empresa);
                db.AddInParameter(dbCommand, Constantes.ESTADO, DbType.Int16, dept.Estado);

                IDataReader drPersonas = db.ExecuteReader(dbCommand);

                DataTable dtPersonas = new DataTable();
                dtPersonas.Load(drPersonas);

                dsPersonas.Tables.Add(dtPersonas);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPersonas;

        }

        /// <summary>
        /// Obteniene las cesiones que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="cesion">datos para realizar el filtro de cesion</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns></returns>
        public DataSet buscarCesiones(FiltroCesion cesion, string perfiles)
        {
            DataSet dsPersonas = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_GESTIONDEPARTAMENTOSCESIONES);
                db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, cesion.IdMedio);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, cesion.TipoMedio);
                db.AddInParameter(dbCommand, Constantes.CESIONACTIVA, DbType.Int16, cesion.CesionActiva);
                db.AddInParameter(dbCommand, Constantes.ID_ORGUNIT, DbType.String, cesion.IdDestCesion);
                db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);  

                IDataReader drPersonas = db.ExecuteReader(dbCommand);

                DataTable dtPersonas = new DataTable();
                dtPersonas.Load(drPersonas);

                dsPersonas.Tables.Add(dtPersonas);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPersonas;

        }
    }
}
