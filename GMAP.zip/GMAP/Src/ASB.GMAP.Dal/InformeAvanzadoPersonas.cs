﻿using System;
using System.Data;
using System.Data.Common;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace ASB.GMAP.Dal
{
    public class InformeAvanzadoPersonas : Base
    {
        public InformeAvanzadoPersonas(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }
     
        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles)
        {
            DataSet dsTiposMedios = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();

                dsTiposMedios = db.ExecuteDataSet(Constantes.LOAD_COMBOS_PERFIL, new object[] { Constantes.TIPOSDEMEDIOS, perfiles });
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposMedios;
        }

        /// <summary>
        /// Obtiene la lista de empresas para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de empresas</returns>
        public DataSet obtenerEmpresas()
        {
            DataSet dsEmpresas = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();

                dsEmpresas = db.ExecuteDataSet(Constantes.LOAD_COMBOS, Constantes.EMPRESAS);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsEmpresas;
        }

        /// <summary>
        /// Busca cesiones a personas que cumplan los criterios especificados en los parámetros.
        /// </summary>
        /// <param name="listaEmpresas">Lista separada por comas del los id de empresas</param>
        /// <param name="listaTipoMedios">Lista separada por comas del los id de tipos de medios</param>
        /// <param name="nombre">Nombre de la persona a quien se cedió el medio</param>
        /// <param name="codigoMedio">Código del medio</param>
        /// <param name="tipoContrato">Tipo de contrato del empleado {Interno, Externo}</param>
        /// <param name="esPersonaActiva">Indica si el empleado esta en activo</param>
        /// <param name="esCesionActiva">Indica si la cesión está activa</param>
        /// <returns>Un DataSet con las cesiones encontradas</returns>
        public DataSet buscarCesionesPersonas(string listaEmpresas, string listaTipoMedios, string nombre, string codigoMedio, string tipoContrato, int esPersonaActiva, int esCesionActiva)
        {
            DataSet dsCesionesPersonas = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_PERSONASAVANZADO))
                {
                    db.AddInParameter(dbCommand, Constantes.LISTAEMPRESAS, DbType.String, listaEmpresas);
                    db.AddInParameter(dbCommand, Constantes.LISTATIPOMEDIOS, DbType.String, listaTipoMedios);
                    db.AddInParameter(dbCommand, Constantes.NOMBREAPELLIDOS, DbType.String, nombre);
                    db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, codigoMedio);
                    db.AddInParameter(dbCommand, Constantes.TIPOCONTRATO, DbType.String, tipoContrato);
                    db.AddInParameter(dbCommand, Constantes.ESACTIVA, DbType.Int32, esPersonaActiva);
                    db.AddInParameter(dbCommand, Constantes.CESIONESACTIVAS, DbType.Int32, esCesionActiva);

                    dsCesionesPersonas = db.ExecuteDataSet(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsCesionesPersonas;
        }
    }
}
