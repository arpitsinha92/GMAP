﻿using System;
using System.Data;
using System.Data.Common;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace ASB.GMAP.Dal
{
    public class GestionAlertas : Base
    {
        public GestionAlertas(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }

        public GestionAlertas()
        {
            base.Manejador = new MantMensajes();
        }

        #region Personas

        /// <summary>
        /// Busca cesiones de médios a empleados que cumplan los criterios especificados
        /// en los parámetros.
        /// </summary>
        /// <param name="nombreEmpleado">Nombre del empleado</param>
        /// <param name="idTipoMedio">Tipo de medio cedido</param>
        /// <param name="esProrrogado">Indica si se ha prorrogado la cesión</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns>Un DataSet con las cesiones encontradas</returns>
        public DataSet buscarCesionesPersonas(string nombreEmpleado, int idTipoMedio, int esProrrogado, string perfiles)
        {
            DataSet dsCesionesPersonas = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_CESIONESPERSONAS))
                {
                    db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, nombreEmpleado);
                    db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int32, idTipoMedio);
                    db.AddInParameter(dbCommand, Constantes.ESPRORROGADO, DbType.Int32, esProrrogado);
                    db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);  

                    dsCesionesPersonas = db.ExecuteDataSet(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsCesionesPersonas;
        }

        #endregion

        #region Departamentos

        /// <summary>
        /// Busca cesiones de médios a empleados que cumplan los criterios especificados
        /// en los parámetros.
        /// </summary>
        /// <param name="nombreDepartamento">Nombre del departamento</param>
        /// <param name="idTipoMedio">Tipo de medio cedido</param>
        /// <param name="esProrrogado">Indica si se ha prorrogado la cesión</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns>Un DataSet con las cesiones encontradas</returns>
        public DataSet buscarCesionesDepartamentos(string nombreDepartamento, int idTipoMedio, int esProrrogado, string perfiles)
        {
            DataSet dsCesionesDepartamentos = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_CESIONESDEPARTAMENTOS))
                {
                    db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, nombreDepartamento);
                    db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int32, idTipoMedio);
                    db.AddInParameter(dbCommand, Constantes.ESPRORROGADO, DbType.Int32, esProrrogado);
                    db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);

                    dsCesionesDepartamentos = db.ExecuteDataSet(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsCesionesDepartamentos;
        }

        #endregion
    }
}
