﻿using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace ASB.GMAP.Dal
{
    public class InformeCuantalis : Base
    {
        public InformeCuantalis(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }

        public InformeCuantalis()
        {
            base.Manejador = new MantMensajes();
        }

        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles)
        {
            DataSet dsTiposMedios = new DataSet();

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_TIPOSMEDIOS_CUANTALIS);
                db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);

                IDataReader drTiposMedios = db.ExecuteReader(dbCommand);

                DataTable dtTiposMedios = new DataTable();
                dtTiposMedios.Load(drTiposMedios);

                dsTiposMedios.Tables.Add(dtTiposMedios);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposMedios;
        }

        public DataSet generarInforme(DateTime fechaInicio, DateTime fechaFin, int idTipoMedio)
        {
            DataSet dsCuantalis = null;

            try
            {
                try
                {

                    // Accedemos a base de datos por la Enterprise Library
                    Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                    using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.GENERAR_INFORME_CUANTALIS))
                    {
                        dbCommand.CommandTimeout = 600;
                        db.AddInParameter(dbCommand, Constantes.FECINICIO, DbType.DateTime, fechaInicio);
                        db.AddInParameter(dbCommand, Constantes.FECFIN, DbType.DateTime, fechaFin);
                        db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int32, idTipoMedio);

                        dsCuantalis = db.ExecuteDataSet(dbCommand);
                    }
                }
                catch (SqlException ex)
                {
                    string mensaje = "Ha habido un problema durante la ejecución del informe, superando el límite de espera de conexión al servidor de base de datos. Por favor, inténtalo más tarde.";
                    // Si da error de timeout lanzamos el mensaje
                    if (ex.Number == -2)
                    {
                        Manejador.agregar("2", mensaje, Mensajes.tiposMensaje.Error, ex);
                    }                    
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }            

            return dsCuantalis;
        }
    }
}
