﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class TiposDeMedios:Base
    {
        public TiposDeMedios(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }


        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la insert del nuevo tipo de medio
        /// </summary>
        /// <param name="tipoDeMedio">Objeto que contendrá los datos del nuevo tipo de medio</param>
        /// <returns></returns>
        public int insertarTipoDeMedio(TipoDeMedio tipoDeMedio)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_TIPOSDEMEDIO);
                db.AddInParameter(dbCommand, Constantes.NOMBRE,DbType.String, tipoDeMedio.Nombre);
                db.AddInParameter(dbCommand, Constantes.DESCRIPCION, DbType.String, tipoDeMedio.Descripcion);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, tipoDeMedio.FecBaja.Equals("")?null:tipoDeMedio.FecBaja);
                db.AddInParameter(dbCommand, Constantes.ENTREGABLE, DbType.Int16, tipoDeMedio.EsEntregable);
                db.AddInParameter(dbCommand, Constantes.MARCAMODELO, DbType.Int16, tipoDeMedio.TieneMarcaModelo);
                db.AddInParameter(dbCommand, Constantes.EXTENSION, DbType.Int16, tipoDeMedio.TieneExtension);
                db.AddInParameter(dbCommand, Constantes.CENTROCOSTE, DbType.String, tipoDeMedio.CentroCoste);
                
                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la update del tipo de medio seleccionado
        /// </summary>
        /// <param name="tipoDeMedio">Objeto que contendrá los datos del tipo de medio seleccionado</param>
        /// <returns></returns>
        public int actualizarTipoDeMedio(TipoDeMedio tipoDeMedio)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_TIPOSDEMEDIO);
                db.AddInParameter(dbCommand, Constantes.NOMBRE,DbType.String, tipoDeMedio.Nombre);
                db.AddInParameter(dbCommand, Constantes.DESCRIPCION, DbType.String, tipoDeMedio.Descripcion);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, tipoDeMedio.FecBaja.Equals("")?null:tipoDeMedio.FecBaja);
                db.AddInParameter(dbCommand, Constantes.ENTREGABLE, DbType.Int16, tipoDeMedio.EsEntregable);
                db.AddInParameter(dbCommand, Constantes.MARCAMODELO, DbType.Int16, tipoDeMedio.TieneMarcaModelo);
                db.AddInParameter(dbCommand, Constantes.EXTENSION, DbType.Int16, tipoDeMedio.TieneExtension);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, tipoDeMedio.OidTipoMedio);
                db.AddInParameter(dbCommand, Constantes.CENTROCOSTE, DbType.String, tipoDeMedio.CentroCoste);
                
                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la delete del tipo de medio seleccionado
        /// </summary>
        /// <param name="oidTipoMedio">ID del tipo de medio a borrar</param>
        /// <returns></returns>
        public int eliminarTipoDeMedio(string oidTipoMedio)
        {
            int returnValue = 0;
            
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_TIPOSDEMEDIO);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, oidTipoMedio);
                db.AddOutParameter(dbCommand, Constantes.RETURNVALUE, DbType.Int16, returnValue);

                db.ExecuteNonQuery(dbCommand);
                returnValue = Convert.ToInt16(db.GetParameterValue(dbCommand, Constantes.RETURNVALUE));
                
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return returnValue;

        }

        /// <summary>
        /// Comprobamos si ya existe un tipo de medio con el mismo nombre
        /// </summary>
        /// <param name="tipoMedio">Datos del tipo de medio</param>
        /// <returns>true si existe un tipo de medio con el mismo nombre</returns>
        public bool existeNombreTipoMedio(TipoDeMedio tipoMedio)
        {
            bool returnValue = false;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.EXISTE_TIPOMEDIO);
                db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, tipoMedio.Nombre);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, tipoMedio.OidTipoMedio);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }

        /// <summary>
        /// Obtenemos si hay medios asociados al tipo de medio con una fecha de baja posterior a la fecha de baja
        /// del tipo de medio
        /// </summary>
        /// <param name="modelo">datos del modelo</param>
        /// <returns></returns>
        public bool tieneFecBajaAnteriorMedios(TipoDeMedio tipMedio)
        {
            bool returnValue = false;

            DataSet dsModelos = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.TIPOSDEMEDIOS_CON_MEDIOS_BAJA);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, tipMedio.OidTipoMedio);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, tipMedio.FecBaja);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }
        
        

        /// <summary>
        /// Obtenemos los tipos de medio que cumplan el filtro
        /// </summary>
        /// <param name="filtroTipoMedio">Valor del filtro para los tipos de medio</param>
        /// <returns></returns>
        public DataSet buscarTiposDeMedio(string filtroTipoMedio)
        {
            DataSet dsTiposDeMedio = new DataSet();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader drTiposDeMedio = db.ExecuteReader(Constantes.SELECT_TIPOSDEMEDIO, filtroTipoMedio);

                DataTable dtTiposDeMedio = new DataTable();
                dtTiposDeMedio.Load(drTiposDeMedio);

                dsTiposDeMedio.Tables.Add(dtTiposDeMedio);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposDeMedio;

        }
    }
}
