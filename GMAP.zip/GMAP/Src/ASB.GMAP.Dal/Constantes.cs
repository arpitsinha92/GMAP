﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Dal
{
    public class Constantes
    {
        
        // Procedimientos almacenados
        public const string INSERT_TIPOSDEMEDIO = "sp_InsertTiposDeMedios";
        public const string SELECT_TIPOSDEMEDIO = "sp_SelectTiposDeMedios";
        public const string UPDATE_TIPOSDEMEDIO = "sp_UpdateTiposDeMedios";
        public const string DELETE_TIPOSDEMEDIO = "sp_DeleteTiposDeMedios";
        public const string INSERT_MARCA = "sp_InsertMarca";
        public const string UPDATE_MARCA = "sp_UpdateMarca";
        public const string SELECT_MARCAS = "sp_SelectMarcas";
        public const string DELETE_MARCA = "sp_DeleteMarca";
        public const string INSERT_MODELO = "sp_InsertModelo";
        public const string UPDATE_MODELO = "sp_UpdateModelo";
        public const string SELECT_MODELOS = "sp_SelectModelos";
        public const string DELETE_MODELO = "sp_DeleteModelo";
        public const string SELECT_EMPRESAS = "sp_SelectEmpresas";
        public const string SELECT_PERSONAS = "sp_SelectPersonas";
        public const string SELECT_DEPARTAMENTOS = "sp_SelectDepartamentos";
        public const string INSERT_MEDIO = "sp_InsertMedio";
        public const string INSERT_MEDIOCESIONEMPLEADO = "sp_InsertMedioCesionEmpleado";
        public const string INSERT_MEDIOCESIONDEPARTAMENTO = "sp_InsertMedioCesionDepartamento";
        public const string SELECT_MEDIOSCESION = "sp_SelectMediosCesion";
        public const string SELECT_MEDIOS = "sp_SelectMedios";
        public const string SELECT_DATOSTIPOSDEMEDIOS = "sp_SelectDatosTiposDeMedios";
        public const string UPDATE_CESIONEMPLEADO = "sp_UpdateCesionEmpleado";
        public const string DELETE_CESIONEMPLEADO = "sp_DeleteCesionEmpleado";
        public const string UPDATE_CESIONDEPARTAMENTO = "sp_UpdateCesionDepartamento";
        public const string DELETE_CESIONDEPARTAMENTO = "sp_DeleteCesionDepartamento";
        public const string SELECT_EDICIONCESIONDEPARTAMENTO = "sp_SelectEdicionCesionDepartamento";
        public const string SELECT_EDICIONCESIONEMPLEADO = "sp_SelectEdicionCesionEmpleado";
        public const string SELECT_DELETECESIONEMPLEADO = "sp_SelectDeleteCesionEmpleado";
        public const string SELECT_DELETECESIONDEPARTAMENTO = "sp_SelectDeleteCesionDepartamento";
        public const string UPDATE_MEDIO = "sp_UpdateMedio";
        public const string TIENE_CESION = "fun_TieneCesion";
        public const string SELECT_EDICIONMEDIO = "sp_SelectEdicionMedio";
        public const string SELECT_GESTIONPERSONAS = "sp_SelectGestionPersonas";
        public const string SELECT_GESTIONPERSONASCESIONES = "sp_SelectGestionPersonasCesiones";
        public const string SELECT_DELETECESIONACTIVADEPARTAMENTO = "sp_SelectDeleteCesionActivaDepartamento";
        public const string SELECT_DELETECESIONACTIVAEMPLEADO = "sp_SelectDeleteCesionActivaEmpleado";
        public const string SELECT_GESTIONDEPARTAMENTOS = "sp_SelectGestionDepartamentos";
        public const string SELECT_GESTIONDEPARTAMENTOSCESIONES = "sp_SelectGestionDepartamentosCesiones";
        public const string SELECT_FUNCIONES = "sp_SelectFunciones";
        public const string SELECT_TIPOSMEDIOS_FUNCION = "sp_SelectTiposMediosPorFuncion";
        public const string SELECT_ACCIONES_FUNCION = "sp_SelectAccionesPorFuncion";
        public const string SELECT_ACCIONES = "sp_SelectAcciones";
        public const string INSERT_FUNCION = "sp_InsertFuncion";
        public const string INSERT_TIPOMEDIO_FUNCION = "sp_InsertTipoMedioPorFuncion";
        public const string INSERT_ACCION_FUNCION = "sp_InsertAccionPorFuncion";
        public const string UPDATE_FUNCION = "sp_UpdateFuncion";
        public const string DELETE_TIPOSMEDIOS_FUNCION = "sp_DeleteTiposMediosPorFuncion";
        public const string DELETE_ACCIONES_FUNCION = "sp_DeleteAccionesPorFuncion";
        public const string DELETE_FUNCION = "sp_DeleteFuncion";
        public const string SELECT_PERFILES = "sp_SelectPerfiles";
        public const string SELECT_FUNCIONES_PERFIL = "sp_SelectFuncionesPorPerfil";
		public const string SELECT_MENUS_PERFIL = "sp_SelectMenusPorPerfil";
        public const string INSERT_PERFIL = "sp_InsertPerfil";
        public const string INSERT_FUNCION_PERFIL = "sp_InsertFuncionPorPerfil";
		public const string INSERT_MENU_PERFIL = "sp_InsertMenuPorPerfil";
        public const string UPDATE_PERFIL = "sp_UpdatePerfil";
        public const string DELETE_FUNCIONES_PERFIL = "sp_DeleteFuncionesPorPerfil";
		public const string DELETE_MENUS_PERFIL = "sp_DeleteMenusPorPerfil";
        public const string DELETE_PERFIL = "sp_DeletePerfil";
        public const string SELECT_CESIONESPERSONAS = "sp_SelectCesionesPersonas";
        public const string SELECT_CESIONESDEPARTAMENTOS = "sp_SelectCesionesDepartamentos";
        public const string SELECT_MISCESIONES = "sp_SelectMisCesiones";
        public const string SELECT_TIPOSMEDIOS_CUANTALIS = "sp_SelectTiposMediosCuantalis";
        public const string GENERAR_INFORME_CUANTALIS = "sp_GeneraListadoCUANTALIS";
        public const string SELECT_TIPOSMEDIOSACCESOS = "sp_SelectTiposDeMediosAccesos";
        public const string LOAD_COMBOS = "sp_LoadCombos";
        public const string LOAD_COMBOS_PERFIL = "sp_LoadCombosPerfil";
        public const string SELECT_PERSONASAVANZADO = "sp_SelectPersonasAvanzado";
        public const string MARCA_CON_MODELOS_BAJA = "fun_tieneMarcaModelosBaja";
        public const string SELECT_DEPARTAMENTOSAVANZADO = "sp_SelectDepartamentosAvanzado";
        public const string MODELOS_CON_MEDIOS_BAJA = "fun_tieneModeloMediosBaja";
        public const string MODELO_CON_FECBAJA_POSTERIOR_MARCA = "fun_tieneFecBajaPosteriorMarca";
        public const string DELETE_MEDIO = "sp_DeleteMedio";
        public const string SELECT_ACCIONES_PERFIL = "sp_SelectAccionesPorPerfil";
        public const string TIPOSDEMEDIOS_CON_MEDIOS_BAJA = "fun_tieneTiposMedioMediosBaja";
		public const string SELECT_OPCIONESMENU = "sp_SelectOpcionesMenu";
        public const string SELECT_PAGINASPERFIL = "sp_SelectPaginasPorPerfil";
        public const string OBTENER_DATOS_CESION_ACTIVA_MEDIO = "sp_ObtenerDatosCesionActivaMedio";
        public const string SELECT_MISCESIONESTIPOSMEDIOS = "sp_SelectMisCesionesTiposMedios";

        public const string OBTENER_MENU = "sp_RecuperaOpcionesMenu";
        public const string OBTENER_FUNCION = "sp_ObtenerFuncion";
        public const string EXISTE_MARCA = "fun_ExisteMarcaConNombre";
        public const string EXISTE_MARCA_NOMBRE_MODELO = "fun_ExisteMarcaNombreModelo";
        public const string EXISTE_TIPOMEDIO = "fun_ExisteTipoMedio";
        public const string EXISTE_MEDIO_ID_TIPOMEDIO = "fun_ExisteIDMedioTipoMedio";
        

        //Parametros procedimientos almacenados
        public const string NOMBRE = "@var_Nombre";
        public const string DESCRIPCION = "@var_Descripcion";
        public const string FECBAJA = "@dat_fecbaja";
        public const string ENTREGABLE = "@bit_entregable";
        public const string MARCAMODELO = "@bit_marcamodelo";
        public const string EXTENSION = "@bit_exttfno";
        public const string OIDTIPOMEDIO = "@int_oidtipomedio";
        public const string RETURNVALUE = "@int_returnValue";
        public const string OIDMARCA = "@int_oidmarca";
        public const string OIDMODELO = "@int_oidmodelo";
        public const string NOMBREAPELLIDOS  = "@var_nombreapellidos";
        public const string OIDEMPRESA = "@var_oidempresa";
        public const string TIPOCONTRATO = "@var_tipocontrato";
        public const string ESTADO = "@int_estado";
        public const string NOMBREDEPARTAMENTO = "@var_nombreDept";
        public const string IDMEDIO = "@var_idMedio";
        public const string EXTENSIONMEDIO = "@var_extensionMedio";
        public const string FECHAALTA = "@dat_fecAlta";
        public const string NUMEMPLEADO = "@var_strnumempleado";
        public const string FECINICESION = "@dat_fecIniCesion";
        public const string COMENTARIOSCESION = "@var_comentariosCesion";
        public const string ID_ORGUNIT = "@var_idorgunit";
        public const string OIDMEDIO = "@int_oidmedio";
        public const string COMENTARIOSMEDIO = "@var_comentariosmedio";
        public const string LIBRE = "@bit_libre";
        public const string EMPAUDITORIA = "@strEmpleadoAuditori";
        public const string FECFINPRORROGA = "@dat_fecfinprorroga";
        public const string FECFINCESION = "@dat_fecfin";
        public const string OIDCESION = "@int_oidcesion";
        public const string CESIONACTIVA = "@bit_cesionesActivas";
        public const string ID_FUNCION = "@idFuncion";
        public const string ID_PERFIL = "@idPerfil";
        public const string LISTATIPOMEDIOS = "@listaTipoMedios";
        public const string COMENTARIOS = "@comentarios";
        public const string LISTAEMPRESAS = "@listaEmpresas";
        public const string TIPOCESION = "@tipoCesion";
        public const string CESIONESACTIVAS = "@cesionesActivas";
        public const string ESPRORROGADO = "@bit_esProrrogado";
        public const string ESACTIVA = "@bit_esActiva";
        public const string FECINICIO = "@fechaInicio";
        public const string FECFIN = "@fechaFin";
        public const string PERFILES_USUARIO = "@var_perfiles";
        public const string TABLA = "@strTabla";
        public const string DEPARTAMENTO = "@var_nombreDept";
        public const string CENTROCOSTE = "@var_cc";
        
        // Tipos de Orden
        public const string ORDEN_ASCENDENTE = "ASC";
        public const string ORDEN_DESCENDENTE = "DESC";

        public const String TIPOSDEMEDIOS = "Tb_TiposMedios";
        public const String EMPRESAS = "Vw_Empresas";
    }
}

