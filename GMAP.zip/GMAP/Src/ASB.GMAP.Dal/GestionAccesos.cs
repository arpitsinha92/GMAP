﻿using System;
using System.Data;
using System.Xml;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using ASB.GMAP.Ent;
using System.Collections.Generic;

namespace ASB.GMAP.Dal
{
    public class GestionAccesos : Base
    {
        public GestionAccesos(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }

        #region Funciones

        /// <summary>
        /// Obtiene una lista de las funciones almacenadas en la base de datos
        /// sin fecha de baja o con fecha de baja posterior a la fecha del día
        /// </summary>
        /// <returns>Un DataSet con la tabla de funciones</returns>
        public DataSet obtenerListaFunciones()
        {
            DataSet dsFunciones = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsFunciones = db.ExecuteDataSet(Constantes.SELECT_FUNCIONES);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsFunciones;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataSet obtenerListaTiposMedios()
        {
            DataSet dsTiposMedios = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsTiposMedios = db.ExecuteDataSet(Constantes.SELECT_TIPOSMEDIOSACCESOS);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposMedios;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataSet obtenerListaAcciones()
        {
            DataSet dsAcciones = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsAcciones = db.ExecuteDataSet(Constantes.SELECT_ACCIONES);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsAcciones;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <returns></returns>
        public DataSet obtenerTiposMediosPorFuncion(int idFuncion)
        {
            DataSet dsTiposMedios = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsTiposMedios = db.ExecuteDataSet(Constantes.SELECT_TIPOSMEDIOS_FUNCION, idFuncion);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposMedios;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <returns></returns>
        public DataSet obtenerAccionesPorFuncion(int idFuncion)
        {
            DataSet dsAcciones = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsAcciones = db.ExecuteDataSet(Constantes.SELECT_ACCIONES_FUNCION, idFuncion);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsAcciones;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <param name="fechaBaja"></param>
        /// <returns></returns>
        public int eliminarFuncion(int idFuncion, DateTime fechaBaja)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_FUNCION))
                {
                    db.AddInParameter(dbCommand, Constantes.ID_FUNCION, DbType.Int32, idFuncion);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, fechaBaja);

                    resultado = db.ExecuteNonQuery(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="funcion"></param>
        /// <returns></returns>
        public int insertarFuncion(Funcion funcion)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_FUNCION))
                {
                    db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, funcion.Nombre);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, funcion.FechaBaja);
                    db.AddOutParameter(dbCommand, Constantes.ID_FUNCION, DbType.Int32, Int32.MaxValue);

                    using (DbConnection conn = db.CreateConnection())
                    {
                        conn.Open();
                        DbTransaction trans = conn.BeginTransaction();

                        try
                        {
                            resultado = db.ExecuteNonQuery(dbCommand, trans);

                            int idFuncionInsertada = Convert.ToInt32(dbCommand.Parameters[Constantes.ID_FUNCION].Value);

                            if (funcion.Acciones != null)
                            {
                                foreach (Accion accion in funcion.Acciones)
                                {
                                    insertarAccionPorFuncion(idFuncionInsertada, accion.IdAccion, trans);
                                }
                            }

                            if (funcion.TiposDeMedios != null)
                            {
                                foreach (TipoDeMedio tipoMedio in funcion.TiposDeMedios)
                                {
                                    insertarTipoMedioPorFuncion(idFuncionInsertada, Convert.ToInt16(tipoMedio.OidTipoMedio), trans);
                                }
                            }

                            trans.Commit();
                        }
                        catch (Exception err)
                        {
                            trans.Rollback();
                            throw new Exception(err.Message, err);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncionInsertada"></param>
        /// <param name="idTipoMedio"></param>
        /// <returns></returns>
        private int insertarTipoMedioPorFuncion(int idFuncionInsertada, int idTipoMedio, DbTransaction trans = null)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_TIPOMEDIO_FUNCION, new object[] { idFuncionInsertada, idTipoMedio }))
                {
                    resultado = trans == null ? db.ExecuteNonQuery(dbCommand) : db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncionInsertada"></param>
        /// <param name="idAccion"></param>
        /// <returns></returns>
        private int insertarAccionPorFuncion(int idFuncionInsertada, int idAccion, DbTransaction trans = null)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_ACCION_FUNCION, new object[] { idFuncionInsertada, idAccion }))
                {
                    resultado = trans == null ? db.ExecuteNonQuery(dbCommand) : db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="funcion"></param>
        /// <returns></returns>
        public int actualizarFuncion(Funcion funcion)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_FUNCION))
                {
                    db.AddInParameter(dbCommand, Constantes.ID_FUNCION, DbType.Decimal, funcion.IdFuncion);
                    db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, funcion.Nombre);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, funcion.FechaBaja);

                    using (DbConnection conn = db.CreateConnection())
                    {
                        conn.Open();
                        DbTransaction trans = conn.BeginTransaction();

                        try
                        {
                            resultado = db.ExecuteNonQuery(dbCommand, trans);

                            eliminarAccionesPorFuncion(funcion.IdFuncion, trans);
                            eliminarTiposMediosPorFuncion(funcion.IdFuncion, trans);

                            if (funcion.Acciones != null)
                            {
                                foreach (Accion accion in funcion.Acciones)
                                {
                                    insertarAccionPorFuncion(funcion.IdFuncion, accion.IdAccion, trans);
                                }
                            }

                            if (funcion.TiposDeMedios != null)
                            {
                                foreach (TipoDeMedio tipoMedio in funcion.TiposDeMedios)
                                {
                                    insertarTipoMedioPorFuncion(funcion.IdFuncion, Convert.ToInt16(tipoMedio.OidTipoMedio), trans);
                                }
                            }

                            trans.Commit();
                        }
                        catch (Exception err)
                        {
                            trans.Rollback();
                            throw new Exception(err.Message, err);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <returns></returns>
        private int eliminarTiposMediosPorFuncion(int idFuncion, DbTransaction trans)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_TIPOSMEDIOS_FUNCION, idFuncion))
                {
                    resultado = db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <returns></returns>
        private int eliminarAccionesPorFuncion(int idFuncion, DbTransaction trans)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_ACCIONES_FUNCION, idFuncion))
                {
                    resultado = db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        #endregion

        #region Perfiles

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataSet obtenerListaPerfiles()
        {
            DataSet dsPerfiles = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsPerfiles = db.ExecuteDataSet(Constantes.SELECT_PERFILES);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPerfiles;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rutaXml"></param>
        /// <returns></returns>
        public DataSet obtenerListaOpcionesMenu()
        {
            DataSet dsOpcionesMenu = new DataSet();

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsOpcionesMenu = db.ExecuteDataSet(Constantes.SELECT_OPCIONESMENU);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsOpcionesMenu;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfil"></param>
        /// <returns></returns>
        public DataSet obtenerFuncionesPorPerfil(int idPerfil)
        {
            DataSet dsFunciones = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsFunciones = db.ExecuteDataSet(Constantes.SELECT_FUNCIONES_PERFIL, idPerfil);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsFunciones;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfil"></param>
        /// <param name="rutaXml"></param>
        /// <returns></returns>
        public DataSet obtenerOpcionesMenuPorPerfil(int idPerfil)
        {
            DataSet dsOpcionesMenu = new DataSet();

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsOpcionesMenu = db.ExecuteDataSet(Constantes.SELECT_MENUS_PERFIL, idPerfil);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsOpcionesMenu;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfil"></param>
        /// <param name="fechaBaja"></param>
        /// <returns></returns>
        public int eliminarPerfil(int idPerfil, DateTime fechaBaja)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_PERFIL))
                {
                    db.AddInParameter(dbCommand, Constantes.ID_PERFIL, DbType.Int32, idPerfil);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, fechaBaja);

                    resultado = db.ExecuteNonQuery(dbCommand);
                }

                // Eliminar opciones de menú asociadas al perfil
                // TODO: eliminarOpcionesMenuPorPerfil(idPerfil);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="perfil"></param>
        /// <returns></returns>
        public int insertarPerfil(Perfil perfil)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_PERFIL))
                {
                    db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, perfil.Nombre);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, perfil.FechaBaja);
                    db.AddOutParameter(dbCommand, Constantes.ID_PERFIL, DbType.Int32, Int32.MaxValue);

                    using (DbConnection conn = db.CreateConnection())
                    {
                        conn.Open();
                        DbTransaction trans = conn.BeginTransaction();

                        try
                        {
                            resultado = db.ExecuteNonQuery(dbCommand, trans);

                            int idPerfilInsertado = Convert.ToInt32(dbCommand.Parameters[Constantes.ID_PERFIL].Value);

                            if (perfil.Funciones != null)
                            {
                                foreach (Funcion funcion in perfil.Funciones)
                                {
                                    insertarFuncionPorPerfil(idPerfilInsertado, funcion.IdFuncion, trans);
                                }
                            }

                            // Insertamos las opciones de menú asociadas al perfil
                            if (perfil.OpcionesMenu != null)
                            {
                                foreach (OpcionMenu opcionMenu in perfil.OpcionesMenu)
                                {
                                    insertarOpcionMenuPorPerfil(idPerfilInsertado, opcionMenu.IdOpcionMenu, trans);
                                }
                            }

                            trans.Commit();
                        }
                        catch (Exception err)
                        {
                            trans.Rollback();
                            throw new Exception(err.Message, err);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfilInsertado"></param>
        /// <param name="idMenu"></param>
        /// <param name="trans"></param>
        /// <returns></returns>
        private int insertarOpcionMenuPorPerfil(int idPerfilInsertado, int idMenu, DbTransaction trans = null)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_MENU_PERFIL, new object[] { idPerfilInsertado, idMenu }))
                {
                    resultado = trans == null ? db.ExecuteNonQuery(dbCommand) : db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfilInsertado"></param>
        /// <param name="idFuncion"></param>
        /// <param name="trans"></param>
        /// <returns></returns>
        private int insertarFuncionPorPerfil(int idPerfilInsertado, int idFuncion, DbTransaction trans = null)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_FUNCION_PERFIL, new object[] { idPerfilInsertado, idFuncion }))
                {
                    resultado = trans == null ? db.ExecuteNonQuery(dbCommand) : db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="perfil"></param>
        /// <returns></returns>
        public int actualizarPerfil(Perfil perfil)
        {
            // Código de error
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_PERFIL))
                {
                    db.AddInParameter(dbCommand, Constantes.ID_PERFIL, DbType.Decimal, perfil.IdPerfil);
                    db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, perfil.Nombre);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, perfil.FechaBaja);

                    using (DbConnection conn = db.CreateConnection())
                    {
                        conn.Open();
                        DbTransaction trans = conn.BeginTransaction();

                        try
                        {
                            resultado = db.ExecuteNonQuery(dbCommand, trans);

                            eliminarFuncionesPorPerfil(perfil.IdPerfil, trans);

                            if (perfil.Funciones != null)
                            {
                                foreach (Funcion funcion in perfil.Funciones)
                                {
                                    insertarFuncionPorPerfil(perfil.IdPerfil, funcion.IdFuncion, trans);
                                }
                            }

                            // Actualizamos las opciones de menú asociadas al perfil
                            eliminarOpcionesMenuPorPerfil(perfil.IdPerfil, trans);

                            if (perfil.OpcionesMenu != null)
                            {
                                foreach (OpcionMenu opcionMenu in perfil.OpcionesMenu)
                                {
                                    insertarOpcionMenuPorPerfil(perfil.IdPerfil, opcionMenu.IdOpcionMenu, trans);
                                }
                            }

                            trans.Commit();
                        }
                        catch (Exception err)
                        {
                            trans.Rollback();
                            throw new Exception(err.Message, err);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nombrePerfil"></param>
        /// <param name="rutaXml"></param>
        /// <returns></returns>
        private int eliminarOpcionesMenuPorPerfil(int idPerfil, DbTransaction trans)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_MENUS_PERFIL, idPerfil))
                {
                    resultado = db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfil"></param>
        /// <param name="trans"></param>
        /// <returns></returns>
        private int eliminarFuncionesPorPerfil(int idPerfil, DbTransaction trans)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_FUNCIONES_PERFIL, idPerfil))
                {
                    resultado = db.ExecuteNonQuery(dbCommand, trans);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
                throw new Exception(err.Message, err);
            }

            return resultado;
        }

        #endregion

        public DataSet obtenerAccionesPorPerfil(string perfiles)
        {
            DataSet dsAcciones = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsAcciones = db.ExecuteDataSet(Constantes.SELECT_ACCIONES_PERFIL, perfiles);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsAcciones;
        }

        public DataSet obtenerPaginasPorPerfil(string perfiles)
        {
            DataSet dsPaginas = null;

            try
            {
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                dsPaginas = db.ExecuteDataSet(Constantes.SELECT_PAGINASPERFIL, perfiles);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPaginas;
        }
    }
}
