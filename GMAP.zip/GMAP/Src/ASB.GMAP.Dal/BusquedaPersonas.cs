﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class BusquedaPersonas:Base
    {
        public BusquedaPersonas(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }

        /// <summary>
        /// Obteniene las personas que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="filtroPer">datos para realizar el filtro de personas</param>
        /// <returns></returns>
        public DataSet buscarPersonas(FiltroPersona filtroPer)
        {
            DataSet dsPersonas = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_PERSONAS);
                db.AddInParameter(dbCommand, Constantes.NOMBREAPELLIDOS, DbType.String, filtroPer.NombreApellidos);
                db.AddInParameter(dbCommand, Constantes.OIDEMPRESA, DbType.String, filtroPer.Empresa);
                db.AddInParameter(dbCommand, Constantes.TIPOCONTRATO, DbType.String, filtroPer.TipoContrato);
                db.AddInParameter(dbCommand, Constantes.ESTADO, DbType.Int16, filtroPer.Estado);

                IDataReader drPersonas = db.ExecuteReader(dbCommand);

                DataTable dtPersonas = new DataTable();
                dtPersonas.Load(drPersonas);

                dsPersonas.Tables.Add(dtPersonas);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPersonas;

        }
    }
}
