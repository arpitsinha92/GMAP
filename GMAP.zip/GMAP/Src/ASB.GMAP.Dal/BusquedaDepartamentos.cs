﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class BusquedaDepartamentos:Base
    {
        public BusquedaDepartamentos(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }

        /// <summary>
        /// Obteniene los departamentos que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="filtroDept">datos para realizar el filtro de departamentos</param>
        /// <returns></returns>
        public DataSet buscarDepartamentos(FiltroDepartamento filtroDept)
        {
            DataSet dsDepartamentos = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_DEPARTAMENTOS);
                db.AddInParameter(dbCommand, Constantes.NOMBREDEPARTAMENTO, DbType.String, filtroDept.NombreDepartamento);
                db.AddInParameter(dbCommand, Constantes.OIDEMPRESA, DbType.String, filtroDept.Empresa);                

                IDataReader drDepartamentos = db.ExecuteReader(dbCommand);

                DataTable dtDepartamentos = new DataTable();
                dtDepartamentos.Load(drDepartamentos);

                dsDepartamentos.Tables.Add(dtDepartamentos);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);                
            }

            return dsDepartamentos;
        }
    }
}
