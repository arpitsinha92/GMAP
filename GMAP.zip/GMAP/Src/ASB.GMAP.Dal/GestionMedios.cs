﻿using System;
using System.Data;
using System.Data.Common;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace ASB.GMAP.Dal
{
    public class GestionMedios : Base
    {
        public GestionMedios(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }

        public GestionMedios()
        {
            base.Manejador = new MantMensajes();
        }

        /// <summary>
        /// Busca medios que cumplan los criterios especificados en los parámetros.
        /// </summary>
        /// <param name="idMedio">Código identificador del medio</param>
        /// <param name="tipoCesion">Tipo de cesion: -1 -> Todas; 0 -> A personas; 1 -> A departamentos; 2 -> Disponibles</param>
        /// <param name="estado">Estado del medio: -1 -> Todas; 0 -> No activo; 1 -> Activo</param>
        /// <param name="listaTipoMedios">Lista separada por comas del los id de tipos de medios</param>
        /// <returns>Un DataSet con los medios encontrados</returns>
        public DataSet buscarMedios(string idMedio, int tipoCesion, int estado, string listaTipoMedios, int cesionesActivas, int medioLibre, string comentarios)
        {
            DataSet dsMedios = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_MEDIOS))
                {
                    db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, idMedio);
                    db.AddInParameter(dbCommand, Constantes.TIPOCESION, DbType.Int32, tipoCesion);
                    db.AddInParameter(dbCommand, Constantes.ESTADO, DbType.Int32, estado);
                    db.AddInParameter(dbCommand, Constantes.LISTATIPOMEDIOS, DbType.String, listaTipoMedios);
                    db.AddInParameter(dbCommand, Constantes.CESIONESACTIVAS, DbType.Int32, cesionesActivas);
                    db.AddInParameter(dbCommand, Constantes.LIBRE, DbType.Int32, medioLibre);
                    db.AddInParameter(dbCommand, Constantes.COMENTARIOS, DbType.String, comentarios);

                    dsMedios = db.ExecuteDataSet(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsMedios;
        }

        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles)
        {
            DataSet dsTiposMedios = new DataSet();

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.LOAD_COMBOS_PERFIL);
                db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);
                db.AddInParameter(dbCommand, Constantes.TABLA, DbType.String, Constantes.TIPOSDEMEDIOS);

                IDataReader drTiposMedios = db.ExecuteReader(dbCommand);

                DataTable dtTiposMedios = new DataTable();
                dtTiposMedios.Load(drTiposMedios);

                dsTiposMedios.Tables.Add(dtTiposMedios);
               
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposMedios;
        }

        public int eliminarMedio(int idMedio, DateTime fechaBaja)
        {
            int resultado = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_MEDIO))
                {
                    db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.Int32, idMedio);
                    db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, fechaBaja);

                    resultado = db.ExecuteNonQuery(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return resultado;
        }
    }
}
