﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class CesionMedioDisponible:Base
    {
        public CesionMedioDisponible(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }

                       
        /// <summary>
        /// Creamos la cesión del medio al empleado
        /// </summary>
        /// <param name="cesion">Caracteristicas de la cesión al empleado</param>
        /// <returns></returns>
        public int insertarMedioCedidoEmpleado(Cesion cesion)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_MEDIOCESIONEMPLEADO);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, cesion.OidMedio);
                db.AddInParameter(dbCommand, Constantes.NUMEMPLEADO, DbType.String, cesion.IdDestinatarioCesion);
                db.AddInParameter(dbCommand, Constantes.FECINICESION, DbType.DateTime, cesion.FecIni.Equals("") ? null : cesion.FecIni);
                db.AddInParameter(dbCommand, Constantes.FECFINCESION, DbType.DateTime, cesion.FecFin.Equals("") ? null : cesion.FecFin);
                db.AddInParameter(dbCommand, Constantes.COMENTARIOSCESION, DbType.String, cesion.Comentarios);
                
                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Creamos la cesión del medio al departamento
        /// </summary>
        /// <param name="cesion">Caracteristicas de la cesión al departamento</param>
        /// <returns></returns>
        public int insertarMedioCedidoDepartamento(Cesion cesion)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_MEDIOCESIONDEPARTAMENTO);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, cesion.OidMedio);
                db.AddInParameter(dbCommand, Constantes.ID_ORGUNIT, DbType.String, cesion.IdDestinatarioCesion);
                db.AddInParameter(dbCommand, Constantes.FECINICESION, DbType.DateTime, cesion.FecIni.Equals("") ? null : cesion.FecIni);
                db.AddInParameter(dbCommand, Constantes.FECFINCESION, DbType.DateTime, cesion.FecFin.Equals("") ? null : cesion.FecFin);
                db.AddInParameter(dbCommand, Constantes.COMENTARIOSCESION, DbType.String, cesion.Comentarios);

                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;
        }

        /// <summary>
        /// Obteniene los medios que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="oidTipoMedio">Tipo de medio por que que se va a realizar el filtrado</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns></returns>
        public DataSet buscarMedios(int oidTipoMedio, string perfiles)
        {
            DataSet dsMedios = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_MEDIOSCESION);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, oidTipoMedio);
                db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);  
                
                IDataReader drMedios = db.ExecuteReader(dbCommand);

                DataTable dtMedios = new DataTable();
                dtMedios.Load(drMedios);

                dsMedios.Tables.Add(dtMedios);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsMedios;

        }
    }
}
