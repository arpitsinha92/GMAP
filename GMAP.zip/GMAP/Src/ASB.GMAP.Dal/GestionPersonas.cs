﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class GestionPersonas:Base
    {
        public GestionPersonas(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }

        /// <summary>
        /// Obteniene las personas que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="persona">datos para realizar el filtro de personas</param>
        /// <returns></returns>
        public DataSet buscarPersonas(FiltroPersona persona)
        {
            DataSet dsPersonas = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_GESTIONPERSONAS);
                db.AddInParameter(dbCommand, Constantes.NOMBREAPELLIDOS, DbType.String, persona.NombreApellidos);
                db.AddInParameter(dbCommand, Constantes.OIDEMPRESA, DbType.String, persona.Empresa);
                db.AddInParameter(dbCommand, Constantes.TIPOCONTRATO, DbType.String, persona.TipoContrato);
                db.AddInParameter(dbCommand, Constantes.ESTADO, DbType.Int16, persona.Estado);

                IDataReader drPersonas = db.ExecuteReader(dbCommand);

                DataTable dtPersonas = new DataTable();
                dtPersonas.Load(drPersonas);

                dsPersonas.Tables.Add(dtPersonas);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPersonas;

        }

        /// <summary>
        /// Obteniene las cesiones que cumplen las condiciones del filtro
        /// </summary>
        /// <param name="cesion">datos para realizar el filtro de cesion</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns></returns>
        public DataSet buscarCesiones(FiltroCesion cesion, string perfiles)
        {
            DataSet dsPersonas = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_GESTIONPERSONASCESIONES);
                db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, cesion.IdMedio);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, cesion.TipoMedio);
                db.AddInParameter(dbCommand, Constantes.CESIONACTIVA, DbType.Int16, cesion.CesionActiva);
                db.AddInParameter(dbCommand, Constantes.NUMEMPLEADO, DbType.String, cesion.IdDestCesion);
                db.AddInParameter(dbCommand, Constantes.PERFILES_USUARIO, DbType.String, perfiles);  

                IDataReader drPersonas = db.ExecuteReader(dbCommand);

                DataTable dtPersonas = new DataTable();
                dtPersonas.Load(drPersonas);

                dsPersonas.Tables.Add(dtPersonas);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsPersonas;

        }
    }
}
