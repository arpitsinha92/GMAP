﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;
using System.Collections;

namespace ASB.GMAP.Dal
{
    public class EditarMedio : Base
    {
        public EditarMedio(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }


        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la update del medio
        /// </summary>
        /// <param name="medio">Objeto que contendrá los datos del nuevo medio</param>
        /// <returns></returns>
        public int actualizarMedio(Medio medio)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_MEDIO);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, medio.OidMedio);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, medio.OidTipoMedio);
                db.AddInParameter(dbCommand, Constantes.OIDMODELO, DbType.Int16, medio.OidModelo == -1 ? (int?)null : medio.OidModelo);
                db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, medio.IdMedio);
                db.AddInParameter(dbCommand, Constantes.EXTENSIONMEDIO, DbType.String, medio.Extension);
                db.AddInParameter(dbCommand, Constantes.FECHAALTA, DbType.DateTime, medio.FecAlta.Equals("") ? null : medio.FecAlta);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, medio.FecBaja.Equals("") ? null : medio.FecBaja);
                db.AddInParameter(dbCommand, Constantes.COMENTARIOSMEDIO, DbType.String, medio.Comentarios);
                //db.AddInParameter(dbCommand, Constantes.LIBRE, DbType.Boolean, medio.Libre);

                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Obtenemos los datos del medio
        /// </summary>        
        /// <returns>datable con los datos del medio</returns>
        public DataTable buscarMedio(int oidMedio)
        {
            DataTable dtCesion = new DataTable();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_EDICIONMEDIO);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, oidMedio);

                IDataReader drCesion = db.ExecuteReader(dbCommand);
                dtCesion.Load(drCesion);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dtCesion;

        }

        /// <summary>
        /// Obtenemos los datos de la cesión activa (en caso de exisitir) para el medio
        /// </summary>
        /// <param name="oidMedio">identificativo del medio</param>
        /// <returns>devolvemos las fechas de finalización de cesion y de prorroga.</returns>
        public DataTable obtenerDatosCesionMedio(string oidMedio)
        {
            DataTable dtCesion = new DataTable();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.OBTENER_DATOS_CESION_ACTIVA_MEDIO);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, oidMedio);

                IDataReader drCesion = db.ExecuteReader(dbCommand);
                dtCesion.Load(drCesion);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dtCesion;
        }

        /// <summary>
        /// Comprobamos si ya existe un medio con ID asociado al tipo de medio seleccionado
        /// </summary>
        /// <param name="medio">Datos del medio</param>
        /// <returns>true si existe un medio con ID asociado al tipo de medio seleccionado</returns>
        public bool existeIDModeloTipoMedio(Medio medio)
        {
            bool returnValue = false;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.EXISTE_MEDIO_ID_TIPOMEDIO);
                db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, medio.IdMedio);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, medio.OidMedio);
                db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int16, medio.OidTipoMedio);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }

        /// <summary>
        /// Obtenemos los datos asociados a los tipos de medios
        /// </summary>
        /// <returns></returns>
        public DataTable obtenerDatosTiposDeMedios()
        {
            DataTable dtTiposDeMedio = new DataTable(); ;
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader drTiposDeMedio = db.ExecuteReader(Constantes.SELECT_DATOSTIPOSDEMEDIOS);

                dtTiposDeMedio.Load(drTiposDeMedio);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dtTiposDeMedio;
        }

        /// <summary>
        /// Obtenemos si el medio tiene o ha tenido alguna cesión tanto a departamentos
        /// como a empleados
        /// </summary>
        /// <param name="oidMedio">identificativo del medio</param>
        /// <returns></returns>
        public bool tieneCesion(int oidMedio)
        {
            bool result = false;
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.TIENE_CESION);
                db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, oidMedio);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                result = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return result;
        }

        /// <summary>
        /// Obteniene los modelos asociados a la marca
        /// </summary>
        /// <param name="oidMarca">identificativo único por el que se filtrará la selección de modelos</param>
        /// <returns></returns>
        public DataSet obtenerListaModelos(int oidMarca)
        {
            DataSet dsModelos = new DataSet();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader drModelos = db.ExecuteReader(Constantes.SELECT_MODELOS, oidMarca);

                DataTable dtModelos = new DataTable();
                dtModelos.Load(drModelos);

                dsModelos.Tables.Add(dtModelos);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsModelos;

        }
    }
}
