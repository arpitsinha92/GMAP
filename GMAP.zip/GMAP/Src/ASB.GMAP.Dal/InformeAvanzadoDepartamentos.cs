﻿using System;
using System.Data;
using System.Data.Common;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace ASB.GMAP.Dal
{
    public class InformeAvanzadoDepartamentos : Base
    {
        public InformeAvanzadoDepartamentos(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }
     
        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles)
        {
            DataSet dsTiposMedios = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();

                dsTiposMedios = db.ExecuteDataSet(Constantes.LOAD_COMBOS_PERFIL, new object[] { Constantes.TIPOSDEMEDIOS, perfiles });
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsTiposMedios;
        }

        /// <summary>
        /// Obtiene la lista de empresas para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de empresas</returns>
        public DataSet obtenerEmpresas()
        {
            DataSet dsEmpresas = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();

                dsEmpresas = db.ExecuteDataSet(Constantes.LOAD_COMBOS, Constantes.EMPRESAS);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsEmpresas;
        }

        /// <summary>
        /// Busca cesiones a departamentos que cumplan los criterios especificados en los parámetros.
        /// </summary>
        /// <param name="listaEmpresas">Lista separada por comas del los id de empresas</param>
        /// <param name="listaTipoMedios">Lista separada por comas del los id de tipos de medios</param>
        /// <param name="nombre">Nombre del departamento al que se cedió el medio</param>
        /// <param name="codigoMedio">Código del medio</param>
        /// <param name="esCesionActiva">Indica si la cesión está activa</param>
        /// <returns>Un DataSet con las cesiones encontradas</returns>
        public DataSet buscarCesionesDepartamentos(string listaEmpresas, string listaTipoMedios, string nombre, string codigoMedio, int esCesionActiva)
        {
            DataSet dsCesionesDepartamentos = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_DEPARTAMENTOSAVANZADO))
                {
                    db.AddInParameter(dbCommand, Constantes.LISTAEMPRESAS, DbType.String, listaEmpresas);
                    db.AddInParameter(dbCommand, Constantes.LISTATIPOMEDIOS, DbType.String, listaTipoMedios);
                    db.AddInParameter(dbCommand, Constantes.DEPARTAMENTO, DbType.String, nombre);
                    db.AddInParameter(dbCommand, Constantes.IDMEDIO, DbType.String, codigoMedio);
                    db.AddInParameter(dbCommand, Constantes.CESIONESACTIVAS, DbType.Int32, esCesionActiva);

                    dsCesionesDepartamentos = db.ExecuteDataSet(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsCesionesDepartamentos;
        }
    }
}
