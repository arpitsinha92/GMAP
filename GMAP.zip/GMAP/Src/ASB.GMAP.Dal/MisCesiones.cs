﻿using System;
using System.Data;
using System.Data.Common;
using MB.Framework.ManejadorMensajes;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;


namespace ASB.GMAP.Dal
{
    public class MisCesiones : Base
    {
        public MisCesiones(ref MantMensajes mantMensajes)
        {
            base.Manejador = mantMensajes;
        }

        public MisCesiones()
        {
            base.Manejador = new MantMensajes();
        }
        
        /// <summary>
        /// Busca cesiones de médios a empleados que cumplan los criterios especificados
        /// en los parámetros.
        /// </summary>
        /// <param name="numeroEmpleado">Número de identificación del empleado</param>
        /// <param name="idTipoMedio">Tipo de medio cedido</param>
        /// <param name="esActiva">Indica si la cesión está activa</param>
        /// <returns>Un DataSet con las cesiones encontradas</returns>
        public DataSet buscarMisCesiones(string numeroEmpleado, int idTipoMedio, int esActiva)
        {
            DataSet dsMisCesiones = null;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_MISCESIONES))
                {
                    db.AddInParameter(dbCommand, Constantes.NUMEMPLEADO, DbType.String, numeroEmpleado);
                    db.AddInParameter(dbCommand, Constantes.OIDTIPOMEDIO, DbType.Int32, idTipoMedio);
                    db.AddInParameter(dbCommand, Constantes.ESACTIVA, DbType.Int32, esActiva);

                    dsMisCesiones = db.ExecuteDataSet(dbCommand);
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsMisCesiones;
        }

        /// <summary>
        /// Devuelve los tipos de medios cedidos al usuario
        /// </summary>
        /// <param name="numeroEmpleado">Número del empleado del usuario logado</param>
        /// <returns></returns>
        public DataTable cargaComboTipoMedios(string numeroEmpleado)
        {
            DataSet dsTiposMedios = null;
            DataTable dtTiposMedios = null;
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = EnterpriseLibraryContainer.Current.GetInstance<Database>();
                using (DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_MISCESIONESTIPOSMEDIOS))
                {
                    db.AddInParameter(dbCommand, Constantes.NUMEMPLEADO, DbType.String, numeroEmpleado);                    

                    dsTiposMedios = db.ExecuteDataSet(dbCommand);
                    dtTiposMedios = dsTiposMedios.Tables[0];
                }
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dtTiposMedios;
        }
        
    }
}
