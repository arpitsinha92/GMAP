﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class EditarCesion:Base
    {
        public EditarCesion(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }


       
        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la update de la cesión de un medio
        /// a un empleado
        /// </summary>
        /// <param name="cesion">Objeto que contendrá los datos de la cesión a modificar</param>
        /// <returns></returns>
        public int actualizarCesionEmpleado(Cesion cesion)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_CESIONEMPLEADO);
                db.AddInParameter(dbCommand, Constantes.OIDCESION, DbType.Int16, cesion.OidCesion);
                db.AddInParameter(dbCommand, Constantes.FECINICESION, DbType.DateTime, cesion.FecIni);
                db.AddInParameter(dbCommand, Constantes.FECFINCESION, DbType.DateTime, cesion.FecFin.Equals("") ? null : cesion.FecFin);
                db.AddInParameter(dbCommand, Constantes.EMPAUDITORIA, DbType.String, cesion.EmpAuditoria);
                db.AddInParameter(dbCommand, Constantes.FECFINPRORROGA, DbType.DateTime, cesion.FecFinProrroga.Equals("") ? null : cesion.FecFinProrroga);
                db.AddInParameter(dbCommand, Constantes.COMENTARIOSCESION, DbType.String, cesion.Comentarios);

                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la update de la cesión de un medio
        /// a un departamento
        /// </summary>
        /// <param name="cesion">Objeto que contendrá los datos de la cesión a modificar</param>
        /// <returns></returns>
        public int actualizarCesionDepartamento(Cesion cesion)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_CESIONDEPARTAMENTO);
                db.AddInParameter(dbCommand, Constantes.OIDCESION, DbType.Int16, cesion.OidCesion);
                db.AddInParameter(dbCommand, Constantes.FECINICESION, DbType.DateTime, cesion.FecIni);
                db.AddInParameter(dbCommand, Constantes.FECFINCESION, DbType.DateTime, cesion.FecFin.Equals("") ? null : cesion.FecFin);
                db.AddInParameter(dbCommand, Constantes.EMPAUDITORIA, DbType.String, cesion.EmpAuditoria);
                db.AddInParameter(dbCommand, Constantes.FECFINPRORROGA, DbType.DateTime, cesion.FecFinProrroga.Equals("") ? null : cesion.FecFinProrroga);
                db.AddInParameter(dbCommand, Constantes.COMENTARIOSCESION, DbType.String, cesion.Comentarios);

                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        
       
        ///// <summary>
        ///// Obtenemos la cesión activa para el medio y departamento
        ///// </summary>        
        ///// <returns>datable con los datos de la cesión</returns>
        //public DataTable buscarCesionDepartamento(int oidMedio,string id_orgunit)
        //{
        //    DataTable dtCesion = new DataTable();
        //    try
        //    {
        //        Database db = DatabaseFactory.CreateDatabase();
        //        DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_EDICIONCESIONACTIVADEPARTAMENTO);
        //        db.AddInParameter(dbCommand, Constantes.ID_ORGUNIT, DbType.String, id_orgunit);
        //        db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, oidMedio);

        //        IDataReader drCesion = db.ExecuteReader(dbCommand);
        //        dtCesion.Load(drCesion);

        //    }
        //    catch (Exception err)
        //    {
        //        Manejador.agregar(err);
        //    }

        //    return dtCesion;

        //}

        /// <summary>
        /// Obtenemos los datos de la cesión
        /// </summary>
        /// <param name="oidCesion">Identificativo de la cesión</param>
        /// <returns>Datos de la cesión</returns>
        public DataTable buscarCesionDepartamento(int oidCesion)
        {
            DataTable dtCesion = new DataTable();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_EDICIONCESIONDEPARTAMENTO);
                db.AddInParameter(dbCommand, Constantes.OIDCESION, DbType.Int16, oidCesion);

                IDataReader drCesion = db.ExecuteReader(dbCommand);
                dtCesion.Load(drCesion);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dtCesion;

        }

        ///// <summary>
        ///// Obtenemos la cesión activa para el medio y empleado
        ///// </summary>        
        ///// <returns>datable con los datos de la cesión</returns>
        //public DataTable buscarCesionEmpleado(int oidMedio, string strNumEmpleado)
        //{
        //    DataTable dtCesion = new DataTable();
        //    try
        //    {
        //        Database db = DatabaseFactory.CreateDatabase();
        //        DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_EDICIONCESIONACTIVAEMPLEADO);
        //        db.AddInParameter(dbCommand, Constantes.NUMEMPLEADO, DbType.String, strNumEmpleado);
        //        db.AddInParameter(dbCommand, Constantes.OIDMEDIO, DbType.Int16, oidMedio);

        //        IDataReader drCesion = db.ExecuteReader(dbCommand);
        //        dtCesion.Load(drCesion);

        //    }
        //    catch (Exception err)
        //    {
        //        Manejador.agregar(err);
        //    }

        //    return dtCesion;

        //}

        /// <summary>
        /// Obtenemos los datos de la cesión 
        /// </summary>
        /// <param name="oidCesion">Identificativo de la cesión</param>
        /// <returns>Datos de la cesión</returns>
        public DataTable buscarCesionEmpleado(int oidCesion)
        {
            DataTable dtCesion = new DataTable();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.SELECT_EDICIONCESIONEMPLEADO);
                db.AddInParameter(dbCommand, Constantes.OIDCESION, DbType.Int16, oidCesion);

                IDataReader drCesion = db.ExecuteReader(dbCommand);
                dtCesion.Load(drCesion);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dtCesion;

        }
       
    }
}
