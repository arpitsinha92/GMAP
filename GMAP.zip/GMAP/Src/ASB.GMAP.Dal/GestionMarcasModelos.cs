﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Ent;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace ASB.GMAP.Dal
{
    public class GestionMarcasModelos:Base
    {
        public GestionMarcasModelos(ref MantMensajes mantMensajes)
        {
            Manejador = mantMensajes;
        }


        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la insert de una nueva marca
        /// </summary>
        /// <param name="marca">Objeto que contendrá los datos de la nueva marca</param>
        /// <returns></returns>
        public int insertarMarca(Marca marca)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_MARCA);
                db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, marca.Nombre);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, marca.FecBaja.Equals("") ? null : marca.FecBaja);                
                
                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la insert de un nuevo modelo
        /// </summary>
        /// <param name="modelo">Objeto que contendrá los datos del nuevo modelo</param>
        /// <returns></returns>
        public int insertarModelo(Modelo modelo)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.INSERT_MODELO);
                db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, modelo.Nombre);
                db.AddInParameter(dbCommand, Constantes.DESCRIPCION, DbType.String, modelo.Descripcion);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, modelo.OidMarca);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, modelo.FecBaja.Equals("") ? null : modelo.FecBaja);

                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la update de un nuevo modelo
        /// </summary>
        /// <param name="modelo">Objeto que contendrá los datos del modelo a modificar</param>
        /// <returns></returns>
        public int actualizarModelo(Modelo modelo)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_MODELO);
                db.AddInParameter(dbCommand, Constantes.OIDMODELO, DbType.Int16, modelo.OidModelo);
                db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, modelo.Nombre);
                db.AddInParameter(dbCommand, Constantes.DESCRIPCION, DbType.String, modelo.Descripcion);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, modelo.OidMarca);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, modelo.FecBaja.Equals("") ? null : modelo.FecBaja);

                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }

        
        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar la update de la marca seleccionadd
        /// </summary>
        /// <param name="tipoDeMedio">Objeto que contendrá los datos de la marca seleccionada</param>
        /// <returns></returns>
        public int actualizarMarca(Marca marca)
        {
            // Código de error
            int nError = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.UPDATE_MARCA);
                db.AddInParameter(dbCommand, Constantes.NOMBRE,DbType.String, marca.Nombre);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, marca.FecBaja.Equals("")?null:marca.FecBaja);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, marca.OidMarca);
                
                nError = db.ExecuteNonQuery(dbCommand);
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return nError;

        }
        
        
        
        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar el "borrado" de la marca seleccionada
        /// </summary>
        /// <param name="oidMarca">ID de la marca a borrar</param>
        /// <returns></returns>
        public int eliminarMarca(string oidMarca)
        {
            int returnValue = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_MARCA);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, oidMarca);
                db.AddOutParameter(dbCommand, Constantes.RETURNVALUE, DbType.Int16, returnValue);
                
               db.ExecuteNonQuery(dbCommand);
               returnValue = Convert.ToInt16(db.GetParameterValue(dbCommand, Constantes.RETURNVALUE));
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return returnValue;

        }

        /// <summary>
        /// Llamada al procedimiento almacenado encargado de realizar el "borrado" del modelo seleccionado
        /// </summary>
        /// <param name="oidModelo">ID del modelo a borrar</param>
        /// <returns></returns>
        public int eliminarModelo(string oidModelo)
        {
            int returnValue = 0;

            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.DELETE_MODELO);
                db.AddInParameter(dbCommand, Constantes.OIDMODELO, DbType.Int16, oidModelo);
                db.AddOutParameter(dbCommand, Constantes.RETURNVALUE, DbType.Int16, returnValue);

                db.ExecuteNonQuery(dbCommand);
                returnValue = Convert.ToInt16(db.GetParameterValue(dbCommand, Constantes.RETURNVALUE));
            }
            catch (Exception err)
            {
                // Agregamos los errores incontrolados
                Manejador.agregar(err);
            }

            return returnValue;

        }        
        

        /// <summary>
        /// Obtenemos todas las marcas
        /// </summary>        
        /// <returns>Dataset con todas las marcas almacenadas</returns>
        public DataSet buscarMarcas()
        {
            DataSet dsMarcas = new DataSet();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader drMarcas = db.ExecuteReader(Constantes.SELECT_MARCAS);

                DataTable dtMarcas = new DataTable();
                dtMarcas.Load(drMarcas);

                dsMarcas.Tables.Add(dtMarcas);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsMarcas;

        }

        /// <summary>
        /// Obteniene los modelos asociados a la marca
        /// </summary>
        /// <param name="oidMarca">identificativo único por el que se filtrará la selección de modelos</param>
        /// <returns></returns>
        public DataSet buscarModelos(int oidMarca)
        {
            DataSet dsModelos = new DataSet();
            try
            {
                Database db = DatabaseFactory.CreateDatabase();
                IDataReader drModelos = db.ExecuteReader(Constantes.SELECT_MODELOS,oidMarca);

                DataTable dtModelos = new DataTable();
                dtModelos.Load(drModelos);

                dsModelos.Tables.Add(dtModelos);

            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }

            return dsModelos;

        }


        /// <summary>
        /// Comprobamos si ya existe modelo asociado a la marca seleccionada con el mismo nombre
        /// </summary>
        /// <param name="modelo">Datos del modelo</param>
        /// <returns>true si existe un modelo asociado a la marca con el mismo nombre</returns>
        public bool existeNombreMarcaModelo(Modelo modelo)
        {
            bool returnValue = false;
            
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.EXISTE_MARCA_NOMBRE_MODELO);
                db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, modelo.Nombre);
                db.AddInParameter(dbCommand, Constantes.OIDMODELO, DbType.Int16, modelo.OidModelo);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, modelo.OidMarca);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }

        /// <summary>
        /// Obtenemos ya existe una marca con el mismo nombre
        /// </summary>
        /// <param name="marca">datos de la marca</param>
        /// <returns></returns>
        public bool existeNombreMarca(Marca marca)
        {
            bool returnValue = false;
            
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.EXISTE_MARCA);
                db.AddInParameter(dbCommand, Constantes.NOMBRE, DbType.String, marca.Nombre);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, marca.OidMarca);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }

        /// <summary>
        /// Obtenemos si hay modelos asociados a la marca con una fecha de baja posterior a la fecha de baja
        /// de la marca
        /// </summary>
        /// <param name="marca">datos de la marca</param>
        /// <returns></returns>
        public bool tieneModelosDadosDeBaja(Marca marca)
        {
            bool returnValue = false;

            DataSet dsModelos = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.MARCA_CON_MODELOS_BAJA);
                db.AddInParameter(dbCommand, Constantes.OIDMARCA, DbType.Int16, marca.OidMarca);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, marca.FecBaja);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }

         /// <summary>
        /// Obtenemos si hay medios asociados al modelo con una fecha de baja posterior a la fecha de baja
        /// del medio
        /// </summary>
        /// <param name="modelo">datos del modelo</param>
        /// <returns></returns>
        public bool tieneMediosDadosDeBaja(Modelo modelo)
        {
            bool returnValue = false;

            DataSet dsModelos = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.MODELOS_CON_MEDIOS_BAJA);
                db.AddInParameter(dbCommand, Constantes.OIDMODELO, DbType.Int16, modelo.OidModelo);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, modelo.FecBaja);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }

        /// <summary>
        /// Obtenemos si la fecha de baja del medio es posterior a la fecha de baja de la marca a la que pertenece
        /// </summary>
        /// <param name="modelo">datos del modelo</param>
        /// <returns></returns>
        public bool tieneFecBajaPosteriorMarca(Modelo modelo)
        {
            bool returnValue = false;

            DataSet dsModelos = new DataSet();
            try
            {
                // Accedemos a base de datos por la Enterprise Library
                Database db = DatabaseFactory.CreateDatabase();
                DbCommand dbCommand = db.GetStoredProcCommand(Constantes.MODELO_CON_FECBAJA_POSTERIOR_MARCA);
                db.AddInParameter(dbCommand, Constantes.OIDMODELO, DbType.Int16, modelo.OidModelo);
                db.AddInParameter(dbCommand, Constantes.FECBAJA, DbType.DateTime, modelo.FecBaja);
                DbParameter param = dbCommand.CreateParameter();
                param.DbType = DbType.Int16;
                param.ParameterName = Constantes.RETURNVALUE;
                param.Direction = ParameterDirection.ReturnValue;
                dbCommand.Parameters.Add(param);

                db.ExecuteScalar(dbCommand);
                returnValue = Convert.ToBoolean(dbCommand.Parameters[Constantes.RETURNVALUE].Value);
            }
            catch (Exception err)
            {
                Manejador.agregar(err);
            }
            return returnValue;
        }
    }
}
