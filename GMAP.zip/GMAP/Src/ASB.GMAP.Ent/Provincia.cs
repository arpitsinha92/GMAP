﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Provincia
    {
        public int Codigo { get; set; }        
        public string Nombre { get; set; }

        /// <summary>
        /// Constructor de la provincia.
        /// </summary>
        /// <param name="codigo">Código de la provincia.</param>
        /// <param name="nombre">Nombre de la provincia.</param>
        public Provincia(int codigo = 0, string nombre = "")
        {
            this.Codigo = codigo;           
            this.Nombre = nombre;
        }
    }
}
