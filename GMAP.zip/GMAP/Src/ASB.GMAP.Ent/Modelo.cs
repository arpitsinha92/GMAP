﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Modelo
    {
        private int oidModelo;
        public int OidModelo
        {
            get { return oidModelo; }
            set { oidModelo = value; }
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        private string descripcion;
        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        private string fecBaja;
        public string FecBaja
        {
            get { return fecBaja; }
            set { fecBaja = value; }
        }

        private int oidMarca;
        public int OidMarca
        {
            get { return oidMarca; }
            set { oidMarca = value; }
        }
        

        /// <summary>
        /// Constructor del Modelos
        /// </summary>
        /// <param name="oidModelo">Identificador único del Modelo</param>
        /// <param name="nombre">Nombre del Modelo</param>
        /// <param name="descripcion">descripción del modelo</param>
        /// <param name="fecBaja">fecha de baja del modelo</param>
        /// <param name="oidMarca">Identificador único de la marca a la que pertenece el modelo</param>
        public Modelo(int oidModelo, string nombre, string descripcion, string fecBaja, int oidMarca)
        {
            this.OidModelo = oidModelo;
            this.Nombre = nombre;
            this.Descripcion = descripcion;
            this.FecBaja = fecBaja;
            this.OidMarca = oidMarca;
        }

    }
}
