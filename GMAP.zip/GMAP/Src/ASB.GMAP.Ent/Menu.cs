using System;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for CDMenu
/// </summary>
/// 
namespace ASB.GMAP.Ent
{
    public class Menu
    {       
        protected int codigoMenu;
        protected int codigoMenuPadre;
        protected string descripocionMenu;
        protected string url;
        protected int posicion;

        public Menu()
        {            
        }

        #region Propiedades

        /// <summary>
        /// Descripci�n del Menu
        /// </summary>
        public string DescripcionMenu
        {
            get
            {
                return descripocionMenu;
            }
            set
            {
                descripocionMenu = value;
            }
        }

        /// <summary>
        /// C�digo del padre del menu.
        /// </summary>
        public int CodigoMenuPadre
        {
            get
            {
                return codigoMenuPadre;
            }
            set
            {
                codigoMenuPadre = value;
            }
        }

        /// <summary>
        /// Posici�n del nodo del menu.
        /// </summary>
        public int Posicion
        {
            get
            {
                return posicion;
            }
            set
            {
                posicion = value;
            }
        }

        /// <summary>
        /// C�digo del nodo del menu.
        /// </summary>
        public int CodigoMenu
        {
            get
            {
                return codigoMenu;
            }
            set
            {
                codigoMenu = value;
            }
        }

        /// <summary>
        /// Url a la que navega al clicar sobre el nodo.
        /// </summary>
        public string Url
        {
            get
            {
                return url;
            }
            set
            {
                url = value;
            }
        }

        #endregion
    }
}