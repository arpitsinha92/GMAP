﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    [Serializable()]
    public class Accion
    {
        public int IdAccion { get; set; }
        public String Nombre { get; set; }
        public DateTime? FechaBaja { get; set; }

        public Accion(int idAccion = 0,
                      String nombre = null,
                      DateTime? fechaBaja = null)
        {
            this.IdAccion = idAccion;
            this.Nombre = nombre;
            this.FechaBaja = fechaBaja;
        }
    }
}
