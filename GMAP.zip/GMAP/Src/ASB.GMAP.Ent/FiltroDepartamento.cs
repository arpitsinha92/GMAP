﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class FiltroDepartamento
    {
        private string nombreDepartamento;
        public string NombreDepartamento
        {
            get { return nombreDepartamento; }
            set { nombreDepartamento = value; }
        }

        private string empresa;
        public string Empresa
        {
            get { return empresa; }
            set { empresa = value; }
        }

        private int estado;
        public int Estado
        {
            get { return estado; }
            set { estado = value; }
        }
        
        /// <summary>
        /// Constructor del filtro de la búsqueda de departamentos
        /// </summary>
        /// <param name="nombreDept">Nombre del departamento a buscar</param>
        /// <param name="empresa">empresa a la que pertenece el departamento</param>
        /// <param name="estado">estado del departamento</param>
        public FiltroDepartamento(string nombreDept, string empresa, int estado)
        {
            this.NombreDepartamento = nombreDept;
            this.Empresa = empresa;
            this.Estado = estado;      
        }

    }
}
