﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class FiltroPersona
    {
        private int estado;
        public int Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        private string nombreApellidos;
        public string NombreApellidos
        {
            get { return nombreApellidos; }
            set { nombreApellidos = value; }
        }

        private string empresa;
        public string Empresa
        {
            get { return empresa; }
            set { empresa = value; }
        }

        private string tipoContrato;
        public string TipoContrato
        {
            get { return tipoContrato; }
            set { tipoContrato = value; }
        }

        
        /// <summary>
        /// Constructor del filtro de la búsqueda de personas
        /// </summary>
        /// <param name="estado">Estado (activo (0), inactivo(1))</param>
        /// <param name="nombreApellidos">Nombre y apellidos de la  persona</param>
        /// <param name="empresa">empresa</param>
        /// <param name="tipoContrato">Interon o externo</param>
 
        public FiltroPersona(int estado, string nombreApellidos, string empresa, string tipoContrato)
        {
            this.Estado = estado;
            this.NombreApellidos = nombreApellidos;
            this.Empresa = empresa;
            this.tipoContrato = tipoContrato;
        }

    }
}
