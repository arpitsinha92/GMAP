﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class FiltroCesion
    {
        private bool cesionActiva;
        public bool CesionActiva
        {
            get { return cesionActiva; }
            set { cesionActiva = value; }
        }

        private string idMedio;
        public string IdMedio
        {
            get { return idMedio; }
            set { idMedio = value; }
        }

        private int tipoMedio;
        public int TipoMedio
        {
            get { return tipoMedio; }
            set { tipoMedio = value; }
        }

        private string idDestCesion;
        public string IdDestCesion
        {
            get { return idDestCesion; }
            set { idDestCesion = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="cesionActiva">Indica si la cesión está activa o no</param>
        /// <param name="idMedio">ID del Medio</param>
        /// <param name="tipoMedio">Tipo de medio</param>
        /// <param name="idDestCesion">Identificativo del destinatario de la cesión, podrá ser un departamento o un empleado</param>
        public FiltroCesion(bool cesionActiva, string idMedio, int tipoMedio, string idDestCesion)
        {
            this.CesionActiva = cesionActiva;
            this.IdMedio = idMedio;
            this.TipoMedio = tipoMedio;
            this.IdDestCesion = idDestCesion;            
        }

    }
}
