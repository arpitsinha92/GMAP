﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    [Serializable()]
    public class Funcion
    {
        public int IdFuncion { get; set; }
        public String Nombre { get; set; }
        public DateTime? FechaBaja { get; set; }
        public List<TipoDeMedio> TiposDeMedios { get; set; }
        public List<Accion> Acciones { get; set; }

        public Funcion(int idFuncion = 0,
                       String nombre = null,
                       DateTime? fechaBaja = null,
                       List<TipoDeMedio> tiposDeMedios = null,
                       List<Accion> acciones = null)
        {
            this.IdFuncion = idFuncion;
            this.Nombre = nombre;
            this.FechaBaja = fechaBaja;
            this.TiposDeMedios = tiposDeMedios;
            this.Acciones = acciones;
        }
    }
}
