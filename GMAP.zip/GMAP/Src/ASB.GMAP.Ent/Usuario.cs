﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Usuario
    {
        public int? IdUsuario { get; set; }
        public String Nombre { get; set; }
        public String Apellidos { get; set; }
        public DateTime? FechaNacimiento { get; set; }
        public String Dni { get; set; }
        public bool? Activo { get; set; }
        public Departamento Departamento { get; set; }
        public Departamento Subdepartamento { get; set; }
        public char? Sexo { get; set; }

        /// <summary>
        /// Constructor del usuario.
        /// </summary>
        /// <param name="idUsuario">Id del usuario.</param>
        /// <param name="nombre">Nombre del usuario.</param>
        /// <param name="apellidos">Apellidos del usuario.</param>
        /// <param name="fechaNacimiento">Fecha nacimiento del usuario.</param>
        /// <param name="dni">DNI del usuario.</param>
        /// <param name="activo">Activo en la aplicación.</param>
        /// <param name="departamento">Departamento del usuario.</param>
        /// <param name="subdepartamento">Subdepartamento del usuario.</param>
        /// <param name="sexo">Sexo del usuario.</param>
        public Usuario(int? idUsuario = null, 
                         String nombre = null, 
                         String apellidos = null, 
                         DateTime? fechaNacimiento = null,
                         String dni = null,
                         bool? activo = null,
                         Departamento departamento = null,
                         Departamento subdepartamento = null,
                         char? sexo = null)
        {
            this.IdUsuario = idUsuario;
            this.Nombre = nombre;
            this.Apellidos = apellidos;
            this.FechaNacimiento = fechaNacimiento;
            this.Dni = dni;
            this.Activo = activo;
            this.Departamento = departamento;
            this.Subdepartamento = subdepartamento;
            this.Sexo = sexo;
        }

    }
}
