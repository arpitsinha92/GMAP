﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    [Serializable()]
    public class TipoDeMedio
    {
        private int oidTipoMedio;
        public int OidTipoMedio
        {
            get { return oidTipoMedio; }
            set { oidTipoMedio = value; }
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        private string descripcion;
        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        private string fecBaja;
        public string FecBaja
        {
            get { return fecBaja; }
            set { fecBaja = value; }
        }

        private bool esEntregable;
        public bool EsEntregable
        {
            get { return esEntregable; }
            set { esEntregable = value; }
        }

        private bool tieneMarcaModelo;
        public bool TieneMarcaModelo
        {
            get { return tieneMarcaModelo; }
            set { tieneMarcaModelo = value; }
        }
        
        private bool tieneExtension;
        public bool TieneExtension
        {
            get { return tieneExtension; }
            set { tieneExtension = value; }
        }

        private string centroCoste;
        public string CentroCoste
        {
            get { return centroCoste; }
            set { centroCoste = value; }
        }

        /// <summary>
        /// Constructor del tipo de medio
        /// </summary>
        /// <param name="oidTipoMedio">Identificador único del tipo de medio</param>
        /// <param name="nombre">Nombre del tipo de medio</param>
        /// <param name="descripcion">descripción del tipo de medio</param>
        /// <param name="fecBaja">fecha de baja del tipo de medio</param>
        /// <param name="esEntregable">indica si el tipo de medio es entregable una vez cause baja</param>
        /// <param name="tieneMarcaModelo">indica si el tipo de medio tiene asociada la marca y modelo</param>
        /// <param name="tieneExtension">indica si el tipo de medio tiene extensión telefónica</param>
        /// <param name="CentroCoste">Centro de Coste</param>
        public TipoDeMedio(int oidTipoMedio, string nombre, string descripcion, string fecBaja, bool esEntregable, bool tieneMarcaModelo, bool tieneExtension,string centroCoste)
        {
            this.OidTipoMedio = oidTipoMedio;
            this.Nombre = nombre;
            this.Descripcion = descripcion;
            this.FecBaja = fecBaja;
            this.EsEntregable = esEntregable;
            this.TieneMarcaModelo = tieneMarcaModelo;
            this.TieneExtension = tieneExtension;
            this.CentroCoste = centroCoste;
        }

        public TipoDeMedio() { }
        

    }
}
