﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Cesion
    {
        private int oidCesion;
        public int OidCesion
        {
            get { return oidCesion; }
            set { oidCesion = value; }
        }
        
        private string idDestinatarioCesion;
        public string IdDestinatarioCesion
        {
            get { return idDestinatarioCesion; }
            set { idDestinatarioCesion = value; }
        }

        private int oidMedio;
        public int OidMedio
        {
            get { return oidMedio; }
            set { oidMedio = value; }
        }

        private string fecIni;
        public string FecIni
        {
            get { return fecIni; }
            set { fecIni = value; }
        }

        private string fecFin;
        public string FecFin
        {
            get { return fecFin; }
            set { fecFin = value; }
        }

        private string empAuditoria;
        public string EmpAuditoria
        {
            get { return empAuditoria; }
            set { empAuditoria = value; }
        }

        private string nombreEmpAuditoria;
        public string NombreEmpAuditoria
        {
            get { return nombreEmpAuditoria; }
            set { nombreEmpAuditoria = value; }
        }

        private string fecFinProrroga;
        public string FecFinProrroga
        {
            get { return fecFinProrroga; }
            set { fecFinProrroga = value; }
        }

        private string comentarios;
        public string Comentarios
        {
            get { return comentarios; }
            set { comentarios = value; }
        }
        
        /// <summary>
        /// Constructor de Cesión
        /// </summary>
        /// <param name="oidCesion">Identificativo único de la cesión</param>
        /// <param name="idDestinatarioCesion">id del destinatario de la cesión. Puede ser una persona o un departamento</param>
        /// <param name="oidMedio">Identificativo del medio cedido</param>
        /// <param name="fecIni">fecha inicio de la cesión</param>
        /// <param name="fecFin">fecha fin de la cesión</param>
        /// <param name="empAuditoria">ID de la persona que autoriza la prorroga</param>
        /// <param name="nombreEmpAuditoria">Nombre y apellidos de la persona que autoriza la prorroga</param>
        /// <param name="fecFinProrroga">fecha de fin de la prorroga</param>
        /// <param name="comentarios">comentarios de la cesion</param>
        public Cesion(int oidCesion, string idDestinatarioCesion, int oidMedio, string fecIni, string fecFin, string empAuditoria, string nombreEmpAuditoria, string fecFinProrroga, string comentarios)
        {            
            this.OidCesion = oidCesion;
            this.IdDestinatarioCesion = idDestinatarioCesion;
            this.OidMedio = oidMedio;
            this.FecIni = fecIni;
            this.FecFin = fecFin;
            this.EmpAuditoria = empAuditoria;
            this.NombreEmpAuditoria = nombreEmpAuditoria;
            this.FecFinProrroga = fecFinProrroga;
            this.Comentarios = comentarios;

        }

    }
}
