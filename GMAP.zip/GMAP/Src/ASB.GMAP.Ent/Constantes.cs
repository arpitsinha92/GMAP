﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public static class Constantes
    {
        // Número máximo de registros por página
        public const int MAX_POR_PAGINA = 10;
       
        // Menú
        public const string CODIGO_MENU = "INT_OIDMENU";
        public const string CODIGO_MENU_PADRE = "INT_OIDMENUPADRE";
        public const string DESCRIPCION_MENU = "VAR_DESCRIPCION";
        public const string URL = "VAR_URL";
        public const string POSICION = "INT_POSICION";   //Posicion de las opciones de Menú con el mismo padre

    }
}
