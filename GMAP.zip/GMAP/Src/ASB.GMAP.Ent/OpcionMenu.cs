﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    [Serializable()]
    public class OpcionMenu
    {
        public int IdOpcionMenu { get; set; }
        public int? IdOpcionMenuPadre { get; set; }
        public String Descripcion { get; set; }
        public String Url { get; set; }
        public int? Posicion { get; set; }


        public OpcionMenu(int idOpcionMenu = 0,
                          int? idOpcionMenuPadre = null,
                          String descripcion = null,
                          String url = null,
                          int? posicion = null)
        {
            this.IdOpcionMenu = idOpcionMenu;
            this.IdOpcionMenuPadre = idOpcionMenuPadre;
            this.Descripcion = descripcion;
            this.Url = url;
            this.Posicion = posicion;
        }
    }
}
