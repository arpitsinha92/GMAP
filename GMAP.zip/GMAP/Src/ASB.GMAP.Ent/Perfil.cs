﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    [Serializable()]
    public class Perfil
    {
        public int IdPerfil { get; set; }
        public String Nombre { get; set; }
        public DateTime? FechaBaja { get; set; }
        public List<Funcion> Funciones { get; set; }
        public List<OpcionMenu> OpcionesMenu { get; set; }

        public Perfil(int idPerfil = 0,
                      String nombre = null,
                      DateTime? fechaBaja = null,
                      List<Funcion> funciones = null,
                      List<OpcionMenu> opcionesMenu = null)
        {
            this.IdPerfil = idPerfil;
            this.Nombre = nombre;
            this.FechaBaja = fechaBaja;
            this.Funciones = funciones;
            this.OpcionesMenu = opcionesMenu;
        }
    }
}
