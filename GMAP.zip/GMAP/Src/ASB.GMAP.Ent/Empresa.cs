﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Empresa
    {
        private string oidEmpresa;
        public string OidEmpresa
        {
            get { return oidEmpresa; }
            set { oidEmpresa = value; }
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        /// <summary>
        /// Constructor de Empresa
        /// </summary>
        /// <param name="oidEmpresa">Identificador único de la empresa</param>
        /// <param name="nombre">Nombre de la empresa</param>        
        public Empresa(string oidEmpresa, string nombre)
        {
            this.OidEmpresa = oidEmpresa;
            this.Nombre = nombre;                        
        }

    }
}
