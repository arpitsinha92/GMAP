﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Medio
    {
        private int oidMedio;
        public int OidMedio
        {
            get { return oidMedio; }
            set { oidMedio = value; }
        }
        
        private int oidTipoMedio;
        public int OidTipoMedio
        {
            get { return oidTipoMedio; }
            set { oidTipoMedio = value; }
        }

        private int oidModelo;
        public int OidModelo
        {
            get { return oidModelo; }
            set { oidModelo = value; }
        }

        private string idMedio;
        public string IdMedio
        {
            get { return idMedio; }
            set { idMedio = value; }
        }        

        private string fecAlta;
        public string FecAlta
        {
            get { return fecAlta; }
            set { fecAlta = value; }
        }

        private string fecBaja;
        public string FecBaja
        {
            get { return fecBaja; }
            set { fecBaja = value; }
        }

        private string extension;
        public string Extension
        {
            get { return extension; }
            set { extension = value; }
        }

        private string comentarios;
        public string Comentarios
        {
            get { return comentarios; }
            set { comentarios = value; }
        }

        private int oidMarca;
        public int OidMarca
        {
            get { return oidMarca; }
            set { oidMarca = value; }
        }
        private bool libre;
        public bool Libre
        {
            get { return libre; }
            set { libre = value; }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="oidMedio">Identificador único del medio</param>
        /// <param name="oidTipoMedio">Identificador único del tipo de medio al que pertenece el medio</param>
        /// <param name="oidMarca">Identificador único de la marca al que pertenece el modelo</param></param>
        /// <param name="oidModelo">Identificador único del modelo al que pertenece el medio</param>
        /// <param name="idMedio">ID del medio</param>
        /// <param name="fecAlta">fecha de alta del medio</param>
        /// <param name="fecBaja">fecha de baja del medio</param>
        /// <param name="extension">extensión telefónica del medio</param>
        /// <param name="comentarios">comentarios del medio</param>        
        public Medio(int oidMedio, int oidTipoMedio, int oidModelo,int oidMarca, string idMedio, string fecAlta, string fecBaja, string extension, string comentarios)
        {            
            this.OidMedio = oidMedio;
            this.OidTipoMedio = oidTipoMedio;
            this.OidModelo = oidModelo;
            this.OidMarca= oidMarca;
            this.IdMedio = idMedio;
            this.FecAlta = fecAlta;
            this.FecBaja = fecBaja;
            this.Extension = extension;
            this.Comentarios = comentarios;
        }

    }
}
