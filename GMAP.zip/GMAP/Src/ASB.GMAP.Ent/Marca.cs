﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Ent
{
    public class Marca
    {
        private int oidMarca;
        public int OidMarca
        {
            get { return oidMarca; }
            set { oidMarca = value; }
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        private string fecBaja;
        public string FecBaja
        {
            get { return fecBaja; }
            set { fecBaja = value; }
        }

        
        /// <summary>
        /// Constructor de la Marca
        /// </summary>
        /// <param name="oidMarca">Identificador único de la marca</param>
        /// <param name="nombre">Nombre de la marca</param>        
        /// <param name="fecBaja">fecha de baja de la marca</param>        
        public Marca(int oidMarca, string nombre, string fecBaja)
        {
            this.OidMarca = oidMarca;
            this.Nombre = nombre;            
            this.FecBaja = fecBaja;
        }

    }
}
