﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;
using System.Web.UI;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Bll;
using System.Web.UI.HtmlControls;

namespace ASB.GMAP.Web
{
    public class Util
    {

        public static int GetIndex(GridView grd, string fieldName)
        {
            for (int i = 0; i < grd.Columns.Count; i++)
            {
                DataControlField field = grd.Columns[i];

                BoundField bfield = field as BoundField;

                //Assuming accessing happens at data level, e.g with data field's name
                if (bfield != null && bfield.DataField == fieldName)
                    return i;
            }
            return -1;
        }        


        /// <summary>
        /// Para acceder al valor de la celda seleccionada de un grid por el nombre de columna
        /// </summary>
        /// <param name="row">Fila seleccionada del grid</param>
        /// <param name="fieldName">Nombre de la columna de la que se quiere obtener el valor</param>
        /// <returns>Valor de la celda seleccionada</returns>
        public static string GetText(GridViewRow row, string fieldName)
        {
            GridView grd = row.NamingContainer as GridView;
            if (grd != null)
            {
                int index = GetIndex(grd, fieldName);
                if (index != -1)
                    return HttpUtility.HtmlDecode(row.Cells[index].Text);
            }
            return "";
        }

        /// <summary>
        /// Función que habilita los botones permitidos según el perfil
        /// del usuario que accede a la página.
        /// </summary>
        /// <param name="p">Página a la que se desea aplicar las acciones</param>
        public static void aplicarAcciones(Page p)
        {
            if (p.Session[Constantes.ID_PERFIL] != null)
            {
                // Habilitamos los botones permitidos para este usuario
                var botonesHabilitados = obtenerBotonesHabilitados(p);
                if (p.Master != null)
                {
                    // Estamos en una Master Page
                    foreach (Control control in p.Master.Controls)
                    {
                        if (control is HtmlForm)
                        {
                            foreach (Control controlForm in control.Controls)
                            {
                                if (controlForm is ContentPlaceHolder)
                                {
                                    foreach (string boton in botonesHabilitados)
                                    {
                                        var c = (WebControl)controlForm.FindControl(boton);
                                        if (c != null)
                                        {
                                            c.Enabled = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    // Página normal
                    foreach (string boton in botonesHabilitados)
                    {
                        ((WebControl)p.FindControl(boton)).Enabled = true;
                    }
                }
            }
        }

        /// <summary>
        /// Función que intenta habilitar un control según el perfil del
        /// usuario que accede a la página.
        /// </summary>
        /// <param name="control">Control que se desea habilitar</param>
        /// <returns>Indica si se ha llegado a habilitar el control</returns>
        public static bool intentarHabilitar(WebControl control)
        {
            var botonesHabilitados = obtenerBotonesHabilitados(control.Page);

            foreach (string boton in botonesHabilitados)
            {
                if (control.ID == boton)
                {
                    control.Enabled = true;
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Función para obtener una lista de los ids habilitados en una página
        /// según el perfil del usuario que accede a ella.
        /// </summary>
        /// <param name="p">Página de la cual se desea saber los botones habilitados</param>
        /// <returns>Una lista con los ids de los botones permitidos</returns>
        private static List<string> obtenerBotonesHabilitados(Page p)
        {
            var botonesHabilitados = new List<string>();

            var nombrePagina = Path.GetFileNameWithoutExtension(p.Request.PhysicalPath);
            var nombreVariableSession = "botonesHabilitados" + nombrePagina;
            if (p.Session[nombreVariableSession] == null)
            {
                var manejador = new MantMensajes();
                var bll = new GestionAccesos(ref manejador);

                // Obtenemos las acciones permitidas para estos perfiles
                var perfiles = p.Session[Constantes.ID_PERFIL].ToString().Replace(Constantes.SEPARADOR, ",");
                var accionesPerfil = bll.obtenerAccionesPorPerfil(perfiles);

                var rutaXml = p.Server.MapPath(Constantes.RUTA_XML_ACCIONES);
                var xmlDoc = new XmlDocument();
                xmlDoc.Load(rutaXml);

                // Obtenemos los botones habilitados por cada accion permitida
                var paginas = xmlDoc.GetElementsByTagName("paginas");
                var pagina = ((XmlElement)paginas[0]).GetElementsByTagName(nombrePagina);
                var acciones = ((XmlElement)pagina[0]).GetElementsByTagName("accion");
                foreach (string accionPerfil in accionesPerfil)
                {
                    foreach (XmlElement accion in acciones)
                    {
                        if (accionPerfil == accion.GetAttribute("id"))
                        {
                            var botones = accion.GetElementsByTagName("boton");
                            foreach (XmlElement boton in botones)
                            {
                                botonesHabilitados.Add(boton.GetAttribute("id"));
                            }
                            break;
                        }
                    }
                }
            }
            else
            {
                botonesHabilitados = (List<string>)p.Session[nombreVariableSession];
            }

            return botonesHabilitados;
        }
		public static bool tieneAcceso(HttpContext c)
        {
            var nombrePagina = c.Request.RawUrl;

            foreach (string pagina in obtenerPaginasPermitidas(c))
            {
                if (pagina == nombrePagina)
                {
                    return true;
                }
            }

            return false;
        }

        private static List<string> obtenerPaginasPermitidas(HttpContext c)
        {
            var paginasPermitidas = new List<string>();

            var nombreVariableSession = "paginasPermitidas" + c.Session[Constantes.ID_PERFIL].ToString();
            if (c.Session[nombreVariableSession] == null)
            {
                var manejador = new MantMensajes();
                var bll = new GestionAccesos(ref manejador);

                // Obtenemos las paginas permitidas para estos perfiles
                var perfiles = c.Session[Constantes.ID_PERFIL].ToString().Replace(Constantes.SEPARADOR, ",");
                paginasPermitidas = bll.obtenerPaginasPorPerfil(perfiles);
            }
            else
            {
                paginasPermitidas = (List<string>)c.Session[nombreVariableSession];
            }

            return paginasPermitidas;
        }

        public static bool tieneAccesoGestionAlertas(string perfil)
        {
            bool retVal = false;
            var manejador = new MantMensajes();
            var bll = new GestionAccesos(ref manejador);
            retVal = ((List<string>)bll.obtenerPaginasPorPerfil(perfil)).Contains(Constantes.PAG_GESTION_ALERTAS);

            return retVal;
        }
    }
}