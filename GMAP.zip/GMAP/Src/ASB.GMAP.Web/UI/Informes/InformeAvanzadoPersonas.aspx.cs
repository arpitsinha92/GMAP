﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Bll;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web
{
    public partial class InformeAvanzadoPersonas : System.Web.UI.Page
    {
        #region Miembros privados

        protected static ASB.GMAP.Bll.InformeAvanzadoPersonas bll;
        private MantMensajes manejador = new MantMensajes();
        private Dictionary<string, string> filtros = new Dictionary<string, string>();

        #endregion

        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        #region Manejadores de eventos

        protected void btnBuscarCesiones_Click(object sender, EventArgs e)
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            var empresasSeleccionadas = new List<string>();
            foreach (ListItem item in lstEmpresasSeleccionadas.Items)
            {
                empresasSeleccionadas.Add("'" + item.Value + "'");
            }

            var mediosSeleccionados = new List<string>();
            if (lstMediosSeleccionados.Items.Count > 0)
            {
                foreach (ListItem item in lstMediosSeleccionados.Items)
                {
                    mediosSeleccionados.Add(item.Value);
                }
            }
            else
            {
                foreach (ListItem item in lstMedios.Items)
                {
                    mediosSeleccionados.Add(item.Value);
                }
            }

            // Variablen en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            ViewState["cesionesPersonas"] = bll.buscarCesionesPersonas(String.Join(",", empresasSeleccionadas),
                                                                       String.Join(",", mediosSeleccionados),
                                                                       txtPersona.Text,
                                                                       txtID.Text,
                                                                       ddlTipoContrato.SelectedValue,
                                                                       Convert.ToInt32(ddlEstadoPersona.SelectedValue),
                                                                       Convert.ToInt32(chkCesionesNoActivas.Checked),
                                                                       out numRegistros);

            guardarFiltros(empresasSeleccionadas);
            GridViewSortExpression = "";
            recargarGrid();

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnDescargarExcel_Click(object sender, EventArgs e)
        {
            // Recuperamos los filtros de la consulta
            filtros = (Dictionary<string, string>)ViewState["filtros"];

            var cesionesPersonas = (DataSet)ViewState["cesionesPersonas"];

            var exportador = new ExportadorExcel(cesionesPersonas.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELA), filtros, lblTitulo.Text);
            exportador.Mapeos = bll.obtenerMapeosExcel();
            exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
            var bytes = exportador.exportarExcel();

            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
            Response.BinaryWrite(bytes);
            Response.End();
        }

        protected void btnSeleccionarEmpresa_Click(object sender, EventArgs e)
        {
            if (lstEmpresas.SelectedIndex > -1)
            {
                var empresasSeleccionadas = new SortedList<string, string>();

                foreach (ListItem itemOrigen in lstEmpresas.Items)
                {
                    if (itemOrigen.Selected)
                    {
                        empresasSeleccionadas.Add(itemOrigen.Text, itemOrigen.Value);
                    }
                }

                // Borramos del origen las empresas seleccionadas
                foreach (string text in empresasSeleccionadas.Keys)
                {
                    lstEmpresas.Items.Remove(new ListItem(text, empresasSeleccionadas[text]));
                }

                foreach (ListItem empresa in lstEmpresasSeleccionadas.Items)
                {
                    empresasSeleccionadas.Add(empresa.Text, empresa.Value);
                }

                lstEmpresasSeleccionadas.DataSource = empresasSeleccionadas;
                lstEmpresasSeleccionadas.DataValueField = "Value";
                lstEmpresasSeleccionadas.DataTextField = "Key";
                lstEmpresasSeleccionadas.DataBind();
            }
        }

        protected void btnDeseleccionarEmpresa_Click(object sender, EventArgs e)
        {
            if (lstEmpresasSeleccionadas.SelectedIndex > -1)
            {
                var empresasSeleccionadas = new SortedList<string, string>();

                foreach (ListItem itemOrigen in lstEmpresasSeleccionadas.Items)
                {
                    if (itemOrigen.Selected)
                    {
                        empresasSeleccionadas.Add(itemOrigen.Text, itemOrigen.Value);
                    }
                }

                // Borramos del origen las empresas seleccionadas
                foreach (string text in empresasSeleccionadas.Keys)
                {
                    lstEmpresasSeleccionadas.Items.Remove(new ListItem(text, empresasSeleccionadas[text]));
                }

                foreach (ListItem empresa in lstEmpresas.Items)
                {
                    empresasSeleccionadas.Add(empresa.Text, empresa.Value);
                }

                lstEmpresas.DataSource = empresasSeleccionadas;
                lstEmpresas.DataValueField = "Value";
                lstEmpresas.DataTextField = "Key";
                lstEmpresas.DataBind();
            }
        }

        protected void btnSeleccionarTodasEmpresas_Click(object sender, EventArgs e)
        {
            var empresasSeleccionadas = new SortedList<string, string>();

            foreach (ListItem itemOrigen in lstEmpresas.Items)
            {
                empresasSeleccionadas.Add(itemOrigen.Text, itemOrigen.Value);
            }

            lstEmpresas.Items.Clear();

            foreach (ListItem empresa in lstEmpresasSeleccionadas.Items)
            {
                empresasSeleccionadas.Add(empresa.Text, empresa.Value);
            }

            lstEmpresasSeleccionadas.DataSource = empresasSeleccionadas;
            lstEmpresasSeleccionadas.DataValueField = "Value";
            lstEmpresasSeleccionadas.DataTextField = "Key";
            lstEmpresasSeleccionadas.DataBind();
        }

        protected void btnDeseleccionarTodasEmpresas_Click(object sender, EventArgs e)
        {
            var empresasSeleccionadas = new SortedList<string, string>();

            foreach (ListItem itemOrigen in lstEmpresasSeleccionadas.Items)
            {
                empresasSeleccionadas.Add(itemOrigen.Text, itemOrigen.Value);
            }

            lstEmpresasSeleccionadas.Items.Clear();

            foreach (ListItem empresa in lstEmpresas.Items)
            {
                empresasSeleccionadas.Add(empresa.Text, empresa.Value);
            }

            lstEmpresas.DataSource = empresasSeleccionadas;
            lstEmpresas.DataValueField = "Value";
            lstEmpresas.DataTextField = "Key";
            lstEmpresas.DataBind();
        }

        protected void btnSeleccionarMedio_Click(object sender, EventArgs e)
        {
            if (lstMedios.SelectedIndex > -1)
            {
                var mediosSeleccionados = new SortedList<string, string>();

                foreach (ListItem itemOrigen in lstMedios.Items)
                {
                    if (itemOrigen.Selected)
                    {
                        mediosSeleccionados.Add(itemOrigen.Text, itemOrigen.Value);
                    }
                }

                foreach (string text in mediosSeleccionados.Keys)
                {
                    lstMedios.Items.Remove(new ListItem(text, mediosSeleccionados[text]));
                }

                foreach (ListItem medio in lstMediosSeleccionados.Items)
                {
                    mediosSeleccionados.Add(medio.Text, medio.Value);
                }

                lstMediosSeleccionados.DataSource = mediosSeleccionados;
                lstMediosSeleccionados.DataValueField = "Value";
                lstMediosSeleccionados.DataTextField = "Key";
                lstMediosSeleccionados.DataBind();
            }
        }

        protected void btnDeseleccionarMedio_Click(object sender, EventArgs e)
        {
            if (lstMediosSeleccionados.SelectedIndex > -1)
            {
                var mediosSeleccionados = new SortedList<string, string>();

                foreach (ListItem itemOrigen in lstMediosSeleccionados.Items)
                {
                    if (itemOrigen.Selected)
                    {
                        mediosSeleccionados.Add(itemOrigen.Text, itemOrigen.Value);
                    }
                }

                foreach (string text in mediosSeleccionados.Keys)
                {
                    lstMediosSeleccionados.Items.Remove(new ListItem(text, mediosSeleccionados[text]));
                }

                foreach (ListItem medio in lstMedios.Items)
                {
                    mediosSeleccionados.Add(medio.Text, medio.Value);
                }

                lstMedios.DataSource = mediosSeleccionados;
                lstMedios.DataValueField = "Value";
                lstMedios.DataTextField = "Key";
                lstMedios.DataBind();
            }
        }

        protected void btnSeleccionarTodosMedio_Click(object sender, EventArgs e)
        {
            var mediosSeleccionados = new SortedList<string, string>();

            foreach (ListItem itemOrigen in lstMedios.Items)
            {
                mediosSeleccionados.Add(itemOrigen.Text, itemOrigen.Value);
            }

            lstMedios.Items.Clear();

            foreach (ListItem medio in lstMediosSeleccionados.Items)
            {
                mediosSeleccionados.Add(medio.Text, medio.Value);
            }

            lstMediosSeleccionados.DataSource = mediosSeleccionados;
            lstMediosSeleccionados.DataValueField = "Value";
            lstMediosSeleccionados.DataTextField = "Key";
            lstMediosSeleccionados.DataBind();
        }

        protected void btnDeseleccionarTodosMedio_Click(object sender, EventArgs e)
        {
            var mediosSeleccionados = new SortedList<string, string>();

            foreach (ListItem itemOrigen in lstMediosSeleccionados.Items)
            {
                mediosSeleccionados.Add(itemOrigen.Text, itemOrigen.Value);
            }

            lstMediosSeleccionados.Items.Clear();

            foreach (ListItem medio in lstMedios.Items)
            {
                mediosSeleccionados.Add(medio.Text, medio.Value);
            }

            lstMedios.DataSource = mediosSeleccionados;
            lstMedios.DataValueField = "Value";
            lstMedios.DataTextField = "Key";
            lstMedios.DataBind();
        }

        protected void gvCesiones_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                recargarGrid(e.NewPageIndex);
            }
        }

        #endregion

        #region Funciones auxiliares

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_INFORME_AVANZADO_PERSONAS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new Bll.InformeAvanzadoPersonas(ref manejador);

            // Aplicamos las acciones segun el perfil del usuario
            Util.aplicarAcciones(this);

            btnDescargarExcel.Enabled = false;

            inicializarCombos();

            // Es la variable que contiene la jerarquía de llamadas. Al estar en un página "padre" vaciamos dicha variable
            Session[Constantes.VENTANAPADRE] = null;
            Session[Constantes.VENTANAANTERIOR] = null;
            Session[Constantes.PARAMETROS] = null;

            // Inicializamos los filtros para la exportación Excel
            filtros.Add(lblEmpresas.Text, String.Empty);
            filtros.Add(lblMedios.Text, String.Empty);
            filtros.Add(lblPersona.Text, String.Empty);
            filtros.Add(lblID.Text, String.Empty);
            filtros.Add(lblTipoContrato.Text, String.Empty);
            filtros.Add(lblEstadoPersona.Text, String.Empty);
            filtros.Add(chkCesionesNoActivas.Text, String.Empty);

            ViewState["filtros"] = filtros;
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;
           
           
        }

        private void inicializarCombos()
        {
            // Cargar el listbox de tipos de medios
            int numeroRegistrosEmpresas = 0;

            lstEmpresas.DataSource = bll.obtenerEmpresas(out numeroRegistrosEmpresas);
            lstEmpresas.DataValueField = "intCodigo";
            lstEmpresas.DataTextField = "strCodigo";
            lstEmpresas.DataBind();

            // Cargar el listbox de tipos de medios
            int numeroRegistrosMedios = 0;

            lstMedios.DataSource = bll.obtenerTiposMedios(Session[Constantes.ID_PERFIL].ToString(), out numeroRegistrosMedios);
            lstMedios.DataValueField = "intCodigo";
            lstMedios.DataTextField = "strDescripcion";
            lstMedios.DataBind();

            // Para el combo de Tipo de Contrato no tenemos tabla maestra por lo tanto introducimos los valores
            ddlTipoContrato.Items.Clear();
            ddlTipoContrato.Items.Add(new ListItem("Todos/as", ""));
            ddlTipoContrato.Items.Add(new ListItem("Interno", "Interno"));
            ddlTipoContrato.Items.Add(new ListItem("Externo", "Externo"));

            // Para el combo de CedidosA no tenemos tabla maestra por lo tanto introducimos los valores
            ddlEstadoPersona.Items.Clear();
            ddlEstadoPersona.Items.Add(new ListItem("Todos/as", "-1"));
            ddlEstadoPersona.Items.Add(new ListItem("Activas", "1"));
            ddlEstadoPersona.Items.Add(new ListItem("No Activas", "0"));
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        private void guardarFiltros(List<string> empresasSeleccionadas)
        {
            // Guardamos los filtros usados en la consulta
            if (ViewState["filtros"] != null)
            {
                filtros = (Dictionary<string, string>)ViewState["filtros"];
            }

            filtros[lblEmpresas.Text] = String.Join(", ", empresasSeleccionadas);
            var textos = new List<string>();
            foreach (ListItem item in lstMediosSeleccionados.Items)
            {
                textos.Add(item.Text);
            }
            filtros[lblMedios.Text] = String.Join(", ", textos);
            filtros[lblPersona.Text] = txtPersona.Text;
            filtros[lblID.Text] = txtID.Text;
            filtros[lblTipoContrato.Text] = ddlTipoContrato.SelectedItem.Text;
            filtros[lblEstadoPersona.Text] = ddlEstadoPersona.SelectedItem.Text;
            filtros[chkCesionesNoActivas.Text] = chkCesionesNoActivas.Checked ? "Si" : "No";

            ViewState["filtros"] = filtros;
        }

        private void recargarGrid()
        {
            gvCesiones.DataSource = ViewState["cesionesPersonas"];
            gvCesiones.DataBind();

            if (gvCesiones.Rows.Count > 0)
            {
                Util.intentarHabilitar(btnDescargarExcel);
            }
            else
            {
                btnDescargarExcel.Enabled = false;
            }
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        #endregion

        private void recargarGrid(int numPage)
        {
            DataTable dataTable = ((DataSet)ViewState["cesionesPersonas"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpression))
                {
                    dataView.Sort = GridViewSortExpression + " " + GridViewSortDirection;
                }
                gvCesiones.PageIndex = numPage;
                gvCesiones.DataSource = dataView;
                gvCesiones.DataBind();
            }

            if (gvCesiones.Rows.Count > 0)
            {
                Util.intentarHabilitar(btnDescargarExcel);
            }
            else
            {
                btnDescargarExcel.Enabled = false;
            }
        }

        protected void gvCesiones_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["cesionesPersonas"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpression(e.SortExpression);

                gvCesiones.DataSource = dataView;
                gvCesiones.DataBind();
            }
        }

        private string GetSortExpression(string sortExpression)
        {
            if (sortExpression == GridViewSortExpression && GridViewSortDirection == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpression = sortExpression;
            return sortExpression + " " + GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirection"] = value; }
        }
        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }

        protected void gvCesiones_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpression)
                        {
                            if (GridViewSortDirection.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }
    }
}