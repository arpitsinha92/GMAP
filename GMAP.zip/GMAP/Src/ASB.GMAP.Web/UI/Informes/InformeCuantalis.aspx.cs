﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using ASB.GMAP.Bll;

namespace ASB.GMAP.Web
{
    public partial class InformeCuantalis : System.Web.UI.Page
    {
        #region Miembros privados

        protected static ASB.GMAP.Bll.InformeCuantalis bll;
        private MantMensajes manejador = new MantMensajes();
        private Dictionary<string, string> filtros = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session["LOGINUSUARIO"] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED, false);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        #region Manejadores de eventos

        protected void btnInforme_Click(object sender, EventArgs e)
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            if (Page.IsValid)
            {
                DateTime fechaInicio = Convert.ToDateTime(txtFechaInicio.Text);
                DateTime fechaFin = Convert.ToDateTime(txtFechaFin.Text);

                var nombreTipoMedio = "Todos";

                int idTipoMedio = -1;
                if (chkTodos.Checked == true)
                {
                    idTipoMedio = 0;
                }
                else
                {
                    foreach (GridViewRow fila in gvMedios.Rows)
                    {
                        CheckBox checkBox = (CheckBox)fila.FindControl("chkSeleccionado");
                        if (checkBox != null && checkBox.Checked == true)
                        {
                            idTipoMedio = Convert.ToInt32(gvMedios.DataKeys[fila.RowIndex].Values["IdTipoMedio"]);
                            nombreTipoMedio = Util.GetText(fila, "VAR_NOMBRE");
                        }
                    }
                }

                if (idTipoMedio != -1)
                {
                    //filtros.Add(lblFechaInicio.Text, txtFechaInicio.Text);
                    //filtros.Add(lblFechaFin.Text, txtFechaFin.Text);
                    //filtros.Add("Tipos de Medios:", nombreTipoMedio);

                    int numeroRegistros = 0;
                    var informeCuantalis = bll.generarInforme(fechaInicio, fechaFin, idTipoMedio, out numeroRegistros);

                    mensajes = bll.mostrarMensajes(ref hayMensajes);

                    if (hayMensajes)
                        mostrarPopUp(mensajes.Mensaje);
                    else
                    {

                        if (informeCuantalis != null)
                        {
                            var exportador = new ExportadorExcel(informeCuantalis.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELA), filtros, lblTitulo.Text);
                            exportador.Mapeos = bll.obtenerMapeosExcel();
                            exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
                            var bytes = exportador.exportarExcelIbatis();


                            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
                            Response.BinaryWrite(bytes);
                            Response.End();
                        }
                        else
                        {
                            mostrarPopUp("No se han obtenido datos.");
                        }
                    }
                                        
                }
                else
                {
                    mostrarPopUp("Debe seleccionar al menos un tipo de medio");
                }
            }
        }

        #endregion

        #region Funciones auxiliares

        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_INFORMA_CUANTALIS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.InformeCuantalis(ref manejador);

            // Aplicamos las acciones segun el perfil del usuario
            Util.aplicarAcciones(this);

            txtFechaInicio.Text = DateTime.Now.ToShortDateString();
            txtFechaFin.Text = DateTime.Now.ToShortDateString();

            cargarTiposMedios();
            Session["estadoPantallaPersonasDepartamentosMediosAlertas"] = null;
           
           
        }

        private void cargarTiposMedios()
        {
            var numeroRegistros = 0;

            gvMedios.DataSource = bll.obtenerTiposMedios(Session["intIDPerfil"].ToString(), out numeroRegistros);
            gvMedios.DataBind();

            // Actualizamos el número de tipos de medios
            lblNumeroTipoMedios.Text = numeroRegistros.ToString();
        }

        /// <summary>
        /// Muestra los mensajes que se producen al cargar la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MensajesEntidad> mensajes = new List<MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        #endregion
    }
}