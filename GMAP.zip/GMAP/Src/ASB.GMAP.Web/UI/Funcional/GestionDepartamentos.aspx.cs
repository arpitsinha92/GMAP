﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Bll;
using ASB.GMAP.Ent;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web
{
    public partial class GestionDepartamentos : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.GestionDepartamentos bll;
        private MantMensajes manejador = new MantMensajes();
        private Dictionary<string, string> filtros = new Dictionary<string, string>();

        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_GESTION_DEPARTAMENTOS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.GestionDepartamentos(ref manejador);

            // Aplicamos las acciones segun el perfil del usuario
            Util.aplicarAcciones(this);

            btnAnadirCesion.Enabled = false;
            btnEditarCesion.Enabled = false;
            btnEditarMedio.Enabled = false;
            btnFinalizarCesion.Enabled = false;
            btnExcel.Enabled = false;

            inicializarCombos();

            //es la variable que contiene la jerarquía de llamadas. Al estar en un página "padre" vaciamos dicha variable
            Session[Constantes.VENTANAPADRE] = null;
            Session[Constantes.VENTANAANTERIOR] = null;
            Session[Constantes.PARAMETROS] = null;

            // Inicializamos los filtros para la exportación Excel
            filtros.Add(lblNombre1.Text, String.Empty);
            filtros.Add(lblEmpresa.Text, String.Empty);
            filtros.Add(lblCedidoA.Text, String.Empty);
            filtros.Add(lblFiltroID.Text, String.Empty);
            filtros.Add(lblTipoMedio.Text, String.Empty);
            filtros.Add(chkCesiones.Text, String.Empty);

            ViewState["filtros"] = filtros;
            presentarPantalla();
           
           
        }

        /// <summary>
        /// Si venimos de vuelta a la pantalla de alguna de sus paginas "hijas" cargamos el estado de la pantalla
        /// </summary>
        private void presentarPantalla()
        {
            if (Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] != null && Session[Constantes.MIGAS_PAN].ToString().Contains(Constantes.MIGAS_PAN_GESTION_DEPARTAMENTOS))
            {
                Hashtable hParametros = (Hashtable)Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS];

                txtDepartamento.Text = hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_NOMBRE].ToString();
                ddlEmpresa.SelectedValue = hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_EMPRESA].ToString();
                btnBuscar_Click(null, null);
                recargaGridEmpresaPaginacion(Convert.ToInt16(hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_PAGINA_GRID]));

                txtID.Text = hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_ID].ToString();
                ddlTipoMedio.SelectedValue = hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_TIPO_MEDIO].ToString();
                chkCesiones.Checked = Convert.ToBoolean(hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_CESIONES_ACTIVAS]);

                hOidDestCesion.Value = hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_REGISTRO_SELECCIONADO].ToString();
                seleccionarDepartamento(hOidDestCesion.Value);

                recargaGridCesionesPaginacion(Convert.ToInt16(hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_PAGINA_CESIONES]));

               

            }
           
                Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;
            
        }

        /// <summary>
        /// Al volver de una pagina hija seleccionamos el departamento que estuviera seleccionado anteriormenteo
        /// </summary>
        private void seleccionarDepartamento(string oidDept)
        {
            foreach (GridViewRow di in grdEmpresa.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChkEmpresa");

                if (oidDept.Equals(grdEmpresa.DataKeys[di.RowIndex].Values["id_orgunit"].ToString()))
                {
                    chkBx.Checked = true;
                    grdChkEmpresa_CheckedChanged(chkBx, null);
                    break;
                }
            }
        }

        private void inicializarCombos()
        {
            Combos.cargarCombosDesc(Constantes.EMPRESASDESC, ddlEmpresa, true);
            Combos.cargarCombosDescPerfil(Constantes.TIPOSDEMEDIOS, ddlTipoMedio, Session[Constantes.ID_PERFIL].ToString(), true);

            ddlEstado.Items.Add(new ListItem(Constantes.TEXTO_DEFECTO_COMBO, Constantes.VALOR_DEFECTO_COMBO_ESTADO_DEPT));
            ddlEstado.Items.Add(new ListItem("Activo", "0"));
            ddlEstado.Items.Add(new ListItem("Inactivo", "-1"));
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);

            }
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int numRegistros = 0;
            //Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            //perdure a los postback de paginación
            FiltroDepartamento filDept = new FiltroDepartamento(txtDepartamento.Text, ddlEmpresa.SelectedValue,Convert.ToInt16(ddlEstado.SelectedValue));
            ViewState["dsGridDepartamentos"] = bll.buscarDepartamentos(filDept, out numRegistros);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            GridViewSortExpressionEmpresa = "";
            grdEmpresa.DataSource = ViewState["dsGridDepartamentos"];
            grdEmpresa.DataBind();
            if (numRegistros > 0)
            {
                Util.intentarHabilitar(btnAnadirCesion);
            }
            else
            {
                btnAnadirCesion.Enabled = false;
            }

            // Guardamos los filtros usados en la consulta
            if (ViewState["filtros"] != null)
            {
                filtros = (Dictionary<string, string>)ViewState["filtros"];
            }
            filtros[lblNombre1.Text] = txtDepartamento.Text;
            filtros[lblEmpresa.Text] = ddlEmpresa.SelectedItem.Text;

            ViewState["filtros"] = filtros;

            //Limpiamos todo lo referente a cesiones
            limpiarCesiones();

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        private void limpiarCesiones()
        {
            txtID.Text = "";
            chkCesiones.Checked = false;
            grdCesiones.EmptyDataText = String.Empty;
            grdCesiones.DataSource = null;
            grdCesiones.DataBind();
            lblDestCesion.Text = "";
            ddlTipoMedio.SelectedIndex = 0;
            btnExcel.Enabled = false;
            btnEditarCesion.Enabled = false;
            btnEditarMedio.Enabled = false;
            btnFinalizarCesion.Enabled = false;
            btnFiltrarCesiones.Enabled = false;
        }

        protected void btnFiltrarCesiones_Click(object sender, EventArgs e)
        {
            filtrarCesiones();
        }

        private void filtrarCesiones()
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int numRegistros = 0;
            //Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            //perdure a los postback de paginación
            FiltroCesion filCesion = new FiltroCesion(!chkCesiones.Checked, txtID.Text, Convert.ToInt16(ddlTipoMedio.SelectedValue), hOidDestCesion.Value);
            ViewState["dsGridCesiones"] = bll.buscarCesiones(filCesion, Session[Constantes.ID_PERFIL].ToString(), out numRegistros);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            GridViewSortExpressionCesiones = "";
            grdCesiones.EmptyDataText = Constantes.GRIDVACIO;
            grdCesiones.DataSource = ViewState["dsGridCesiones"];
            grdCesiones.DataBind();
            if (numRegistros > 0)
            {
                Util.intentarHabilitar(btnEditarCesion);
                Util.intentarHabilitar(btnEditarMedio);
                Util.intentarHabilitar(btnFinalizarCesion);
                Util.intentarHabilitar(btnExcel);
            }
            else
            {
                btnEditarCesion.Enabled = false;
                btnEditarMedio.Enabled = false;
                btnFinalizarCesion.Enabled = false;
                btnExcel.Enabled = false;
            }

            // Guardamos los filtros usados en la consulta
            if (ViewState["filtros"] != null)
            {
                filtros = (Dictionary<string, string>)ViewState["filtros"];
            }
            filtros[lblCedidoA.Text] = lblDestCesion.Text;
            filtros[lblFiltroID.Text] = txtID.Text;
            filtros[lblTipoMedio.Text] = ddlTipoMedio.SelectedItem.Text;
            filtros[chkCesiones.Text] = chkCesiones.Checked ? "Si" : "No";

            ViewState["filtros"] = filtros;

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void grdChkEmpresa_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            bool sel = false;
            if (chk != null)
            {
                if (chk.Checked)
                {
                    //obtenemos el empleado seleccionado para filtrar sus cesiones
                    foreach (GridViewRow di in grdEmpresa.Rows)
                    {
                        CheckBox chkBx = (CheckBox)di.FindControl("grdChkEmpresa");

                        if (chkBx != null && chkBx.Checked)
                        {
                            int numCaracteres = grdEmpresa.DataKeys[di.RowIndex].Values["departamentoEntero"].ToString().Length;
                            if (numCaracteres > 100)
                            {
                                lblDestCesion.Text = grdEmpresa.DataKeys[di.RowIndex].Values["departamentoEntero"].ToString().Substring(0, 100);
                            }
                            else
                            {
                                lblDestCesion.Text = grdEmpresa.DataKeys[di.RowIndex].Values["departamentoEntero"].ToString();
                            }
                            hOidDestCesion.Value = grdEmpresa.DataKeys[di.RowIndex].Values["id_orgunit"].ToString();
                            break;
                        }
                    }
                    btnFiltrarCesiones.Enabled = true;
                    filtrarCesiones();
                }
                else
                {
                    //si no hay ningun registro seleccionado limpiamos la pantalla.
                    foreach (GridViewRow di in grdEmpresa.Rows)
                    {
                        CheckBox chkBx = (CheckBox)di.FindControl("grdChkEmpresa");
                        //comprobamos que no haya nigun registro seleccionado
                        if (chkBx != null && chkBx.Checked)
                        {
                            sel = true;
                            break;
                        }
                    }
                    if (!sel)
                    {
                        limpiarCesiones();
                    }
                }
            }
        }

        protected void btnAnadirCesion_Click(object sender, EventArgs e)
        {
            
            if (esDepartamentoActivo())
            {
                //Preparamos los parametros para pasar a la pantalla
                parametrosAnadirCesion();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("CesionMedioDisponible.aspx");
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJE_DEPARTAMENTO_ACTIVO);
            }
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Añadir Cesión
        /// </summary>
        private void parametrosAnadirCesion()
        {
            //Creamos una hashtable con los parámetros a pasar
            Hashtable hParams = new Hashtable();
            hParams.Add(Constantes.OIDDEPARTAMENTO, hOidDestCesion.Value);
            hParams.Add(Constantes.NOMBREDEPARTAMENTO, lblDestCesion.Text);
            //Para distinguir que la cesión es a departamento y no a empleado.
            hParams.Add(Constantes.OIDEMPLEADO, "");            
            Session[Constantes.PARAMETROS] = hParams;
            Session[Constantes.MIGAS_PAN] = Constantes.MIGAS_PAN_GESTION_DEPARTAMENTOS;
        }

        protected void btnEditarCesion_Click(object sender, EventArgs e)
        {
            if (esCesionActiva())
            {
                parametrosEditarCesion();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("EditarCesion.aspx");
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }

        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Editar Cesión
        /// </summary>
        private void parametrosEditarCesion()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesiones();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de cesión
            hParametros.Add(Constantes.OIDDEPARTAMENTO, hOidDestCesion.Value);
            hParametros.Add(Constantes.NOMDEPARTAMENTO, lblDestCesion.Text);
            //Como estamos en la pantalla de gestión de departamentos pasamos el identificativo de empleado vacio
            //De esta manera en la pantalla de edición de cesión ya se sabe que es una cesión a un departamento
            hParametros.Add(Constantes.OIDEMPLEADO, "");
            hParametros.Add(Constantes.NOMEMPLEADO, "");

            Session[Constantes.PARAMETROS] = hParametros;
        }

        /// <summary>
        /// Obtenemos los datos de la cesión seleccionada para pasar los parámetros a las distintas pantallas
        /// </summary>
        /// <returns>Hastable con los datos de la cesión seleccionada</returns>
        private Hashtable obtenerDatosGridCesiones()
        {
            Hashtable hParametros = new Hashtable();
            //obtenemos el empleado seleccionado para filtrar sus cesiones
            foreach (GridViewRow di in grdCesiones.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    hParametros.Add(Constantes.TIPOMEDIO, grdCesiones.DataKeys[di.RowIndex].Values["nombreTipoMedioEntero"].ToString());
                    hParametros.Add(Constantes.MODELO, grdCesiones.DataKeys[di.RowIndex].Values["nombreModeloEntero"].ToString());
                    hParametros.Add(Constantes.IDMEDIO, grdCesiones.DataKeys[di.RowIndex].Values["var_codigomedioEntero"].ToString());
                    hParametros.Add(Constantes.OIDCESION, grdCesiones.DataKeys[di.RowIndex].Values["int_oidcesiondepartamento"].ToString());
                    hParametros.Add(Constantes.OIDMEDIO, grdCesiones.DataKeys[di.RowIndex].Values["int_oidmedio"].ToString());
                    hParametros.Add(Constantes.FBAJAMEDIO, grdCesiones.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString());
                    break;
                }
            }
            Session[Constantes.MIGAS_PAN] = Constantes.MIGAS_PAN_GESTION_DEPARTAMENTOS;
            return hParametros;
        }

        /// <summary>
        ///Creamos una estructura lifo, de tal manera que se puedan recuperar las ventanas llamadoras hacia atrás
        /// </summary>
        //private void crearPilaVentanaLlamadora()
        //{
        //    Stack<string> stack = new Stack<string>();
        //    stack.Push("GestionDepartamentos.aspx");
        //    Session[Constantes.VENTANALLAMADORA] = stack;
        //}

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        protected void btnFinalizarCesion_Click(object sender, EventArgs e)
        {
            if (esCesionActiva())
            {

                parametrosFinalizarCesion();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("FinalizarCesion.aspx");
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        /// <summary>
        /// Comprueba si la cesión seleccionada está activa o no
        /// </summary>
        /// <returns>true o false en función si la cesión está activa o no</returns>
        private bool esCesionActiva()
        {
            bool activa = false;
            foreach (GridViewRow di in grdCesiones.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos si la cesión está activa o no
                    activa = Util.GetText(di, "activo").Equals("Si") ? true : false;
                    break;
                }
            }
            return activa;
        }

        /// <summary>
        /// Comprueba si el departamento está activa o no
        /// </summary>
        /// <returns>true si el departamento está activo</returns>
        private bool esDepartamentoActivo()
        {
            bool activa = false;
            foreach (GridViewRow di in grdEmpresa.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChkEmpresa");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos si la cesión está activa o no
                    activa = Util.GetText(di, "estado").Equals(Constantes.ACTIVO) ? true : false;
                    break;
                }
            }
            return activa;
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de finalizar Cesión
        /// </summary>
        private void parametrosFinalizarCesion()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesiones();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de cesión
            hParametros.Add(Constantes.OIDDEPARTAMENTO, hOidDestCesion.Value);
            hParametros.Add(Constantes.NOMDEPARTAMENTO, lblDestCesion.Text);
            //Como estamos en la pantalla de gestión de departamentos pasamos el identificativo de empleado vacio
            //De esta manera en la pantalla de finalización de cesión ya se sabe que es una cesión a un departamento
            hParametros.Add(Constantes.OIDEMPLEADO, "");
            hParametros.Add(Constantes.NOMEMPLEADO, "");

            Session[Constantes.PARAMETROS] = hParametros;
        }

        protected void btnEditarMedio_Click(object sender, EventArgs e)
        {
            if (esMedioActivo())
            {
                parametrosEditarMedio();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popUpEditarMedio", "popupEditarMedio(800,350);", true);
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJEMEDIOACTIVO);
            }
        }

        /// <summary>
        /// Comprueba si el medio seleccionado está activo o no
        /// </summary>
        /// <returns>true o false en función si el medio está activo o no</returns>
        private bool esMedioActivo()
        {
            bool activo = false;
            string fbaja = String.Empty;
            foreach (GridViewRow di in grdCesiones.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    fbaja = grdCesiones.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString();
                    break;
                }
            }

            if (string.IsNullOrEmpty(fbaja))
            {
                activo = true;
            }
            else
            {
                if (Convert.ToDateTime(fbaja) > DateTime.Now)
                {
                    activo = true;
                }
                else
                {
                    activo = false;
                }
            }

            return activo;
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de editar medio
        /// </summary>
        private void parametrosEditarMedio()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesiones();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de medio
            Session[Constantes.PARAMETROS] = hParametros;
        }

        /// <summary>
        /// Botón para generar el informe Excel. Está configurado para generar un Postback completo de la página.
        /// Esto es necesario para que funcione el método Response.BinaryWrite
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, EventArgs e)
        {
            var dsCesiones = (DataSet)ViewState["dsGridCesiones"];

            if (dsCesiones != null)
            {
                // Recuperamos los filtros de la consulta
                filtros = (Dictionary<string, string>)ViewState["filtros"];

                var exportador = new ExportadorExcel(dsCesiones.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELA), filtros, lblTitulo.Text);
                exportador.Mapeos = bll.obtenerMapeosExcel();
                exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
                var bytes = exportador.exportarExcel();

                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
                Response.BinaryWrite(bytes);
                Response.End();
            }
        }

        /// <summary>
        /// Guardamos el estado de la página para poderla recuperar cuando el usuario vuelva
        /// </summary>
        private void persistirEstadoPagina()
        {
            Hashtable hParametros = new Hashtable();
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_NOMBRE, txtDepartamento.Text);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_EMPRESA, ddlEmpresa.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_PAGINA_GRID, grdEmpresa.PageIndex);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_REGISTRO_SELECCIONADO, hOidDestCesion.Value);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_ID, txtID.Text);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_TIPO_MEDIO, ddlTipoMedio.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_CESIONES_ACTIVAS, chkCesiones.Checked);
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_PAGINA_CESIONES, grdCesiones.PageIndex);
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = hParametros;
        }

        #region ordenacionPaginacionGrid
        protected void grdEmpresa_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                recargaGridEmpresaPaginacion(e.NewPageIndex);
                limpiarCesiones();
            }
        }

        private void recargaGridEmpresaPaginacion(int numPagina)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridDepartamentos"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpressionEmpresa))
                {
                    dataView.Sort = GridViewSortExpressionEmpresa + " " + GridViewSortDirectionEmpresa;
                }
                grdEmpresa.PageIndex = numPagina;
                grdEmpresa.DataSource = dataView;
                grdEmpresa.DataBind();

            }            
        }
        

        protected void grdCesiones_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                recargaGridCesionesPaginacion(e.NewPageIndex);
            }
        }

        private void recargaGridCesionesPaginacion(int numPagina)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridCesiones"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpressionCesiones))
                {
                    dataView.Sort = GridViewSortExpressionCesiones + " " + GridViewSortDirectionCesiones;
                }
                grdCesiones.PageIndex = numPagina;
                grdCesiones.DataSource = dataView;
                grdCesiones.DataBind();
            }            
        }

        protected void grdEmpresa_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridDepartamentos"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionEmpresa(e.SortExpression);

                grdEmpresa.DataSource = dataView;
                grdEmpresa.DataBind();

            }
        }

        private string GetSortExpressionEmpresa(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionEmpresa && GridViewSortDirectionEmpresa == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionEmpresa = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionEmpresa = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionEmpresa = sortExpression;
            return sortExpression + " " + GridViewSortDirectionEmpresa;
        }

        private string GridViewSortDirectionEmpresa
        {
            get { return ViewState["SortDirectionEmpresa"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionEmpresa"] = value; }
        }
        private string GridViewSortExpressionEmpresa
        {
            get { return ViewState["SortExpressionEmpresa"] as string ?? string.Empty; }
            set { ViewState["SortExpressionEmpresa"] = value; }
        }

        protected void grdEmpresa_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionEmpresa)
                        {
                            if (GridViewSortDirectionEmpresa.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }


        protected void grdCesiones_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridCesiones"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionCesiones(e.SortExpression);

                grdCesiones.DataSource = dataView;
                grdCesiones.DataBind();
            }
        }

        private string GetSortExpressionCesiones(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionCesiones && GridViewSortDirectionCesiones == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionCesiones = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionCesiones = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionCesiones = sortExpression;
            return sortExpression + " " + GridViewSortDirectionCesiones;
        }

        private string GridViewSortDirectionCesiones
        {
            get { return ViewState["SortDirectionCesiones"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionCesiones"] = value; }
        }
        private string GridViewSortExpressionCesiones
        {
            get { return ViewState["SortExpressionCesiones"] as string ?? string.Empty; }
            set { ViewState["SortExpressionCesiones"] = value; }
        }

        protected void grdCesiones_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionCesiones)
                        {
                            if (GridViewSortDirectionCesiones.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        #endregion
    }
}