﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Ent;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web
{
    public partial class EditarMedio : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.EditarMedio bll;
        private MantMensajes manejador = new MantMensajes();
        protected List<Modelo> modelos;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

			// Comprobamos que tiene acceso a la página
            if (!Util.tieneAcceso(this.Context))
            {
                Response.Redirect(Constantes.PAG_PERFIL_NOAUTH);
            }
            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();           
            }
        }
        
        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_EDITAR_MEDIO, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.EditarMedio(ref manejador);
            //Primero inicializamos este combo, ya que en función del valor de elemento seleccionado habrá que realizar distintas operaciones
            inicializarComboTiposDeMedios();
            obtenerDatosSesion();
            obtenerDatosTipoMedio();            
            presentarPantalla();
            obtenerDatosCesionMedio();
            val_fecBajaMedioMayorHoy.ValueToCompare = DateTime.Now.ToShortDateString();
        }

        /// <summary>
        /// obtiene los datos de cesión del medio para poder realizar las comprobaciones oportunas
        /// correspondientes a la fecha de baja del medio.
        /// </summary>
        private void obtenerDatosCesionMedio()
        {
            ArrayList result = new ArrayList();
            result = bll.obtenerDatosCesionMedio(hOidMedio.Value);

            if (result.Count > 0)
            {
                //el medio tiene una cesión activa
                if (!string.IsNullOrEmpty(result[2].ToString()))
                {
                    //si tiene fecha de fin de prorroga
                    val_fecFinProrrogaCesion.ValueToCompare = Convert.ToDateTime(result[2].ToString()).ToShortDateString();
                    val_fecFinProrrogaCesion.ErrorMessage = Constantes.MENSAJEFECHAPRORROGACESIONEDITARMEDIO;
                }
                else
                {
                    if (!string.IsNullOrEmpty(result[1].ToString()))
                    {
                        //si tiene fecha de fin de cesión
                        val_fecFinProrrogaCesion.ValueToCompare = Convert.ToDateTime(result[1].ToString()).ToShortDateString();
                        val_fecFinProrrogaCesion.ErrorMessage = Constantes.MENSAJEFECHAFINCESIONEDITARMEDIO;
                    }
                    else
                    {
                        val_fecFinProrrogaCesion.ValueToCompare = DateTime.Now.ToShortDateString();
                        val_fecFinProrrogaCesion.Enabled = false;
                        //tiene cesión activa pero no tiene ni fecha de fin de cesión ni fecha de fin de prorroga.
                        //no dejamos editar la fecha de baja del medio.
                        txtFecBaja.ReadOnly = true;
                        txtFecBaja.Enabled = false;
                        txtFecBaja.ToolTip = Constantes.MENSAJEFECHABAJAEDITARMEDIO;
                    }
                }
            }
            else
            {
                //el medio actualmente no está cedido
                val_fecFinProrrogaCesion.ValueToCompare = DateTime.Now.ToShortDateString();
                val_fecFinProrrogaCesion.Enabled = false;
                txtFecBaja.ReadOnly = false;
                txtFecBaja.Enabled = true;               
            }

            //// Recuperamos los mensajes del manejador
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (mensajes.TipoMensaje == Mensajes.tiposMensaje.Error)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        /// <summary>
        /// Obtenemos los datos de la cesión
        /// </summary>
        private void obtenerDatosSesion()
        {
            Hashtable hParametros = (Hashtable)Session[Constantes.PARAMETROS];
            hOidMedio.Value = hParametros[Constantes.OIDMEDIO].ToString();
        }

        /// <summary>
        /// obtemos los datos asociados al tipo de medio seleccionado
        /// Si tiene marca y modelo, si tiene extensión y si es entregable
        /// Obtenemos una datatable que almacenamos en la capa de negocio
        /// </summary>
        private void obtenerDatosTipoMedio()
        {
            bll.obtenerDatosTiposDeMedios();
        }

        /// <summary>
        /// Método para mostrar la pantalla al usuario en función del tipo de medio elegido
        /// </summary>
        private void presentarPantalla()
        {
            //Llamamos a la capa de negocio para obtener los datos del medio
            Medio medioAct = bll.buscarMedio(Convert.ToInt16(hOidMedio.Value));
            ddlTipoMedio.SelectedValue = medioAct.OidTipoMedio.ToString();
            if (bll.tieneCesion(Convert.ToInt16(this.hOidMedio.Value)))
            {
                //Si el medio está o ha estado cedido no se podrá actualizar el tipo de medio asociado al mismo
                ddlTipoMedio.Enabled = false;
            }
            if (bll.tieneMarcaModelo(Convert.ToInt16(ddlTipoMedio.SelectedValue)))
            {
                //Si tiene marca y modelo cargamos los combos de marca y modelo
                ddlMarca.Enabled = true;
                Combos.cargarCombosDesc(Constantes.MARCAS, ddlMarca, false);
                ddlMarca.SelectedValue = medioAct.OidMarca.ToString();
                ddlModelo.Enabled = true;
                cargaComboModelos(Convert.ToInt16(ddlMarca.SelectedValue));
                ddlModelo.SelectedValue = medioAct.OidModelo.ToString();
            }
            else
            {
                ddlMarca.Enabled = false;
                ddlMarca.Items.Clear();
                ddlModelo.Enabled = false;
                ddlModelo.Items.Clear();
            }
            if (bll.tieneExtension(Convert.ToInt16(ddlTipoMedio.SelectedValue)))
            {
                //activamos la validación del campo
                valExtension.Enabled = true;
                txtExtension.Text = medioAct.Extension;
            }
            else
            {
                txtExtension.Text = "";
                txtExtension.ReadOnly = true;
                valExtension.Enabled = false;
            }
            if (bll.esEntregable(Convert.ToInt16(ddlTipoMedio.SelectedValue)))
            {
                //si es entregable activamos la check
                chkEntregable.Checked = true;
            }
            else
            {
                chkEntregable.Checked = false;
            }
            txtComentarios.Text = medioAct.Comentarios;
            txtID.Text = medioAct.IdMedio;
            txtFechaAlta.Text = Convert.ToDateTime(medioAct.FecAlta).ToShortDateString();
            if (!medioAct.FecBaja.Equals(""))
            {
                txtFecBaja.Text = Convert.ToDateTime(medioAct.FecBaja).ToShortDateString();
            }
            //chkLibre.Checked = medioAct.Libre;         
        }

        /// <summary>
        /// Cargamos los modelos asociados a la marca seleccinada
        /// </summary>
        /// <param name="oidMarca"></param>
        private void cargaComboModelos(int oidMarca)
        {
            // Cargamos la combo
            modelos = bll.obtenerListaModelos(oidMarca);

            ddlModelo.Items.Clear();
            ddlModelo.Items.Clear();
            foreach (Modelo modeloAct in modelos)
            {
                ddlModelo.Items.Add(new ListItem(modeloAct.Nombre, modeloAct.OidModelo.ToString()));
            }
        }

        private void inicializarComboTiposDeMedios()
        {
            Combos.cargarCombosDescPerfil(Constantes.TIPOSDEMEDIOS, ddlTipoMedio,Session[Constantes.ID_PERFIL].ToString(), false);
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        protected void ddlMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            cargaComboModelos(Convert.ToInt16(ddlMarca.SelectedValue));
        }

        protected void ddlTipoMedio_SelectedIndexChanged(object sender, EventArgs e)
        {
            presentarPantalla();
        }

        /// <summary>
        /// Método para guardar la actualización del medio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            Medio medio = new Medio(Convert.ToInt16(hOidMedio.Value), Convert.ToInt16(this.ddlTipoMedio.SelectedValue),
                                    Convert.ToInt16(this.ddlModelo.SelectedValue.Equals("") ? "-1" : this.ddlModelo.SelectedValue),
                                    Convert.ToInt16(this.ddlMarca.SelectedValue.Equals("") ? "-1" : this.ddlMarca.SelectedValue),
                                    //this.txtID.Text, this.txtFechaAlta.Text, txtFecBaja.Text, this.txtExtension.Text, this.txtComentarios.Text,this.chkLibre.Checked);
                                    this.txtID.Text, this.txtFechaAlta.Text, txtFecBaja.Text, this.txtExtension.Text, this.txtComentarios.Text);
            
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;
            
            int intGuardar;
            ////Llamamos a la capa de negocio
            intGuardar = bll.guardarMedio(medio);
            //// Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (mensajes.TipoMensaje == Mensajes.tiposMensaje.Error)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
            else
            {
                cerrarPopUp();
            }
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        protected void btnInfoOk_Click(object sender, EventArgs e)
        {
            cerrarPopUp();
        }

        private void cerrarPopUp()
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "cerrarVentana", "cerrarPopUp('true')", true);
        }
    }
}