﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Bll;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web
{
    public partial class GestionDeMedios : System.Web.UI.Page
    {
        #region Miembros privados

        protected static ASB.GMAP.Bll.GestionMedios bll;
        private MantMensajes manejador = new MantMensajes();
        private Dictionary<string, string> filtros = new Dictionary<string, string>();
        private string esMedioBaja = String.Empty;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        #region Manejadores de eventos

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            var valores = new List<string>();
            if (!chkTodos.Checked && lstTipos.SelectedIndex > -1)
            {
                foreach (ListItem item in lstTipos.Items)
                {
                    if (item.Selected == true)
                    {
                        valores.Add(item.Value);
                    }
                }
            }
            else
            {
                foreach (ListItem item in lstTipos.Items)
                {
                    valores.Add(item.Value);
                }
            }

            //Variablen en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            ViewState["medios"] = bll.buscarMedios(txtID.Text,
                                                   Convert.ToInt32(cboCedidosA.SelectedValue),
                                                   Convert.ToInt32(cboEstado.SelectedValue),
                                                   String.Join(",", valores),
                                                   Convert.ToInt32(chkCesionesNoActivas.Checked),
                                                   Convert.ToInt32(chkLibre.Checked),
                                                   txtComentarios.Text,
                                                   out numRegistros);

            // Guardamos los filtros usados en la consulta
            if (ViewState["filtros"] != null)
            {
                filtros = (Dictionary<string, string>)ViewState["filtros"];
            }
            filtros[lblID.Text] = txtID.Text;
            filtros[lblMedios.Text] = cboCedidosA.SelectedItem.Text;
            filtros[lblMediosEstados.Text] = cboEstado.SelectedItem.Text;
            filtros[lblComentarios.Text] = txtComentarios.Text;

            if (chkTodos.Checked)
            {
                filtros["Tipos de Medios:"] = "Todos";
            }
            else
            {
                filtros["Tipos de Medios:"] = String.Join(", ", tiposMediosSeleccionados());
            }
            filtros[chkCesionesNoActivas.Text] = chkCesionesNoActivas.Checked ? "Si" : "No";

            ViewState["filtros"] = filtros;

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }

            recargarGrid();
        }

        private List<string> tiposMediosSeleccionados()
        {
            var textos = new List<string>();
            foreach (ListItem item in lstTipos.Items)
            {
                if (item.Selected == true)
                {
                    textos.Add(item.Text);
                }
            }
            return textos;
        }

        

        protected void btnExcelMedios_Click(object sender, EventArgs e)
        {
            // Recuperamos los filtros de la consulta
            filtros = (Dictionary<string, string>)ViewState["filtros"];

            var medios = (DataSet)ViewState["medios"];

            var exportador = new ExportadorExcel(medios.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELB), filtros, lblTitulo.Text);
            exportador.Mapeos = bll.obtenerMapeosExcel();
            exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
            var bytes = exportador.exportarExcel();

            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
            Response.BinaryWrite(bytes);
            Response.End();
        }

        protected void btnEliminarMedio_Click(object sender, EventArgs e)
        {
            var unoSeleccionado = false;
            foreach (GridViewRow fila in gvMedios.Rows)
            {
                CheckBox chkSeleccionado = (CheckBox)fila.FindControl("chkSeleccionado");

                if (chkSeleccionado != null && chkSeleccionado.Checked)
                {
                    unoSeleccionado = true;
                    break;
                }
            }

            if (unoSeleccionado)
            {
                if (!esMedioActivo())
                {
                    mostrarPopUp(Constantes.MENSAJEMEDIONOACTIVO);
                }
                else if (esCedidoActualmente())
                {
                    mostrarPopUp(Constantes.MENSAJEMEDIOCEDIDO);
                }
                else
                {
                    mostrarConfirmPopUp(Constantes.MENSAJEBORRARMEDIO);
                }
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJESELECCIONARUNO);
            }
        }

        protected void btnConfirmacionSi_Click(object sender, EventArgs e)
        {
            ConfirmPopUp.Hide();

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            var idMedio = 0;
            foreach (GridViewRow fila in gvMedios.Rows)
            {
                CheckBox chkSeleccionado = (CheckBox)fila.FindControl("chkSeleccionado");

                if (chkSeleccionado != null && chkSeleccionado.Checked)
                {
                    idMedio = Convert.ToInt32(gvMedios.DataKeys[fila.RowIndex].Values["INT_OIDMEDIO"]);
                    break;
                }
            }

            // Llamamos a la capa de negocio
            var resultado = bll.eliminarMedio(idMedio);

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
            
            // Recargar Grid
            btnBuscar_Click(btnBuscar, EventArgs.Empty);
        }

        protected void btnCrearCesion_Click(object sender, EventArgs e)
        {
            //Preparamos los parametros para pasar a la pantalla
            parametrosAnadirCesion();

            Hashtable hParametros = (Hashtable)Session[Constantes.PARAMETROS];
            string OidEmpleado = hParametros[Constantes.OIDEMPLEADO].ToString();
            string OidDepartamento = hParametros[Constantes.OIDDEPARTAMENTO].ToString();
            string OidCesion = hParametros[Constantes.OIDCESION].ToString();
            string NomEmpleado = hParametros[Constantes.NOMEMPLEADO].ToString();
            string NomDepartamento = hParametros[Constantes.NOMDEPARTAMENTO].ToString();

            if ((esMedioBaja.Equals(Constantes.NO_ACTIVO)) || (string.IsNullOrEmpty(esMedioBaja) && string.IsNullOrEmpty(OidEmpleado) && string.IsNullOrEmpty(OidDepartamento) && string.IsNullOrEmpty(OidCesion) && string.IsNullOrEmpty(NomEmpleado) && string.IsNullOrEmpty(NomDepartamento)))
            {
                mostrarPopUp(Constantes.MENSAJEMEDIOACTIVO);
            }
            else
            {
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("CesionMedioDisponible.aspx");
            }
        }

        protected void btnEditarCesión_Click(object sender, EventArgs e)
        {
            if (esCesionActiva())
            {
                parametrosEditarCesion();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("EditarCesion.aspx");
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        protected void btnEditarMedio_Click(object sender, EventArgs e)
        {
            if (esMedioActivo())
            {
                parametrosEditarMedio();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popUpEditarMedio", "popupEditarMedio(800,350);", true);
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJEMEDIOACTIVO);
            }
        }

        protected void btnEliminarCesion_Click(object sender, EventArgs e)
        {
            if (esCesionActiva())
            {
                parametrosFinalizarCesion();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("FinalizarCesion.aspx");
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        #endregion

        #region Funciones auxiliares

        /// <summary>
        /// Parámetros para pasar a la pantalla de editar medio
        /// </summary>
        private void parametrosEditarMedio()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesiones();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de medio
            Session[Constantes.PARAMETROS] = hParametros;
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de finalizar Cesión
        /// </summary>
        private void parametrosFinalizarCesion()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesiones();
            Session[Constantes.PARAMETROS] = hParametros;
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Editar Cesión
        /// </summary>
        private void parametrosEditarCesion()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesiones();
            Session[Constantes.PARAMETROS] = hParametros;
        }

        /// <summary>
        /// Comprueba si la cesión seleccionada está activa o no
        /// </summary>
        /// <returns>true o false en función si la cesión está activa o no</returns>
        private bool esCesionActiva()
        {
            bool activa = false;
            foreach (GridViewRow di in gvMedios.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkSeleccionado");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos si la cesión está activa o no
                    activa = gvMedios.DataKeys[di.RowIndex].Values["CESIONACTIVA"].Equals(Constantes.SI) ? true : false;
                    break;
                }
            }
            return activa;
        }

        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_GESTION_DE_MEDIOS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.GestionMedios(ref manejador);

            // Aplicamos las acciones segun el perfil del usuario
            Util.aplicarAcciones(this);

            btnExcelMedios.Enabled = false;
            btnEliminarMedio.Enabled = false;
            btnEditarCesión.Enabled = false;
            btnEliminarCesion.Enabled = false;
            btnEditarMedio.Enabled = false;

            inicializarCombos();

            // Inicializamos los filtros para la exportación Excel
            filtros.Add(lblID.Text, String.Empty);
            filtros.Add(lblMedios.Text, String.Empty);
            filtros.Add(lblMediosEstados.Text, String.Empty);
            filtros.Add("Tipos de Medios:", String.Empty);
            filtros.Add(chkCesionesNoActivas.Text, String.Empty);

            ViewState["filtros"] = filtros;
            presentarPantalla();
            Session[Constantes.VENTANAPADRE] = null;
            Session[Constantes.VENTANAANTERIOR] = null;
            Session[Constantes.PARAMETROS] = null;
           
        }

        /// <summary>
        /// Si venimos de vuelta a la pantalla de alguna de sus paginas "hijas" cargamos el estado de la pantalla
        /// </summary>
        private void presentarPantalla()
        {
            if (Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] != null && Session[Constantes.MIGAS_PAN].ToString().Contains(Constantes.MIGAS_PAN_GESTION_MEDIOS))
            {
                Hashtable hParametros = (Hashtable)Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS];

                txtID.Text = hParametros[Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_ID].ToString();
                cboCedidosA.SelectedValue = hParametros[Constantes.PANTALLA_MEDIOS_POR_CESION].ToString();
                cboEstado.SelectedValue = hParametros[Constantes.PANTALLA_MEDIOS_POR_ESTADO].ToString();
                chkTodos.Checked = Convert.ToBoolean(hParametros[Constantes.PANTALLA_MEDIOS_TIPOS_MEDIO_TODOS].ToString());
                seleccionarTiposDeMedio((List<string>)hParametros[Constantes.PANTALLA_MEDIOS_TIPOS_MEDIO]);
                chkCesionesNoActivas.Checked = Convert.ToBoolean(hParametros[Constantes.PANTALLA_MEDIOS_CESIONES_ACTIVAS].ToString());
                btnBuscar_Click(null, null);
                recargaGridMediosPaginacion(Convert.ToInt16(hParametros[Constantes.PANTALLA_MEDIOS_PAGINA]));
                seleccionarMedio((ArrayList)hParametros[Constantes.PANTALLA_MEDIOS_REGISTRO_SELECCIONADO]);
            }

            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;

        }

        /// <summary>
        /// Si venimos de una pantalla hija seleccionamos los tipos de medio que hubiera selecciandos anteriormente
        /// </summary>
        private void seleccionarTiposDeMedio(List<string> tiposMedio)
        {
            foreach (ListItem item in lstTipos.Items)
            {
                if(tiposMedio.Contains(item.Text))
                {
                    item.Selected = true;
                }
            }
        }

        /// <summary>
        /// Guardamos el estado de la página para poderla recuperar cuando el usuario vuelva
        /// </summary>
        private void persistirEstadoPagina()
        {
            Hashtable hParametros = new Hashtable();
            hParametros.Add(Constantes.PANTALLA_PERSONAS_DEPARTAMENTOS_ID, txtID.Text);
            hParametros.Add(Constantes.PANTALLA_MEDIOS_POR_CESION,cboCedidosA.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_MEDIOS_POR_ESTADO, cboEstado.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_MEDIOS_TIPOS_MEDIO_TODOS, chkTodos.Checked);
            hParametros.Add(Constantes.PANTALLA_MEDIOS_TIPOS_MEDIO, tiposMediosSeleccionados());
            hParametros.Add(Constantes.PANTALLA_MEDIOS_CESIONES_ACTIVAS, chkCesionesNoActivas.Checked);
            hParametros.Add(Constantes.PANTALLA_MEDIOS_PAGINA, gvMedios.PageIndex);
            hParametros.Add(Constantes.PANTALLA_MEDIOS_REGISTRO_SELECCIONADO, obtenerMedioSeleccionado());
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = hParametros;
        }

        /// <summary>
        /// Obtenemos el registro seleccionado para al volver de una página hija poderlo seleccionar
        /// </summary>
        /// <returns></returns>
        private ArrayList obtenerMedioSeleccionado()
        {
            ArrayList arrResult = new ArrayList();
            foreach (GridViewRow di in gvMedios.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkSeleccionado");

                if (chkBx.Checked)
                {
                    arrResult.Add(gvMedios.DataKeys[di.RowIndex].Values["INT_OIDMEDIO"].ToString());
                    arrResult.Add(gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONEMPLEADO"].ToString());
                    arrResult.Add(gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONDEPARTAMENTO"].ToString());                     
                    break;
                }
            }
            return arrResult;
        }

        /// <summary>
        /// Al volver de una pagina hija seleccionamos el medio que estuviera seleccionado anteriormenteo
        /// </summary>
        private void seleccionarMedio(ArrayList arrRegSel)
        {
            if (arrRegSel.Count > 0)
            {
                foreach (GridViewRow di in gvMedios.Rows)
                {
                    CheckBox chkBx = (CheckBox)di.FindControl("chkSeleccionado");

                    if (arrRegSel[0].ToString().Equals(gvMedios.DataKeys[di.RowIndex].Values["INT_OIDMEDIO"].ToString()) &&
                        arrRegSel[1].ToString().Equals(gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONEMPLEADO"].ToString()) &&
                        arrRegSel[2].ToString().Equals(gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONDEPARTAMENTO"].ToString()))
                    {
                        chkBx.Checked = true;
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Muestra los mensajes que se producen al cargar la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MensajesEntidad> mensajes = new List<MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        private void recargarGrid()
        {
            gvMedios.DataSource = ViewState["medios"];
            gvMedios.DataBind();

            if (gvMedios.Rows.Count > 0)
            {
                Util.intentarHabilitar(btnExcelMedios);
                Util.intentarHabilitar(btnEliminarMedio);
                Util.intentarHabilitar(btnEditarCesión);
                Util.intentarHabilitar(btnEliminarCesion);
                Util.intentarHabilitar(btnEditarMedio);
            }
            else
            {
                btnExcelMedios.Enabled = false;
                btnEliminarMedio.Enabled = false;
                btnEditarCesión.Enabled = false;
                btnEliminarCesion.Enabled = false;
                btnEditarMedio.Enabled = false;
            }
            Util.intentarHabilitar(btnCrearCesion);
                
        }

        private void inicializarCombos()
        {
            // Cargar el listbox de tipos de medios
            int numRegistros = 0;

            lstTipos.DataSource = bll.obtenerTiposMedios(Session[Constantes.ID_PERFIL].ToString(), out numRegistros);
            lstTipos.DataValueField = "intCodigo";
            lstTipos.DataTextField = "strDescripcion";
            lstTipos.DataBind();

            // Actualizamos el número de tipos de medios
            lblNumeroTipoMedios.Text = "Total Tipos de Medios encontrados: " + numRegistros.ToString();

            //Para el combo de CedidosA no tenemos tabla maestra por lo tanto introducimos los valores
            cboCedidosA.Items.Clear();
            cboCedidosA.Items.Add(new ListItem("Todos/as", "-1"));
            cboCedidosA.Items.Add(new ListItem("Personas", "0"));
            cboCedidosA.Items.Add(new ListItem("Departamentos", "1"));
            cboCedidosA.Items.Add(new ListItem("Disponibles", "2"));

            //Para el combo de estado no tenemos tabla maestra por lo tanto introducimos los valores
            cboEstado.Items.Clear();
            cboEstado.Items.Add(new ListItem("Todos/as", "-1"));
            cboEstado.Items.Add(new ListItem("No Activos", "0"));
            cboEstado.Items.Add(new ListItem("Activos", "1"));
            cboEstado.SelectedValue = "1";
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Añadir Cesión
        /// </summary>
        private void parametrosAnadirCesion()
        {
            //Creamos una hashtable con los parámetros a pasar
            Hashtable hParams = obtenerDatosGridCesiones();
            Session[Constantes.PARAMETROS] = hParams;
        }

        /// <summary>
        ///Creamos una estructura lifo, de tal manera que se puedan recuperar las ventanas llamadoras hacia atrás
        /// </summary>
        //private void crearPilaVentanaLlamadora()
        //{
        //    Stack<string> stack = new Stack<string>();
        //    stack.Push("GestionDeMedios.aspx");
        //    Session[Constantes.VENTANALLAMADORA] = stack;
        //}

        /// <summary>
        /// Obtenemos los datos de la cesión seleccionada para pasar los parámetros a las distintas pantallas
        /// </summary>
        /// <returns>Hastable con los datos de la cesión seleccionada</returns>
        private Hashtable obtenerDatosGridCesiones()
        {
            Hashtable hParametros = new Hashtable();
            bool tieneFilaSeleccionada = false;
            //obtenemos el empleado seleccionado para filtrar sus cesiones
            foreach (GridViewRow di in gvMedios.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkSeleccionado");

                if (chkBx != null && chkBx.Checked)
                {
                    tieneFilaSeleccionada = true;
                    //Para la fila seleccionada obtenemos el tipo de medio
                    hParametros.Add(Constantes.TIPOMEDIO, gvMedios.DataKeys[di.RowIndex].Values["TIPOMEDIOENTERO"].ToString());
                    //el ID del medio
                    hParametros.Add(Constantes.IDMEDIO, gvMedios.DataKeys[di.RowIndex].Values["VAR_CODIGOMEDIOENTERO"].ToString());
                    //el modelo
                    hParametros.Add(Constantes.MODELO, gvMedios.DataKeys[di.RowIndex].Values["MODELOENTERO"].ToString());
                    esMedioBaja = Util.GetText(di, "ACTIVO");
                    if (!gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONEMPLEADO"].ToString().Equals(""))
                    {
                        hParametros.Add(Constantes.OIDCESION, gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONEMPLEADO"].ToString());
                        hParametros.Add(Constantes.OIDEMPLEADO, gvMedios.DataKeys[di.RowIndex].Values["STRNUMEMPLEADO"].ToString());
                        hParametros.Add(Constantes.NOMEMPLEADO, gvMedios.DataKeys[di.RowIndex].Values["CEDIDOAENTERO"].ToString());
                        hParametros.Add(Constantes.NOMDEPARTAMENTO, "");
                        hParametros.Add(Constantes.OIDDEPARTAMENTO, "");
                    }
                    else
                    {
                        if (!gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONDEPARTAMENTO"].ToString().Equals(""))
                        {
                            hParametros.Add(Constantes.OIDCESION, gvMedios.DataKeys[di.RowIndex].Values["INT_OIDCESIONDEPARTAMENTO"].ToString());
                            hParametros.Add(Constantes.OIDDEPARTAMENTO, gvMedios.DataKeys[di.RowIndex].Values["ID_ORGUNIT"].ToString());
                            hParametros.Add(Constantes.NOMDEPARTAMENTO, gvMedios.DataKeys[di.RowIndex].Values["CEDIDOAENTERO"].ToString());
                            hParametros.Add(Constantes.NOMEMPLEADO, "");
                            hParametros.Add(Constantes.OIDEMPLEADO, "");
                        }
                        else
                        {
                            //El medio no está cedido, estará disponible o dado de baja.
                            hParametros.Add(Constantes.OIDCESION, "");
                            hParametros.Add(Constantes.NOMEMPLEADO, "");
                            hParametros.Add(Constantes.OIDEMPLEADO, "");
                            hParametros.Add(Constantes.NOMDEPARTAMENTO, "");
                            hParametros.Add(Constantes.OIDDEPARTAMENTO, "");
                        }
                    }
                    hParametros.Add(Constantes.OIDMEDIO, gvMedios.DataKeys[di.RowIndex].Values["INT_OIDMEDIO"].ToString());
                    hParametros.Add(Constantes.FBAJAMEDIO, gvMedios.DataKeys[di.RowIndex].Values["DAT_FBAJA"].ToString());
                    break;
                }
            }

            if (!tieneFilaSeleccionada)
            {
                //No se ha seleccionado ningun registro del grid
                hParametros.Add(Constantes.OIDCESION, "");
                hParametros.Add(Constantes.NOMEMPLEADO, "");
                hParametros.Add(Constantes.OIDEMPLEADO, "");
                hParametros.Add(Constantes.NOMDEPARTAMENTO, "");
                hParametros.Add(Constantes.OIDDEPARTAMENTO, "");
            }

            Session[Constantes.MIGAS_PAN] = Constantes.MIGAS_PAN_GESTION_MEDIOS;
            return hParametros;
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        private void mostrarConfirmPopUp(string mensaje)
        {
            lblMensajeConfirmacion.Text = mensaje;
            ConfirmPopUp.Show();
        }

        private bool esCedidoActualmente()
        {
            bool esCedido = false;
            foreach (GridViewRow fila in gvMedios.Rows)
            {
                CheckBox chkSeleccionado = (CheckBox)fila.FindControl("chkSeleccionado");

                if (chkSeleccionado != null && chkSeleccionado.Checked)
                {
                    esCedido = gvMedios.DataKeys[fila.RowIndex].Values["ACTUALMENTECEDIDO"].ToString().Equals("1") ? true : false;
                    break;
                }
            }
            return esCedido;
        }

        private bool esMedioActivo()
        {
            bool esActivo = false;
            foreach (GridViewRow fila in gvMedios.Rows)
            {
                CheckBox chkSeleccionado = (CheckBox)fila.FindControl("chkSeleccionado");

                if (chkSeleccionado != null && chkSeleccionado.Checked)
                {
                    esActivo = Util.GetText(fila, "ACTIVO").Equals("Activo") ? true : false;
                    break;
                }
            }
            return esActivo;
        }

        #endregion
        protected void gvMedios_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                recargaGridMediosPaginacion(e.NewPageIndex);
            }
        }

        private void recargaGridMediosPaginacion(int numPagina)
        {
            DataTable dataTable = ((DataSet)ViewState["medios"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpression))
                {
                    dataView.Sort = GridViewSortExpression + " " + GridViewSortDirection;
                }
                gvMedios.PageIndex = numPagina;
                gvMedios.DataSource = dataView;
                gvMedios.DataBind();
                recargarGrid();
            }             
            
        }
        protected void gvMedios_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["medios"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpression(e.SortExpression);

                gvMedios.DataSource = dataView;
                gvMedios.DataBind();
            }
        }

        private string GetSortExpression(string sortExpression)
        {
            if (sortExpression == GridViewSortExpression && GridViewSortDirection == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpression = sortExpression;
            return sortExpression + " " + GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirection"] = value; }
        }
        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }

        protected void gvMedios_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpression)
                        {
                            if (GridViewSortDirection.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }
        public string MakeShort(String str, int maxLength)

        {
            if (str.Length >= maxLength)

            {

                str = str.Substring(0, maxLength) + "...";

            }

            return str;

        }
    }
}