﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using ASB.GMAP.Ent;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web
{
    public partial class EditarCesion : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.EditarCesion bll;
        private MantMensajes manejador = new MantMensajes();

        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_EDITAR_CESION, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.EditarCesion(ref manejador);           
            //Recuperamos de la sesion los parámetros para hacer la búsqueda de la cesión
            recuperarDatosSesion();
            obtenerDatosCesion();
            comprobacionFechaBajaMedio();
            txtRespProrroga.Attributes.Add("readonly", "readonly");
            Session[Constantes.VENTANAANTERIOR] = Request.UrlReferrer.AbsolutePath.ToString();
        }

        /// <summary>
        /// Inicializa el comparador para que la fecha de fin de cesión no pueda ser superior a la fecha
        /// de baja del medio.
        /// </summary>
        private void comprobacionFechaBajaMedio()
        {
            if (string.IsNullOrEmpty(hOidFecBajaMedio.Value))
            {
                val_fecFinCesionMenorBajaMedio.Enabled = false;
                valFecFinProrrogaFecBajaMedio.Enabled = false;
                val_fecFinCesionMenorBajaMedio.ValueToCompare = DateTime.Now.ToShortDateString();
                valFecFinProrrogaFecBajaMedio.ValueToCompare = DateTime.Now.ToShortDateString();
            }
            else
            {
                val_fecFinCesionMenorBajaMedio.Enabled = true;
                val_fecFinCesionMenorBajaMedio.ValueToCompare = Convert.ToDateTime(hOidFecBajaMedio.Value).ToShortDateString();
                val_fecFinCesionMenorBajaMedio.ErrorMessage = Constantes.MENSAJEFECHAFINCESIONBAJAMEDIO + "(" + Convert.ToDateTime(hOidFecBajaMedio.Value).ToShortDateString() + ")";
                valFecFinProrrogaFecBajaMedio.ValueToCompare = Convert.ToDateTime(hOidFecBajaMedio.Value).ToShortDateString();
                valFecFinProrrogaFecBajaMedio.ErrorMessage = Constantes.MENSAJEFECHAFINPRORROGABAJAMEDIO + "(" + Convert.ToDateTime(hOidFecBajaMedio.Value).ToShortDateString() + ")";
            }
        }

        private void recuperarDatosSesion()
        {
            Hashtable hParametros = (Hashtable)Session[Constantes.PARAMETROS];
            hOidEmpleado.Value = hParametros[Constantes.OIDEMPLEADO].ToString();
            hOidDepartamento.Value = hParametros[Constantes.OIDDEPARTAMENTO].ToString();
            hOidCesion.Value = hParametros[Constantes.OIDCESION].ToString();
            hOidFecBajaMedio.Value = hParametros[Constantes.FBAJAMEDIO].ToString();
            lblCodigoMedio.Text = hParametros[Constantes.IDMEDIO].ToString();
            lblTipoMedio.Text = hParametros[Constantes.TIPOMEDIO].ToString();
            lblDescModelo.Text = hParametros[Constantes.MODELO].ToString();
            lblPersona.Text = hParametros[Constantes.NOMEMPLEADO].ToString();
            lblDepartamento.Text = hParametros[Constantes.NOMDEPARTAMENTO].ToString();
            lblMigasPan.Text = Session[Constantes.MIGAS_PAN].ToString() + " > " + Constantes.MIGAS_PAN_EDITAR_CESION;
        }

        /// <summary>
        ///Realizamos la llamara para obtener los datos de la cesión.
        /// </summary>
        private void obtenerDatosCesion()
        {
            //Llamamos a la capa de negocio para obtener los datos de la cesión
            Cesion cesionAct = bll.buscarCesion(Convert.ToInt16(hOidCesion.Value), hOidEmpleado.Value, hOidDepartamento.Value);
            //Mostramos los valores en pantalla
            txtFecIniCesion.Text = Convert.ToDateTime(cesionAct.FecIni).ToShortDateString();            
            if (!cesionAct.FecFin.Equals(""))
            {
                txtFecFinCesion.Text = Convert.ToDateTime(cesionAct.FecFin).ToShortDateString();
            }
            txtComentCesion.Text = cesionAct.Comentarios;
            hOidCesion.Value = cesionAct.OidCesion.ToString();

            if (!cesionAct.FecFinProrroga.Equals(""))
            {
                //Si existe prorroga
                txtRespProrroga.Text = cesionAct.NombreEmpAuditoria;
                hRespProrroga.Value = cesionAct.EmpAuditoria;
                txtFinProrroga.Text = Convert.ToDateTime(cesionAct.FecFinProrroga).ToShortDateString();
                presentacionSiHayProrroga();
            }
            else
            {
                //Si no existe prorroga
                presentacionSiNoHayProrroga();
            }
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        /// <summary>
        /// Método para guardar un nuevo medio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            Cesion cesion = new Cesion(Convert.ToInt16(hOidCesion.Value),null,-1, this.txtFecIniCesion.Text,txtFecFinCesion.Text,
                                         this.hRespProrroga.Value,txtRespProrroga.Text, txtFinProrroga.Text, this.txtComentCesion.Text);
            
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;            
            
            int intGuardar;
            // Llamamos a la capa de negocio
            // al llamar a la capa de negocio pasamos un parametro para determinar si el destinatario es una persona (1) o un departamento (2).
            intGuardar = bll.actualizarCesion(cesion, !this.hOidEmpleado.Value.Equals("")?"1":"2");
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            //volvemos a la pantalla llamadora
            //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());
            Response.Redirect(Session[Constantes.VENTANAANTERIOR].ToString());
        }

        protected void chkProrrogado_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProrrogado.Checked)
            {
                presentacionSiHayProrroga();
            }
            else
            {
                presentacionSiNoHayProrroga();
            }
        }

        private void presentacionSiHayProrroga()
        {
            txtFinProrroga.ReadOnly = false;
            txtFinProrroga.Enabled = true;
            chkProrrogado.Checked = true;
            chkProrrogado.Enabled = true;
            btnPersona.Enabled = true;
            valFechaFinProrroga.Enabled = true;
            valEmpleado.Enabled = true;
            valProrrogaFecFinCesion.Enabled = true;
            valFecFinFecFinProrroga.Enabled = true;
            if (!string.IsNullOrEmpty(hOidFecBajaMedio.Value))
            {
                valFecFinProrrogaFecBajaMedio.Enabled = true;
            }
        }

        private void presentacionSiNoHayProrroga()
        {
            btnPersona.Enabled = false;
            txtRespProrroga.Text = "";
            hRespProrroga.Value = "";
            txtFinProrroga.ReadOnly = true;
            txtFinProrroga.Enabled = false;
            txtFinProrroga.Text = "";
            valFechaFinProrroga.Enabled = false;
            valEmpleado.Enabled = false;
            valProrrogaFecFinCesion.Enabled = false;
            valFecFinFecFinProrroga.Enabled = false;
            valFecFinProrrogaFecBajaMedio.Enabled = false;
            hRespProrroga.Value = "";
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        protected void btnInfoOk_Click(object sender, EventArgs e)
        {
            // Si todo ha ido correctamente volvemos a la pantalla llamadora.
            //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());
            Response.Redirect(Session[Constantes.VENTANAANTERIOR].ToString());
        }
    }
}