﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Bll;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web.UI.Cesiones
{
    public partial class MisCesiones : System.Web.UI.Page
    {
        #region Miembros privados

        protected static ASB.GMAP.Bll.MisCesiones bll;
        private MantMensajes manejador = new MantMensajes();
        private Dictionary<string, string> filtros = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        #region Manejadores de eventos

        protected void btnBuscarMisCesiones_Click(object sender, EventArgs e)
        {
            var mensajes = new MB.Framework.ManejadorMensajes.MensajesEntidad();
            bool hayMensajes = false;

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            cargarGrid();

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
        }

        

        protected void btnExcelMisCesiones_Click(object sender, EventArgs e)
        {
            filtros = (Dictionary<string, string>)ViewState["filtros"];

            var misCesiones = (DataSet)ViewState["misCesiones"];

            if (misCesiones != null)
            {
                filtros.Add("Medios cedidos a:", misCesiones.Tables[0].Rows[0][0].ToString());

                var exportador = new ExportadorExcel(misCesiones.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELA), filtros, lblTitulo.Text);
                exportador.Mapeos = bll.obtenerMapeosExcel();
                exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
                var bytes = exportador.exportarExcel();


                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
                Response.BinaryWrite(bytes);
                Response.End();
            }
        }

        #endregion

        #region Funciones auxiliares

        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_MIS_CESIONES, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.MisCesiones(ref manejador);

            // Aplicamos las acciones segun el perfil del usuario
            Util.aplicarAcciones(this);

            inicializarCombos();

            // Inicializamos los filtros para la exportación Excel
            filtros.Add(lblTipoMedio.Text, String.Empty);
            filtros.Add(lblCesiones.Text, String.Empty);

            ViewState["filtros"] = filtros;

            cargarGrid();
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;
           
           
        }

        private void cargarGrid()
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Variablen en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            // Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            // perdure a los postback de paginación
            ViewState["misCesiones"] = bll.buscarMisCesiones(Session[Constantes.IDEMPLEADO].ToString(),
                                                             Convert.ToInt16(ddlTipoMedio.SelectedValue),
                                                             Convert.ToInt16(ddlEstadoCesiones.SelectedValue),
                                                             out numRegistros);
            GridViewSortExpression = "";
            gvMisCesiones.DataSource = (DataSet)ViewState["misCesiones"];
            gvMisCesiones.DataBind();

            // Habilitamos la descarga a Excel solo si hay resultados
            alternarBotonExcel();
            
            // Guardamos los filtros usados en la consulta
            if (ViewState["filtros"] != null)
            {
                filtros = (Dictionary<string, string>)ViewState["filtros"];
            }
            filtros[lblTipoMedio.Text] = ddlTipoMedio.SelectedItem.Text;
            filtros[lblCesiones.Text] = ddlEstadoCesiones.SelectedItem.Text;

            ViewState["filtros"] = filtros;

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        

        private void alternarBotonExcel()
        {
            if (gvMisCesiones.Rows.Count > 0)
            {
                Util.intentarHabilitar(btnExcelMisCesiones);
            }
            else
            {
                btnExcelMisCesiones.Enabled = false;
            }
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MensajesEntidad> mensajes = new List<MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        private void inicializarCombos()
        {
            cargaComboTipoMedios(Session[Constantes.IDEMPLEADO].ToString());
            //Para el combo de Estado no tenemos tabla maestra por lo tanto introducimos los valores
            ddlEstadoCesiones.Items.Clear();
            ddlEstadoCesiones.Items.Add(new ListItem("Todos/as", "-1"));
            ddlEstadoCesiones.Items.Add(new ListItem("Activas", "1"));
            ddlEstadoCesiones.Items.Add(new ListItem("No Activas", "0"));
            ddlEstadoCesiones.SelectedIndex = 1;
        }

        private void cargaComboTipoMedios(string idEmpleado)
        {
            //La carga de este combo es un tanto especial ya que solamente se cargaran aquellos tipos de medios
            //que el empleado tenga asignados.
            DataTable dtCesionesTiposMedios = bll.cargaComboTipoMedios(idEmpleado);
            ddlTipoMedio.Items.Add(new ListItem("Todos/as", "-1"));
            foreach (DataRow dr in dtCesionesTiposMedios.Rows)
            {
                ddlTipoMedio.Items.Add(new ListItem(dr[Constantes.NOMBRE_TIPO_MEDIO_COMBO_CESIONES].ToString(), dr[Constantes.ID_TIPO_MEDIO_COMBO_CESIONES].ToString()));
            }            
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        #endregion

        #region ordenacion y paginacion Grid

        /// <summary>
        /// Evento de paginación del gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvMisCesiones_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                gvMisCesiones.PageIndex = e.NewPageIndex;
                recargaGrid();
            }
        }

        /// <summary>
        /// Método para recargar el grid en caso de paginación.
        /// </summary>
        private void recargaGrid()
        {
            DataTable dataTable = ((DataSet)ViewState["misCesiones"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpression))
                {
                    dataView.Sort = GridViewSortExpression + " " + GridViewSortDirection;
                }
                gvMisCesiones.DataSource = dataView;
                gvMisCesiones.DataBind();

            }
        }

        protected void gvMisCesiones_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["misCesiones"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpression(e.SortExpression);

                gvMisCesiones.DataSource = dataView;
                gvMisCesiones.DataBind();
            }
        }

        private string GetSortExpression(string sortExpression)
        {
            if (sortExpression == GridViewSortExpression && GridViewSortDirection ==Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpression = sortExpression;
            return sortExpression + " " + GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirection"] = value; }
        }
        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }

        protected void gvMisCesiones_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpression)
                        {
                            if (GridViewSortDirection.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        #endregion
    }
}