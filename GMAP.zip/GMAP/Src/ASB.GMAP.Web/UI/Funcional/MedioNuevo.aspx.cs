﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Ent;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Collections;

namespace ASB.GMAP.Web
{
    public partial class MedioNuevo : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.NuevoMedio bll;
        private MantMensajes manejador = new MantMensajes();
        protected List<Modelo> modelos;

        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_MEDIO_NUEVO, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.NuevoMedio(ref manejador);           
            //Primero inicializamos este combo, ya que en función del valor de elemento seleccionado habrá que realizar distintas operaciones
            inicializarComboTiposDeMedios();
            obtenerDatosTipoMedio();
            presentarPantalla();
            Session[Constantes.VENTANAANTERIOR] = Request.UrlReferrer.AbsolutePath.ToString();
           
        }

        /// <summary>
        /// obtemos los datos asociados al tipo de medio seleccionado
        /// Si tiene marca y modelo, si tiene extensión y si es entregable
        /// Obtenemos una datatable que almacenamos en la capa de negocio
        /// </summary>
        private void obtenerDatosTipoMedio()
        {
            bll.obtenerDatosTiposDeMedios();
        }

        /// <summary>
        /// Método para mostrar la pantalla al usuario en función del tipo de medio elegido
        /// </summary>
        private void presentarPantalla()
        {
            if (bll.tieneMarcaModelo(Convert.ToInt16(ddlTipoMedio.SelectedValue)))
            {
                //Si tiene marca y modelo cargamos los combos de marca y modelo
                ddlMarca.Enabled = true;
                //cargamos solamente aquellas marcas que tengan al menos un modelo asociado
                Combos.cargarCombosDesc(Constantes.MARCASMODELO, ddlMarca, false);
                ddlModelo.Enabled = true;
                cargaComboModelos(Convert.ToInt16(ddlMarca.SelectedValue));
            }
            else
            {
                ddlMarca.Enabled = false;
                ddlMarca.Items.Clear();
                ddlModelo.Enabled = false;
                ddlModelo.Items.Clear();
            }
            if (bll.tieneExtension(Convert.ToInt16(ddlTipoMedio.SelectedValue)))
            {
                //activamos la validación del campo
                valExtension.Enabled = true;
                txtExtension.ReadOnly = false;
            }
            else
            {
                txtExtension.Text = "";
                txtExtension.ReadOnly = true;
                valExtension.Enabled = false;
            }
            if (bll.esEntregable(Convert.ToInt16(ddlTipoMedio.SelectedValue)))
            {
                //si es entregable activamos la check
                chkEntregable.Checked = true;
            }
            else
            {
                chkEntregable.Checked = false;
            }
            txtFechaAlta.Text = DateTime.Now.ToShortDateString();
            Hashtable hParametros = (Hashtable)Session[Constantes.PARAMETROS];
            lblMigasPan.Text = Session[Constantes.MIGAS_PAN].ToString() + " > " + Constantes.MIGAS_PAN_MEDIO_NUEVO;
        }

        /// <summary>
        /// Cargamos los modelos asociados a la marca seleccinada
        /// </summary>
        /// <param name="oidMarca"></param>
        private void cargaComboModelos(int oidMarca)
        {
            // Cargamos la combo
            modelos = bll.obtenerListaModelos(oidMarca);

            ddlModelo.Items.Clear();
            ddlModelo.Items.Clear();
            foreach (Modelo modeloAct in modelos)
            {
                ddlModelo.Items.Add(new ListItem(modeloAct.Nombre, modeloAct.OidModelo.ToString()));                
            }
        }

        private void inicializarComboTiposDeMedios()
        {
            Combos.cargarCombosDescPerfil(Constantes.TIPOSDEMEDIOS, ddlTipoMedio,Session[Constantes.ID_PERFIL].ToString(), false);            
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        /// <summary>
        /// Método para guardar un nuevo medio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            Medio medio = new Medio(0, Convert.ToInt16(this.ddlTipoMedio.SelectedValue),
                                                       Convert.ToInt16(ddlModelo.SelectedValue.Equals("") ? "-1" : ddlModelo.SelectedValue),
                                                       Convert.ToInt16(this.ddlMarca.SelectedValue.Equals("") ? "-1" : this.ddlMarca.SelectedValue), 
                                                       this.txtID.Text, this.txtFechaAlta.Text,"",this.txtExtension.Text, this.txtComentarios.Text);
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false; 
           
            int intGuardar;
            ////Llamamos a la capa de negocio
            //al llamar a la capa de negocio pasamos un parametro para determinar si el destinatario es una persona (1) o un departamento (2) o ninguno (0).
            intGuardar = bll.guardarMedioNuevo(medio);
            //// Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void ddlMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            cargaComboModelos(Convert.ToInt16(ddlMarca.SelectedValue));
        }

        protected void ddlTipoMedio_SelectedIndexChanged(object sender, EventArgs e)
        {
            presentarPantalla();
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            string migas = Session[Constantes.MIGAS_PAN].ToString();
            string[] arrMigas = migas.Split('>');
            Session[Constantes.MIGAS_PAN] = arrMigas[0];
            ////Si se cancela la inserción volvemos a la pantalla llamadora.

            //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());
            Response.Redirect(Session[Constantes.VENTANAANTERIOR].ToString());
        }

        private void mostrarPopUp(string mensaje)
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (!hayMensajes || (mensajes.TipoMensaje != Mensajes.tiposMensaje.Error))
            {
                //Si los datos se han guardado correctamente limpiamos la pantalla por si el usuario quiere dar de alta más medios.
                limpiarPantalla();
            }    
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }       

        private void limpiarPantalla()
        {
            ddlTipoMedio.SelectedIndex = 0;
            txtComentarios.Text = "";
            txtExtension.Text = "";
            txtID.Text = "";
        }

    }
}