﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Bll;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Web;

namespace ASB.GMAP.Web
{
    public partial class GestionAlertas : System.Web.UI.Page
    {
        #region Miembros privados

        protected static ASB.GMAP.Bll.GestionAlertas bll;
        private MantMensajes manejador = new MantMensajes();
        private Dictionary<string, string> filtrosPersonas = new Dictionary<string, string>();
        private Dictionary<string, string> filtrosDepartamentos = new Dictionary<string, string>();

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session["LOGINUSUARIO"] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED, false);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        #region Manejadores de eventos del fildset Personas

        protected void btnBuscarCesionesPersonas_Click(object sender, EventArgs e)
        {
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Controlamos que la sesión no haya expirado
            if (Session["LOGINUSUARIO"] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED, false);
            }

            //Variablen en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            //Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            //perdure a los postback de paginación
            ViewState["cesionesPersonas"] = bll.buscarCesionesPersonas(txtNombrePersona.Text,
                                                                       Convert.ToInt32(ddlTipoMedioPersona.SelectedValue),
                                                                       Convert.ToInt32(ddlProrrogadoPersona.SelectedValue),
                                                                       Session["intIDPerfil"].ToString(),
                                                                       out numRegistros);
            GridViewSortExpressionPersonas = "";
            gvCesionesPersonas.DataSource = (DataSet)ViewState["cesionesPersonas"];
            gvCesionesPersonas.DataBind();

            if (gvCesionesPersonas.Rows.Count > 0)
            {
                Util.intentarHabilitar(btnExcelPersonas);
                Util.intentarHabilitar(btnFinalizarCesionEmpleado);
            }
            else
            {
                btnExcelPersonas.Enabled = false;
                btnFinalizarCesionEmpleado.Enabled = false;
            }

            // Guardamos los filtros usados en la consulta
            if (ViewState["filtrosPersonas"] != null)
            {
                filtrosPersonas = (Dictionary<string, string>)ViewState["filtrosPersonas"];
            }
            filtrosPersonas[lblNombreEmpleado.Text] = txtNombrePersona.Text;
            filtrosPersonas[lblTipoMedioPer.Text] = ddlTipoMedioPersona.SelectedItem.Text;
            filtrosPersonas[lblProrrogadoPer.Text] = ddlProrrogadoPersona.SelectedItem.Text;

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnFinalizarCesionEmpleado_Click(object sender, EventArgs e)
        {
            if (esCesionActivaEmpleado())
            {
                parametrosFinalizarCesionEmpleado();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("FinalizarCesion.aspx", false);
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        ///// <summary>
        /////Creamos una estructura lifo, de tal manera que se puedan recuperar las ventanas llamadoras hacia atrás
        ///// </summary>
        //private void crearPilaVentanaLlamadora()
        //{
        //    Stack<string> stack = new Stack<string>();
        //    stack.Push("GestionAlertas.aspx");
        //    Session[Constantes.VENTANALLAMADORA] = stack;
        //}

        /// <summary>
        /// Parámetros para pasar a la pantalla de Finalizar Cesión
        /// </summary>
        private void parametrosFinalizarCesionEmpleado()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesionesEmpleado();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de cesión
            //Como estamos en el grid de gestión de personas pasamos el identificativo de departamento vacio
            //De esta manera en la pantalla de edición de cesión ya se sabe que es una cesión a un empleado
            hParametros.Add(Constantes.OIDDEPARTAMENTO, "");
            hParametros.Add(Constantes.NOMDEPARTAMENTO, "");

            Session["parametros"] = hParametros;
        }

        /// <summary>
        /// Obtenemos los datos de la cesión seleccionada para pasar los parámetros a las distintas pantallas
        /// </summary>
        /// <returns>Hastable con los datos de la cesión seleccionada</returns>
        private Hashtable obtenerDatosGridCesionesEmpleado()
        {
            Hashtable hParametros = new Hashtable();
            //obtenemos el empleado seleccionado para filtrar sus cesiones
            foreach (GridViewRow di in gvCesionesPersonas.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkCesionEmpleadoSeleccionada");

                if (chkBx != null && chkBx.Checked)
                {
                    hParametros.Add(Constantes.TIPOMEDIO, gvCesionesPersonas.DataKeys[di.RowIndex].Values["VAR_NOMBREENTERO"].ToString());
                    //el ID del medio
                    hParametros.Add(Constantes.IDMEDIO,gvCesionesPersonas.DataKeys[di.RowIndex].Values["VAR_CODIGMEDIOENTERO"].ToString());
                    //Nombre del empleado
                    hParametros.Add(Constantes.NOMEMPLEADO, gvCesionesPersonas.DataKeys[di.RowIndex].Values["NOMBREEMPLEADOENTERO"].ToString());
                    //las columnas ocultas del grid están asociadas al mismo como dataKeys ya que sobre
                    //una columna visible = false no se puden obtener sus datos.
                    hParametros.Add(Constantes.OIDCESION, gvCesionesPersonas.DataKeys[di.RowIndex].Values["INT_OIDCESIONEMPLEADO"].ToString());
                    hParametros.Add(Constantes.OIDEMPLEADO, gvCesionesPersonas.DataKeys[di.RowIndex].Values["STRNUMEMPLEADO"].ToString());
                    hParametros.Add(Constantes.FBAJAMEDIO, gvCesionesPersonas.DataKeys[di.RowIndex].Values["DAT_FBAJA"].ToString());
                    hParametros.Add(Constantes.OIDMEDIO, gvCesionesPersonas.DataKeys[di.RowIndex].Values["INT_OIDMEDIO"].ToString());
                    hParametros.Add(Constantes.MODELO, gvCesionesPersonas.DataKeys[di.RowIndex].Values["nombreModeloEntero"].ToString());
                    break;
                }
            }
            Session["migasPan"] = Constantes.MIGAS_PAN_GESTION_ALERTAS;
            return hParametros;
        }

        /// <summary>
        /// Comprueba si la cesión seleccionada está activa o no
        /// </summary>
        /// <returns>true o false en función si la cesión está activa o no</returns>
        private bool esCesionActivaEmpleado()
        {
            bool activa = false;
            foreach (GridViewRow di in gvCesionesPersonas.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkCesionEmpleadoSeleccionada");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos si la cesión está activa o no
                    activa = gvCesionesPersonas.DataKeys[di.RowIndex].Values["esCesionActiva"].ToString().Equals("Si") ? true : false;                    
                    break;
                }
            }
            return activa;
        }

        protected void btnExcelPersonas_Click(object sender, EventArgs e)
        {
            // Recuperamos los filtros de la consulta
            filtrosPersonas = (Dictionary<string, string>)ViewState["filtrosPersonas"];

            var cesionesPersonas = (DataSet)ViewState["cesionesPersonas"];

            if (cesionesPersonas != null)
            {
                filtrosPersonas.Add("Medios cedidos a:", cesionesPersonas.Tables[0].Rows[0][1].ToString());

                var exportador = new ExportadorExcel(cesionesPersonas.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELC), filtrosPersonas, lblTitulo.Text);
                exportador.Mapeos = bll.obtenerMapeosExcelPersonas();
                exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
                var bytes = exportador.exportarExcel();


                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
                Response.BinaryWrite(bytes);
                Response.End();
            }
        }

        #endregion

        #region Manejadores de eventos del fieldset Departamentos

        protected void btnBuscarCesionesDepartamentos_Click(object sender, EventArgs e)
        {
            var mensajes = new MB.Framework.ManejadorMensajes.MensajesEntidad();
            bool hayMensajes = false;

            // Variable en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            ViewState["cesionesDepartamentos"] = bll.buscarCesionesDepartamentos(txtNombreDepartamento.Text,
                                                                                 Convert.ToInt16(ddlTipoMedioDepartamento.SelectedValue),
                                                                                 Convert.ToInt16(ddlProrrogadoDepartamento.SelectedValue),
                                                                                 Session["intIDPerfil"].ToString(),
                                                                                 out numRegistros);
            GridViewSortExpressionDepartamentos = "";
            gvCesionesDepartamentos.DataSource = (DataSet)ViewState["cesionesDepartamentos"];
            gvCesionesDepartamentos.DataBind();

            if (gvCesionesDepartamentos.Rows.Count > 0)
            {
                Util.intentarHabilitar(btnExcelDepartamentos);
                Util.intentarHabilitar(btnFinalizarCesionDepartamento);
            }
            else
            {
                btnExcelDepartamentos.Enabled = false;
                btnFinalizarCesionDepartamento.Enabled = false;
            }

            // Guardamos los filtros usados en la consulta
            if (ViewState["filtrosDepartamentos"] != null)
            {
                filtrosPersonas = (Dictionary<string, string>)ViewState["filtrosDepartamentos"];
            }
            filtrosDepartamentos[lblNombreDepartamento.Text] = txtNombreDepartamento.Text;
            filtrosDepartamentos[lblTipoMedioDept.Text] = ddlTipoMedioDepartamento.SelectedItem.Text;
            filtrosDepartamentos[lblProrrogadoDept.Text] = ddlProrrogadoDepartamento.SelectedItem.Text;

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnFinalizarCesionDepartamento_Click(object sender, EventArgs e)
        {
            if (esCesionActivaDepartamento())
            {
                parametrosFinalizarCesionDepartamento();
                persistirEstadoPagina();
                //crearPilaVentanaLlamadora();
                Response.Redirect("FinalizarCesion.aspx", false);
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Finalizar Cesión
        /// </summary>
        private void parametrosFinalizarCesionDepartamento()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesionesDepartamento();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de cesión
            //Como estamos en el grid de gestión de departamentos pasamos el identificativo de usuario vacio
            //De esta manera en la pantalla de edición de cesión ya se sabe que es una cesión a un departamento
            hParametros.Add(Constantes.OIDEMPLEADO, "");
            hParametros.Add(Constantes.NOMEMPLEADO, "");

            Session["parametros"] = hParametros;
        }

        /// <summary>
        /// Obtenemos los datos de la cesión seleccionada para pasar los parámetros a las distintas pantallas
        /// </summary>
        /// <returns>Hastable con los datos de la cesión seleccionada</returns>
        private Hashtable obtenerDatosGridCesionesDepartamento()
        {
            Hashtable hParametros = new Hashtable();
            //obtenemos el empleado seleccionado para filtrar sus cesiones
            foreach (GridViewRow di in gvCesionesDepartamentos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkCesionDepartamentoSeleccionada");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos el tipo de medio
                    hParametros.Add(Constantes.TIPOMEDIO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["VAR_NOMBREENTERO"].ToString());
                    //el ID del medio
                    hParametros.Add(Constantes.IDMEDIO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["VAR_CODIGMEDIOENTERO"].ToString());
                    //Nombre del departamento
                    hParametros.Add(Constantes.NOMBREDEPARTAMENTO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["DESC_ORGUNITENTERO"].ToString());
                    //las columnas ocultas del grid están asociadas al mismo como dataKeys ya que sobre
                    //una columna visible = false no se puden obtener sus datos.
                    hParametros.Add(Constantes.OIDCESION, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["INT_OIDCESIONDEPARTAMENTO"].ToString());
                    hParametros.Add(Constantes.OIDDEPARTAMENTO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["ID_ORGUNIT"].ToString());
                    hParametros.Add(Constantes.FBAJAMEDIO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["DAT_FBAJA"].ToString());
                    hParametros.Add(Constantes.OIDMEDIO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["INT_OIDMEDIO"].ToString());
                    hParametros.Add(Constantes.MODELO, gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["nombreModeloEntero"].ToString());
                    break;
                }
            }
            Session["migasPan"] = Constantes.MIGAS_PAN_GESTION_ALERTAS;
            return hParametros;
        }

        /// <summary>
        /// Comprueba si la cesión seleccionada está activa o no
        /// </summary>
        /// <returns>true o false en función si la cesión está activa o no</returns>
        private bool esCesionActivaDepartamento()
        {
            bool activa = false;
            foreach (GridViewRow di in gvCesionesDepartamentos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("chkCesionDepartamentoSeleccionada");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos si la cesión está activa o no
                    activa = gvCesionesDepartamentos.DataKeys[di.RowIndex].Values["esCesionActiva"].ToString().Equals("Si") ? true : false;                    
                    break;
                }
            }
            return activa;
        }

        protected void btnExcelDepartamentos_Click(object sender, EventArgs e)
        {
            // Recuperamos los filtros de la consulta
            filtrosPersonas = (Dictionary<string, string>)ViewState["filtrosDepartamentos"];

            var cesionesDepartamentos = (DataSet)ViewState["cesionesDepartamentos"];

            if (cesionesDepartamentos != null)
            {
                filtrosPersonas.Add("Medios cedidos a:", cesionesDepartamentos.Tables[0].Rows[0][0].ToString());

                var exportador = new ExportadorExcel(cesionesDepartamentos.Tables[0], Server.MapPath(Constantes.RUTA_PLANTILLA_EXCELD), filtrosDepartamentos, lblTitulo.Text);
                exportador.Mapeos = bll.obtenerMapeosExcelDepartamentos();
                exportador.CamposCentrados = Constantes.CAMPOSCENTRADOS;
                var bytes = exportador.exportarExcel();

                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("Content-Disposition", "attachment;filename=informe.xlsx");
                Response.BinaryWrite(bytes);
                Response.End();
            }
        }

        #endregion

        #region Funciones auxiliares

        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_GESTION_ALERTAS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.GestionAlertas(ref manejador);

            // Aplicamos las acciones segun el perfil del usuario
            Util.aplicarAcciones(this);
            //Los botones de edición de cesión tienen que estar deshabilitados hasta que no haya resultados en los grids
            btnFinalizarCesionDepartamento.Enabled = false;
            btnFinalizarCesionEmpleado.Enabled = false;

            btnExcelDepartamentos.Enabled = false;
            btnExcelPersonas.Enabled = false;

            inicializarCombos();

            // Inicializamos los filtros para la exportación Excel
            filtrosPersonas.Add(lblNombreEmpleado.Text, String.Empty);
            filtrosPersonas.Add(lblTipoMedioPer.Text, String.Empty);
            filtrosPersonas.Add(lblProrrogadoPer.Text, String.Empty);

            ViewState["filtrosPersonas"] = filtrosPersonas;

            filtrosDepartamentos.Add(lblNombreDepartamento.Text, String.Empty);
            filtrosDepartamentos.Add(lblTipoMedioDept.Text, String.Empty);
            filtrosDepartamentos.Add(lblProrrogadoDept.Text, String.Empty);

            ViewState["filtrosDepartamentos"] = filtrosDepartamentos;
            presentarPantalla();
           
            //cargamos los grids
            btnBuscarCesionesPersonas_Click(null, null);
            btnBuscarCesionesDepartamentos_Click(null, null);
           
        }

        /// <summary>
        /// Guardamos el estado de la página para poderla recuperar cuando el usuario vuelva
        /// </summary>
        private void persistirEstadoPagina()
        {
            Hashtable hParametros = new Hashtable();
            hParametros.Add(Constantes.PANTALLA_ALERTAS_EMPLEADOS_NOMBRE, txtNombrePersona.Text);
            hParametros.Add(Constantes.PANTALLA_ALERTAS_EMPLEADOS_TIPO_MEDIO, ddlTipoMedioPersona.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_ALERTAS_EMPLEADOS_PRORROGADO, ddlProrrogadoPersona.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_ALERTAS_DEPARTAMENTO_NOMBRE, txtNombreDepartamento.Text);
            hParametros.Add(Constantes.PANTALLA_ALERTAS_DEPARTAMENTO_TIPO_MEDIO, ddlTipoMedioDepartamento.SelectedValue);
            hParametros.Add(Constantes.PANTALLA_ALERTAS_DEPARTAMENTO_PRORROGADO, ddlProrrogadoDepartamento.SelectedValue);
            Session["estadoPantallaPersonasDepartamentosMediosAlertas"] = hParametros;
        }

        /// <summary>
        /// Si venimos de vuelta a la pantalla de alguna de sus paginas "hijas" cargamos el estado de la pantalla
        /// </summary>
        private void presentarPantalla()
        {
            if (Session["estadoPantallaPersonasDepartamentosMediosAlertas"] != null && Session["migasPan"].ToString().Contains(Constantes.MIGAS_PAN_GESTION_ALERTAS))
            {
                Hashtable hParametros = (Hashtable)Session["estadoPantallaPersonasDepartamentosMediosAlertas"];

                txtNombrePersona.Text = hParametros[Constantes.PANTALLA_ALERTAS_EMPLEADOS_NOMBRE].ToString();
                ddlTipoMedioPersona.SelectedValue = hParametros[Constantes.PANTALLA_ALERTAS_EMPLEADOS_TIPO_MEDIO].ToString();
                ddlProrrogadoPersona.SelectedValue = hParametros[Constantes.PANTALLA_ALERTAS_EMPLEADOS_PRORROGADO].ToString();
                txtNombreDepartamento.Text = hParametros[Constantes.PANTALLA_ALERTAS_DEPARTAMENTO_NOMBRE].ToString();
                ddlTipoMedioDepartamento.SelectedValue = hParametros[Constantes.PANTALLA_ALERTAS_DEPARTAMENTO_TIPO_MEDIO].ToString();
                ddlProrrogadoDepartamento.SelectedValue = hParametros[Constantes.PANTALLA_ALERTAS_DEPARTAMENTO_PRORROGADO].ToString();
                //btnBuscarCesionesDepartamentos_Click(null, null);
                //btnBuscarCesionesPersonas_Click(null, null);
             }

            Session["estadoPantallaPersonasDepartamentosMediosAlertas"] = null;

        }

        /// <summary>
        /// Muestra los mensajes que se producen al cargar la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MensajesEntidad> mensajes = new List<MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        private void inicializarCombos()
        {
            Combos.cargarCombosDescPerfil(Constantes.TIPOSDEMEDIOS, ddlTipoMedioPersona, Session["intIDPerfil"].ToString(), true);
            Combos.cargarCombosDescPerfil(Constantes.TIPOSDEMEDIOS, ddlTipoMedioDepartamento, Session["intIDPerfil"].ToString(), true);

            //Para el combo de prorrogado no tenemos tabla maestra por lo tanto introducimos los valores
            ddlProrrogadoPersona.Items.Clear();
            ddlProrrogadoPersona.Items.Add(new ListItem("Todos/as", "-1"));
            ddlProrrogadoPersona.Items.Add(new ListItem("Si", "1"));
            ddlProrrogadoPersona.Items.Add(new ListItem("No", "0"));

            //Para el combo de prorrogado no tenemos tabla maestra por lo tanto introducimos los valores
            ddlProrrogadoDepartamento.Items.Clear();
            ddlProrrogadoDepartamento.Items.Add(new ListItem("Todos/as", "-1"));
            ddlProrrogadoDepartamento.Items.Add(new ListItem("Si", "1"));
            ddlProrrogadoDepartamento.Items.Add(new ListItem("No", "0"));
        }

        #endregion

        #region ordenacion y paginacion Grid

        protected void gvCesionesPersonas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                gvCesionesPersonas.PageIndex = e.NewPageIndex;
                recargaGridPersonas();
            }
        }

        /// <summary>
        /// Método para recargar el grid en caso de paginación.
        /// </summary>
        private void recargaGridPersonas()
        {
            DataTable dataTable = ((DataSet)ViewState["cesionesPersonas"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpressionPersonas))
                {
                    dataView.Sort = GridViewSortExpressionPersonas + " " + GridViewSortDirectionPersonas;
                }
                gvCesionesPersonas.DataSource = dataView;
                gvCesionesPersonas.DataBind();

            }
        }

        /// <summary>
        /// Método para recargar el grid en caso de paginación.
        /// </summary>
        private void recargaGridDepartamentos()
        {
            DataTable dataTable = ((DataSet)ViewState["cesionesDepartamentos"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpressionDepartamentos))
                {
                    dataView.Sort = GridViewSortExpressionDepartamentos + " " + GridViewSortDirectionDepartamentos;
                }
                gvCesionesDepartamentos.DataSource = dataView;
                gvCesionesDepartamentos.DataBind();

            }
        }

        protected void gvCesionesDepartamentos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                gvCesionesDepartamentos.PageIndex = e.NewPageIndex;
                recargaGridDepartamentos();
            }
        }

        protected void gvCesionesPersonas_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["cesionesPersonas"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionPersonas(e.SortExpression);

                gvCesionesPersonas.DataSource = dataView;
                gvCesionesPersonas.DataBind();
            }
        }

        private string GetSortExpressionPersonas(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionPersonas && GridViewSortDirectionPersonas == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionPersonas = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionPersonas = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionPersonas = sortExpression;
            return sortExpression + " " + GridViewSortDirectionPersonas;
        }

        private string GridViewSortDirectionPersonas
        {
            get { return ViewState["SortDirectionPersonas"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionPersonas"] = value; }
        }
        private string GridViewSortExpressionPersonas
        {
            get { return ViewState["SortExpressionPersonas"] as string ?? string.Empty; }
            set { ViewState["SortExpressionPersonas"] = value; }
        }

        protected void gvCesionesPersonas_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionPersonas)
                        {
                            if (GridViewSortDirectionPersonas.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        protected void gvCesionesDepartamentos_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["cesionesDepartamentos"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionDepartamentos(e.SortExpression);

                gvCesionesDepartamentos.DataSource = dataView;
                gvCesionesDepartamentos.DataBind();
            }
        }

        private string GetSortExpressionDepartamentos(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionDepartamentos && GridViewSortDirectionDepartamentos == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionDepartamentos = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionDepartamentos = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionDepartamentos = sortExpression;
            return sortExpression + " " + GridViewSortDirectionDepartamentos;
        }

        private string GridViewSortDirectionDepartamentos
        {
            get { return ViewState["SortDirectionDepartamentos"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionDepartamentos"] = value; }
        }
        private string GridViewSortExpressionDepartamentos
        {
            get { return ViewState["SortExpressionDepartamentos"] as string ?? string.Empty; }
            set { ViewState["SortExpressionDepartamentos"] = value; }
        }

        protected void gvCesionesDepartamentos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionDepartamentos)
                        {
                            if (GridViewSortDirectionDepartamentos.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        #endregion

        protected void btnEditarDeptartamento_Click(object sender, EventArgs e)
        {
            if (esCesionActivaDepartamento())
            {
                parametrosEditarCesionDepartamento();
                persistirEstadoPagina();
                Response.Redirect("EditarCesion.aspx", false);
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Editar Cesión
        /// </summary>
        private void parametrosEditarCesionDepartamento()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesionesDepartamento();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de cesión
            //Como estamos en el grid de gestión de departamentos pasamos el identificativo de usuario vacio
            //De esta manera en la pantalla de edición de cesión ya se sabe que es una cesión a un departamento
            hParametros.Add(Constantes.OIDEMPLEADO, "");
            hParametros.Add(Constantes.NOMEMPLEADO, "");

            Session["parametros"] = hParametros;
        }

        protected void btnEditarPersona_Click(object sender, EventArgs e)
        {
            if (esCesionActivaEmpleado())
            {
                parametrosEditarCesionEmpleado();
                persistirEstadoPagina();
                Response.Redirect("EditarCesion.aspx", false);
            }
            else
            {
                mostrarPopUp(Constantes.MENSAJECESIONACTIVA);
            }
        }

        /// <summary>
        /// Parámetros para pasar a la pantalla de Editar Cesión
        /// </summary>
        private void parametrosEditarCesionEmpleado()
        {
            //obtenmos los datos de la cesión seleccionada
            Hashtable hParametros = obtenerDatosGridCesionesEmpleado();
            //Pasamos los parametros para que sean recogidos por la pantalla de edición de cesión
            //Como estamos en el grid de gestión de personas pasamos el identificativo de departamento vacio
            //De esta manera en la pantalla de edición de cesión ya se sabe que es una cesión a un empleado
            hParametros.Add(Constantes.OIDDEPARTAMENTO, "");
            hParametros.Add(Constantes.NOMDEPARTAMENTO, "");

            Session["parametros"] = hParametros;
        }
        
    }
}