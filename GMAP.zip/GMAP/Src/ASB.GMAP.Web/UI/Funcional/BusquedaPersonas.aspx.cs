﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Combo;
using MB.Framework.Log;
using ASB.GMAP.Bll;
using ASB.GMAP.Ent;
using System.Data;


namespace ASB.GMAP.Web
{
    public partial class BusquedaPersonas : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.BusquedaPersonas bll;
        private MantMensajes manejador = new MantMensajes();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

			// Comprobamos que tiene acceso a la página
            //if (!Util.tieneAcceso(this.Context))
            //{
            //    Response.Redirect(Constantes.PAG_PERFIL_NOAUTH);
            //}
            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        protected void btnSeleccionar_Click(object sender, EventArgs e)
        {
            string nombreApellidos = String.Empty;
            string codEmpleado = String.Empty;

            foreach (GridViewRow di in grdPersonas.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos el nombre y los apellidos para pasarlos a la pantalla padre
                    nombreApellidos = grdPersonas.DataKeys[di.RowIndex].Values["NombreEmpleadoEntero"].ToString();

                    //las columnas ocultas del grid están asociadas al mismo como dataKeys ya que sobre
                    //una columna visible = false no se puden obtener sus datos.
                    codEmpleado = grdPersonas.DataKeys[di.RowIndex].Values["strNumEmpleado"].ToString();
                    break;
                }
            }
            //trasladamos los datos de la persona seleccionada a la pantalla padre
            ScriptManager.RegisterClientScriptBlock(this.Page, GetType(), "trasladarValores", "trasladarValores('" + nombreApellidos + "','" + codEmpleado + "');", true);
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarPersonas();
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_BUSQUEDA_PERSONAS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.BusquedaPersonas(ref manejador);
            inicializarCombos();
            buscarPersonas();
        }

        /// <summary>
        /// método encargado de realizar la carga del gridview de personas
        /// </summary>
        private void buscarPersonas()
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            //Variable en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            FiltroPersona filtroPer = new FiltroPersona(Convert.ToInt16(ddlEstado.SelectedValue), this.TxtBusqueda.Text
                                                        , ddlEmpresa.SelectedValue.ToString(), ddlContrato.SelectedValue.ToString());
            ViewState["grdPersonas"] = bll.buscarPersonas(filtroPer, out numRegistros);
            GridViewSortExpressionPersonas = "";
            grdPersonas.DataSource = ViewState["grdPersonas"]; 
            grdPersonas.DataBind();
            
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        private void inicializarCombos()
        {
            Combos.cargarCombos(Constantes.EMPRESAS, ddlEmpresa, true);

            //Para el combo de contrato no tenemos tabla maestra por lo tanto introducimos los valores
            ddlContrato.Items.Clear();
            ddlContrato.Items.Add(new ListItem(Constantes.TEXTO_DEFECTO_COMBO, Constantes.VALOR_DEFECTO_COMBO));
            ddlContrato.Items.Add(new ListItem("Interno", "Interno"));
            ddlContrato.Items.Add(new ListItem("Externo", "Externo"));
            //Para el combo de estado no tenemos tabla maestra por lo tanto introducimos lo valores
            ddlEstado.Items.Clear();
            ddlEstado.Items.Add(new ListItem(Constantes.TEXTO_DEFECTO_COMBO, Constantes.VALOR_DEFECTO_COMBO));
            ddlEstado.Items.Add(new ListItem("Activo", "0"));
            ddlEstado.Items.Add(new ListItem("Inactivo", "1"));
            //si obtenemos como parametro de pagina solo empleados internos
            if (Convert.ToBoolean(Request.QueryString["soloInternos"]))
            {
                ddlContrato.SelectedIndex = 1;
                ddlContrato.Enabled = false;
                //si solo son empleados internos estaremos en un búsqueda de empleados que puedan autorizar 
                //una prorroga para una cesión, por lo tanto tambien tendrá que ser un empleado activo
                ddlEstado.SelectedIndex = 1;
                ddlEstado.Enabled = false;
            }            
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);

            }
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        protected void grdPersonas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                DataTable dataTable = ((DataSet)ViewState["grdPersonas"]).Tables[0];
                if (dataTable != null)
                {
                    DataView dataView = new DataView(dataTable);
                    if (!string.IsNullOrEmpty(GridViewSortExpressionPersonas))
                    {
                        dataView.Sort = GridViewSortExpressionPersonas + " " + GridViewSortDirectionPersonas;
                    }
                    grdPersonas.PageIndex = e.NewPageIndex;
                    grdPersonas.DataSource = dataView;
                    grdPersonas.DataBind();

                }
            }
        }
        protected void grdPersonas_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["grdPersonas"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionPersonas(e.SortExpression);

                grdPersonas.DataSource = dataView;
                grdPersonas.DataBind();

            }
        }

        private string GetSortExpressionPersonas(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionPersonas && GridViewSortDirectionPersonas == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionPersonas = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionPersonas = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionPersonas = sortExpression;
            return sortExpression + " " + GridViewSortDirectionPersonas;
        }

        private string GridViewSortDirectionPersonas
        {
            get { return ViewState["SortDirectionPersonas"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionPersonas"] = value; }
        }
        private string GridViewSortExpressionPersonas
        {
            get { return ViewState["SortExpressionPersonas"] as string ?? string.Empty; }
            set { ViewState["SortExpressionPersonas"] = value; }
        }

        protected void grdPersonas_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionPersonas)
                        {
                            if (GridViewSortDirectionPersonas.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }
    }
}