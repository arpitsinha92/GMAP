﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Combo;
using MB.Framework.Log;
using ASB.GMAP.Bll;
using ASB.GMAP.Ent;
using System.Data;

namespace ASB.GMAP.Web
{
    public partial class BusquedaDepartamentos : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.BusquedaDepartamentos bll;
        private MantMensajes manejador = new MantMensajes();
        protected List<Empresa> empresas;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

			// Comprobamos que tiene acceso a la página
            //if (!Util.tieneAcceso(this.Context))
            //{
            //    Response.Redirect(Constantes.PAG_PERFIL_NOAUTH);
            //}
            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_BUSQUEDA_DEPARTAMENTOS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.BusquedaDepartamentos(ref manejador);
            inicializarCombos();
            buscarDepartamentos();
           
           
        }

        

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarDepartamentos();
        }

        /// <summary>
        /// método encargado de realizar la carga del gridview de departamentos
        /// </summary>
        private void buscarDepartamentos()
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            //Variable en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            FiltroDepartamento filtroDept = new FiltroDepartamento(this.TxtBusqueda.Text, ddlEmpresa.SelectedValue.ToString(),-1);
            //Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            //perdure a los postback de paginación
            ViewState["dsGrid"] = bll.buscarDepartamentos(filtroDept, out numRegistros);
            GridViewSortExpressionEmpresa = "";
            recargaGrid();
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        private void inicializarCombos()
        {
            // obtenemos las empresas para cargar la combo
            Combos.cargarCombos(Constantes.EMPRESAS, ddlEmpresa, true);
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);

            }
        }

        protected void btnSeleccionar_Click(object sender, EventArgs e)
        {
            string nombreDept = String.Empty;
            string codDept = String.Empty;

            foreach (GridViewRow di in grdDepartamentos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    //Para la fila seleccionada obtenemos el nombre para pasarlos a la pantalla padre
                    nombreDept = grdDepartamentos.DataKeys[di.RowIndex].Values["desc_orgunitEntero"].ToString();

                    //las columnas ocultas del grid están asociadas al mismo como dataKeys ya que sobre
                    //una columna visible = false no se puden obtener sus datos.
                    codDept = grdDepartamentos.DataKeys[di.RowIndex].Values["id_orgunit"].ToString();
                    break;
                }
            }
            //trasladamos los datos de la persona seleccionada a la pantalla padre
            ScriptManager.RegisterClientScriptBlock(this.Page, GetType(), "trasladarValores", "trasladarValores('" + nombreDept + "','" + codDept + "');", true);
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        /// <summary>
        /// Evento de paginación del gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdDepartamentos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                grdDepartamentos.PageIndex = e.NewPageIndex;
                recargaGrid();
            }

        }

        /// <summary>
        /// Método para recargar el grid en caso de paginación.
        /// </summary>
        private void recargaGrid()
        {
            DataTable dataTable = ((DataSet)ViewState["dsGrid"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpressionEmpresa))
                {
                    dataView.Sort = GridViewSortExpressionEmpresa + " " + GridViewSortDirectionEmpresa;
                }
                grdDepartamentos.DataSource = dataView;
                grdDepartamentos.DataBind();

            }
        }

        protected void grdDepartamentos_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGrid"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionEmpresa(e.SortExpression);

                grdDepartamentos.DataSource = dataView;
                grdDepartamentos.DataBind();

            }
        }

        private string GetSortExpressionEmpresa(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionEmpresa && GridViewSortDirectionEmpresa == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionEmpresa = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionEmpresa = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionEmpresa = sortExpression;
            return sortExpression + " " + GridViewSortDirectionEmpresa;
        }

        private string GridViewSortDirectionEmpresa
        {
            get { return ViewState["SortDirectionEmpresa"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionEmpresa"] = value; }
        }
        private string GridViewSortExpressionEmpresa
        {
            get { return ViewState["SortExpressionEmpresa"] as string ?? string.Empty; }
            set { ViewState["SortExpressionEmpresa"] = value; }
        }

        protected void grdDepartamentos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionEmpresa)
                        {
                            if (GridViewSortDirectionEmpresa.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }
    }
}