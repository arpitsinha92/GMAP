﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using ASB.GMAP.Ent;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Web
{
    public partial class FinalizarCesion : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.FinalizarCesion bll;
        //private static int contador = 0;
        private MantMensajes manejador = new MantMensajes();
        
        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_FINALIZAR_CESION, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.FinalizarCesion(ref manejador);
            val_fecBajaMedioMayorHoy.ValueToCompare = DateTime.Now.ToShortDateString();
            //Recuperamos de la sesion los parámetros para hacer la búsqueda de la cesión
            recuperarDatosSesion();
            obtenerDatosCesion();
            Session[Constantes.VENTANAANTERIOR] = Request.UrlReferrer.AbsolutePath.ToString();
        }

        private void recuperarDatosSesion()
        {
            Hashtable hParametros = (Hashtable)Session[Constantes.PARAMETROS];
            hOidEmpleado.Value = hParametros[Constantes.OIDEMPLEADO].ToString();
            hOidDepartamento.Value = hParametros[Constantes.OIDDEPARTAMENTO].ToString();
            hOidCesion.Value = hParametros[Constantes.OIDCESION].ToString();
            hOidMedio.Value = hParametros[Constantes.OIDMEDIO].ToString();
            lblDestCesion.Text = hParametros[Constantes.NOMEMPLEADO].ToString().Equals("") ? hParametros[Constantes.NOMDEPARTAMENTO].ToString() : hParametros[Constantes.NOMEMPLEADO].ToString();
            lblCodigoMedio.Text = hParametros[Constantes.IDMEDIO].ToString();
            lblTipoMedio.Text = hParametros[Constantes.TIPOMEDIO].ToString();
            lblMigasPan.Text = Session[Constantes.MIGAS_PAN].ToString() + " > " + Constantes.MIGAS_PAN_FINALIZAR_CESION;
        }

        /// <summary>
        ///Realizamos la llamara para obtener los datos de la cesión.
        /// </summary>
        private void obtenerDatosCesion()
        {
            string fecBajaMedio;
            //Llamamos a la capa de negocio para obtener los datos de la cesión
            ArrayList arrEliminarCesion = bll.buscarCesion(Convert.ToInt16(hOidCesion.Value), hOidEmpleado.Value, hOidDepartamento.Value);
            //Mostramos los valores en pantalla            
            Cesion cesionAct = (Cesion)arrEliminarCesion[0];
            fecBajaMedio = arrEliminarCesion[1].ToString();
            if(!fecBajaMedio.Equals(""))
            {
                txtFecBajaMedio.Text = Convert.ToDateTime(fecBajaMedio).ToShortDateString();
            }
            lblIniValue.Text = Convert.ToDateTime(cesionAct.FecIni).ToShortDateString();
            if (!cesionAct.FecFin.Equals(""))
            {
                lblFinValue.Text = Convert.ToDateTime(cesionAct.FecFin).ToShortDateString();
            }
            if (!cesionAct.FecFinProrroga.Equals(""))
            {
                lblFecFinProrrogaValue.Text = Convert.ToDateTime(cesionAct.FecFinProrroga).ToShortDateString();
                lblProrrogadaSiNo.Text = Constantes.SI;
                lblRespProrroga.Text = cesionAct.NombreEmpAuditoria;
            }
            else
            {
                lblProrrogadaSiNo.Text = Constantes.NO;
            }
            hOidCesion.Value = cesionAct.OidCesion.ToString();
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        /// <summary>
        /// Método para guardar un nuevo medio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
         
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int intGuardar;
            ////Llamamos a la capa de negocio
            //solamente actulizamos la fecha de baja (con el día actual) para dar de baja la cesión
            intGuardar = bll.finalizarCesion(Convert.ToInt16(hOidCesion.Value),Convert.ToInt16(hOidMedio.Value), txtFecBajaMedio.Text, !this.hOidEmpleado.Value.Equals("") ? "1" : "2");
            //// Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            // volvemos a la pantalla llamadora
            //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());
            Response.Redirect(Session[Constantes.VENTANAANTERIOR].ToString());
        }

        protected void btnInfoOk_Click(object sender, EventArgs e)
        {
            //if (this.hBtnOK.Value.ToString().Equals("01"))
            //{
            Response.Redirect(Session[Constantes.VENTANAANTERIOR].ToString());
            //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());         
            //}
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }
    }
}