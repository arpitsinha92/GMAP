﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Ent;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Data;

namespace ASB.GMAP.Web
{
    public partial class CesionMedioDisponible : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.CesionMedioDisponible bll;
        private MantMensajes manejador = new MantMensajes();
        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_CESION_MEDIO_DISPONIBLE, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.CesionMedioDisponible(ref manejador);
            //Mostramos la forma inicial de los controles en pantalla
            //ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "estadoCargaInicial();", true);
            inicializarCombos();
            buscarMedios();
            //determinamos desde donde se ha llamado a la pantalla para inicializarla como corresponda
            estadoInicialSegunParametros();
            //La validación de departamento al inicio esta deshabilitada hasta que se pulse sobre su correspondiente radio button
            this.valDepartamento.Enabled = false;
            //La fecha de hoy para crear una nueva cesión
            this.txtFecIniCesion.Text = DateTime.Now.ToShortDateString();//obtenerFechaActual();
            val_fecFinCesionMenorBajaMedio.ValueToCompare = DateTime.Now.ToShortDateString();
            txtDepartamento.Attributes.Add("readonly", "readonly");
            txtEmpleado.Attributes.Add("readonly", "readonly");
            if (Session[Constantes.VENTANAPADRE] == null)
            {
                Session[Constantes.VENTANAPADRE] = Request.UrlReferrer.AbsolutePath.ToString();
            }
        }

        /// <summary>
        /// Según los parámetros de sesión realizamos las correspondientes inicializaciones
        /// </summary>
        private void estadoInicialSegunParametros()
        {
            //obtenemos la hahstable con los parámetros
            Hashtable hParametros = (Hashtable)Session[Constantes.PARAMETROS];
            if (!string.IsNullOrEmpty(hParametros[Constantes.OIDEMPLEADO].ToString()))
            {
                //Se ha llamado a la ventana con los parámetros de empleado
                txtEmpleado.Text = hParametros[Constantes.NOMEMPLEADO].ToString();
                hOidDestCesion.Value = hParametros[Constantes.OIDEMPLEADO].ToString();
                btnDepartamento.Enabled = false;
                btnEmpleado.Enabled = false;
                rbtLstCesion.Enabled = false;
                this.valEmpleado.Enabled = true;
                this.valDepartamento.Enabled = false;
                rbtLstCesion.SelectedIndex = 0;

            }
            else
            {
                if (!string.IsNullOrEmpty(hParametros[Constantes.OIDDEPARTAMENTO].ToString()))
                {
                    //Se ha llamado a la ventana con los parámetros de departamento
                    txtDepartamento.Text = hParametros[Constantes.NOMBREDEPARTAMENTO].ToString();
                    hOidDestCesion.Value = hParametros[Constantes.OIDDEPARTAMENTO].ToString();
                    btnDepartamento.Enabled = false;
                    btnEmpleado.Enabled = false;
                    rbtLstCesion.Enabled = false;
                    this.valDepartamento.Enabled = true;
                    this.valEmpleado.Enabled = false;
                    rbtLstCesion.SelectedIndex = 1;
                }
                //Si el medio está libre:
                else
                {
                    //Arrastramos el medio seleccionado y lo ponemos en la primera línea
                    DataTable dt = ((DataSet)grdMedios.DataSource).Tables[0];
                    //test.Rows.InsertAt(0);
                    DataRow rowSelected = dt.NewRow();
                    rowSelected = dt.Select("int_oidmedio=" + hParametros[Constantes.OIDMEDIO])[0];
                    DataRow newRow = dt.NewRow();
                    newRow.ItemArray = rowSelected.ItemArray;
                    dt.Rows.Remove(rowSelected); 
                    dt.Rows.InsertAt(newRow, 0);                   
                    grdMedios.DataSource = dt;
                    grdMedios.DataBind();

                    //Marcamos el check del medio arrastrado de la pantalla anterior. Debe estar en primera posición.
                    foreach (GridViewRow row in grdMedios.Rows)
                    {
                        int rowIndex = row.RowIndex;

                        if (grdMedios.DataKeys[row.RowIndex][Constantes.INT_OIDMEDIO].ToString().Equals(hParametros[Constantes.OIDMEDIO]))
                        {
                            ((CheckBox)row.FindControl("grdChk")).Checked = true;
                            break;
                        }
                    }

                    btnDepartamento.Enabled = false;
                    btnEmpleado.Enabled = true;
                    rbtLstCesion.Enabled = true;
                    this.valDepartamento.Enabled = false;
                    this.valEmpleado.Enabled = true;
                    rbtLstCesion.SelectedIndex = 0;
                }
            }

            lblMigasPan.Text = Session[Constantes.MIGAS_PAN].ToString() + " > " + Constantes.MIGAS_PAN_CESION_MEDIO;
        }

        /// <summary>
        /// obtenemos la fecha actual para asignarla a la fecha de inicio de cesión
        /// </summary>
        /// <returns></returns>
        private string obtenerFechaActual()
        {
            string fecha = String.Empty;

            fecha = DateTime.Now.Day + "/" + DateTime.Now.Month + "/" + DateTime.Now.Year;

            return fecha;
        }

        private void buscarMedios()
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            //Variable en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;
            ViewState["dsGrid"] = bll.buscarMedios(Convert.ToInt16(ddlTipoMedio.SelectedValue), Session[Constantes.ID_PERFIL].ToString(), out numRegistros);
            grdMedios.DataSource = ViewState["dsGrid"];
            grdMedios.DataBind();
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        private void inicializarCombos()
        {
            Combos.cargarCombosDescPerfil(Constantes.TIPOSDEMEDIOS, ddlTipoMedio, Session[Constantes.ID_PERFIL].ToString(), true);
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);

            }
        }

        /// <summary>
        /// Método para guardar los cambios de un nuevo medio y su correspendondiente cesión
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            Cesion cesion = new Cesion(0, this.hOidDestCesion.Value.ToString(), obtenerMedioSeleccionado(), this.txtFecIniCesion.Text, txtFecFinCesion.Text,
                                        null, null, null, this.txtComentarios.Text);

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int intGuardar;
            // Llamamos a la capa de negocio
            // al llamar a la capa de negocio pasamos un parametro para determinar si el destinatario es una persona (1) o un departamento (2) o ninguno (0).
            intGuardar = bll.guardarCesionMedioDisponible(cesion, rbtLstCesion.SelectedValue);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        private int obtenerMedioSeleccionado()
        {
            int result = -1;
            foreach (GridViewRow di in grdMedios.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    //las columnas ocultas del grid están asociadas al mismo como dataKeys ya que sobre
                    //una columna visible = false no se puden obtener sus datos.
                    result = Convert.ToInt16(grdMedios.DataKeys[di.RowIndex].Values["int_oidmedio"].ToString());
                }
            }
            return result;
        }

        protected void ddlTipoMedio_SelectedIndexChanged(object sender, EventArgs e)
        {
            buscarMedios();
        }

        protected void btnNuevoMedio_Click(object sender, EventArgs e)
        {
            Session[Constantes.MIGAS_PAN] = Session[Constantes.MIGAS_PAN].ToString() + " > " + Constantes.MIGAS_PAN_CESION_MEDIO;
            Response.Redirect("MedioNuevo.aspx");
        }

        protected void rbtLstCesion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rbtLstCesion.SelectedValue.Equals("1"))
            {
                btnEmpleado.Enabled = true;
                btnDepartamento.Enabled = false;
                txtDepartamento.Text = "";
                this.valEmpleado.Enabled = true;
                this.valDepartamento.Enabled = false;
            }
            else
            {
                btnEmpleado.Enabled = false;
                btnDepartamento.Enabled = true;
                txtEmpleado.Text = "";
                this.valEmpleado.Enabled = false;
                this.valDepartamento.Enabled = true;
            }
            hOidDestCesion.Value = "";
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());
            Response.Redirect(Session[Constantes.VENTANAPADRE].ToString());
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        protected void btnInfoOk_Click(object sender, EventArgs e)
        {
            var unoSeleccionado = false;
            foreach (GridViewRow fila in grdMedios.Rows)
            {
                CheckBox chk = (CheckBox)fila.FindControl("grdChk");
                if (chk != null && chk.Checked)
                {
                    unoSeleccionado = true;
                    break;
                }
            }

            if (unoSeleccionado)
            {
                // Si todo ha ido correctamente volvemos a la pantalla llamadora.
                //Response.Redirect(((Stack<string>)Session[Constantes.VENTANALLAMADORA]).Pop());
                Response.Redirect(Session[Constantes.VENTANAPADRE].ToString());
            }
        }

        protected void grdChkMedio_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            if (chk != null)
            {
                if (chk.Checked)
                {
                    //obtenemos el medio seleccionado para cargar su fecha de baja
                    foreach (GridViewRow di in grdMedios.Rows)
                    {
                        CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                        if (chkBx != null && chkBx.Checked)
                        {
                            if (!string.IsNullOrEmpty(grdMedios.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()))
                            {
                                val_fecFinCesionMenorBajaMedio.Enabled = true;
                                val_fecFinCesionMenorBajaMedio.ValueToCompare = Convert.ToDateTime(grdMedios.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()).ToShortDateString();
                                txtFecFinCesion.Text = Convert.ToDateTime(grdMedios.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()).ToShortDateString();
                            }
                            else
                            {
                                val_fecFinCesionMenorBajaMedio.Enabled = false;
                                txtFecFinCesion.Text = "";
                            }
                            break;
                        }
                    }
                }
            }
        }

        #region ordenacionGrid
        protected void grdMedios_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGrid"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpression(e.SortExpression);

                grdMedios.DataSource = dataView;
                grdMedios.DataBind();
            }
        }

        private string GetSortExpression(string sortExpression)
        {
            if (sortExpression == GridViewSortExpression && GridViewSortDirection == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpression = sortExpression;
            return sortExpression + " " + GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirection"] = value; }
        }
        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }

        protected void grdMedios_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpression)
                        {
                            if (GridViewSortDirection.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        #endregion
    }
}