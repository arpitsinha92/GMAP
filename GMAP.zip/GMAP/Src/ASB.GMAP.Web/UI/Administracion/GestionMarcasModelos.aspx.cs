﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Ent;
using MB.Framework.Combo;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Data;

namespace ASB.GMAP.Web
{
    public partial class GestionMarcasModelos : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.GestionMarcasModelos bll;
        private MantMensajes manejador = new MantMensajes();

        private enum MarcaModelo {
            Marcas,
            Modelos
        };

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
                buscarMarcas();
                buscarModelos(Convert.ToInt16(Constantes.VALOR_DEFECTO_COMBO));
            }
        }

        /// <summary>
        /// Inicializamos las combos.
        /// </summary>
        public void inicializarCombos()
        {
            // Cargamos la combo
            Combos.cargarCombosDesc(Constantes.MARCAS, ddlMarca, true);
            Combos.cargarCombosDesc(Constantes.MARCAS, ddlMarcaEdicion, false);
            addElementoVacioddlMarcaEdidion();
        }

        /// <summary>
        /// Método que cargará el grid de marcas
        /// </summary>
        private void buscarMarcas()
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Variable en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            // perdure a los postback de paginación
            ViewState["dsGridMarcas"] = bll.buscarMarcas(out numRegistros);
            grdMarcas.DataSource = ViewState["dsGridMarcas"];
            grdMarcas.DataBind();            
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_GESTION_MARCAS_MODELOS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.GestionMarcasModelos(ref manejador);
            //Mostramos la forma inicial de los controles en pantalla
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "estadoCargaInicial();", true);
            inicializarCombos();
            val_fecBajaPosterior.ValueToCompare = DateTime.Now.ToShortDateString();
            val_fecBajaMarcaPosterior.ValueToCompare = DateTime.Now.ToShortDateString();
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            var mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        /// <summary>
        /// Evento click del boton guardar de la Marca
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardarMarca_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            Marca marca = new Marca(Convert.ToInt16(this.hOidMarca.Value), this.txtMarca.Text, this.txtFecBajaMarca.Text);
            
            var mensajes = new MB.Framework.ManejadorMensajes.MensajesEntidad();
            bool hayMensajes = false;
            
            int intGuardar;
            //Llamamos a la capa de negocio
            intGuardar = bll.guardarMarca(marca);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes && mensajes.TipoMensaje == Mensajes.tiposMensaje.Error)
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "btnEliminarMarcaDisable();grdMarcasDisable();desHabilitarModelos()", true);
                mostrarPopUp(mensajes);
            }
            else
            {
                // deshabilitamos la parte de mantenimeinto
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "desHabilitarMantenimientoModelos();desHabilitarMantenimientoMarcas();", true);
                // Si todo ha ido correctamente inicializamos la pantalla y relanzamos la búsqueda.
                buscarMarcas();
                // tenemos que refrescar tambien los combos de marca y el grid de modelos
                inicializarCombos();
                buscarModelos(Convert.ToInt16(ddlMarca.SelectedValue));
                if (hayMensajes)
                {
                    mostrarPopUp(mensajes);
                }
            }
        }

        protected void btnModificarMarca_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow di in grdMarcas.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChkMarca");

                if (chkBx != null && chkBx.Checked)
                {
                    this.txtMarca.Text = grdMarcas.DataKeys[di.RowIndex].Values["var_nombreEntero"].ToString();
                    this.hOidMarca.Value = grdMarcas.DataKeys[di.RowIndex].Values["int_oidmarca"].ToString();
                    if (!string.IsNullOrEmpty(grdMarcas.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()))
                    {
                        this.txtFecBajaMarca.Text = Convert.ToDateTime(grdMarcas.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()).ToShortDateString(); 
                    }
                    break;
                }
            }
            txtMarca.Focus();
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "btnEliminarMarcaDisable();grdMarcasDisable();desHabilitarModelos()", true);
            // despues se llama a una funcion javascript para la presentación de la pantalla en modo de edición.
        }

        /// <summary>
        /// Evento onclick del botón eliminar marca
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEliminarMarca_Click(object sender, EventArgs e)
        {
            mostrarConfirmPopUp(Constantes.MENSAJEBORRARMARCA, MarcaModelo.Marcas);
        }

        protected void btnPreguntaOkMarca_Click(object sender, EventArgs e)
        {
            ConfirmPopUpMarca.Hide();

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            string oidMarca = String.Empty;

            foreach (GridViewRow di in grdMarcas.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChkMarca");

                if (chkBx != null && chkBx.Checked)
                {
                    oidMarca = grdMarcas.DataKeys[di.RowIndex].Values["int_oidmarca"].ToString();
                    break;
                }
            }
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int intGuardar;
            //Llamamos a la capa de negocio
            intGuardar = bll.eliminarMarca(oidMarca);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }
            buscarMarcas();

            // tenemos que refrescar tambien los combos de marca y el grid de modelos
            inicializarCombos();
            buscarModelos(Convert.ToInt16(ddlMarca.SelectedValue));
        }

        /// <summary>
        /// Método para mostrar en pantalla mensajes informativos
        /// </summary>
        /// <param name="mensajes">Mensaje a mostrar al usuario</param>
        private void mostrarPopUp(MensajesEntidad mensajes)
        {
            this.lblMensajeInfo.Text = mensajes.Mensaje;
            this.InfoPopUp.Show();
        }

        /// <summary>
        /// Método para mostrar en pantalla mensajes informativos
        /// </summary>
        /// <param name="mensajes">Mensaje a mostrar al usuario</param>
        private void mostrarPopUpModelos(MensajesEntidad mensajes)
        {
            this.lblMensajeInfoModelos.Text = mensajes.Mensaje;
            this.InfoPopUpModelos.Show();
        }

        private void mostrarConfirmPopUp(string mensaje, MarcaModelo origen)
        {
            switch (origen)
            {
                case MarcaModelo.Marcas:
                    lblMensajePreguntaMarca.Text = mensaje;
                    ConfirmPopUpMarca.Show();
                    break;
                case MarcaModelo.Modelos:
                    lblMensajePreguntaModelo.Text = mensaje;
                    ConfirmPopUpModelo.Show();
                    break;
            }
        }

        /// <summary>
        /// Eventon onclick para el botón de guardar modelos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardarModelo_Click(object sender, EventArgs e)
        {
            
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            Modelo modelo = new Modelo(Convert.ToInt16(this.hOidModelo.Value), this.txtModelo.Text,this.txtModeloDesc.Text, this.txtFecBajaModelo.Text, Convert.ToInt16(this.ddlMarcaEdicion.SelectedValue));
            
            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;
            
            int intGuardar;
            //Llamamos a la capa de negocio
            intGuardar = bll.guardarModelo(modelo);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            if (hayMensajes && mensajes.TipoMensaje == Mensajes.tiposMensaje.Error)
            {
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "btnEliminarModeloDisable();grdDdlModelosDisable();desHabilitarMarcas()", true);
                mostrarPopUpModelos(mensajes);
            }
            else
            {
                // deshabilitamos la parte de mantenimeinto
                ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "desHabilitarMantenimientoMarcas();desHabilitarMantenimientoModelos();", true);
                // Si todo ha ido correctamente inicializamos la pantalla y relanzamos la búsqueda.
                buscarModelos(Convert.ToInt16(this.ddlMarca.SelectedValue));
                addElementoVacioddlMarcaEdidion();
                if (hayMensajes)
                {
                    mostrarPopUpModelos(mensajes);
                }
            }
        }

        /// <summary>
        /// método encargado de realizar la carga del gridview de modelos
        /// </summary>
        private void buscarModelos(int oidMarca)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Variable en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            // Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            // perdure a los postback de paginación
            ViewState["dsGridModelos"] = bll.buscarModelos(oidMarca, out numRegistros);
            grdModelos.DataSource = ViewState["dsGridModelos"];
            grdModelos.DataBind();
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }
        }

        /// <summary>
        /// Cuando se selecciona una marca nueva en el combo se realiza la búsqueda de los modelos asociados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            buscarModelos(Convert.ToInt16(ddlMarca.SelectedValue));
        }

        protected void btnEliminarModelo_Click(object sender, EventArgs e)
        {
            mostrarConfirmPopUp(Constantes.MENSAJEBORRARMODELO, MarcaModelo.Modelos);
        }

        protected void btnPreguntaOkModelo_Click(object sender, EventArgs e)
        {
            ConfirmPopUpModelo.Hide();

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            string oidModelo = String.Empty;

            foreach (GridViewRow di in grdModelos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdCheckModelo");

                if (chkBx != null && chkBx.Checked)
                {
                    oidModelo = grdModelos.DataKeys[di.RowIndex].Values["int_oidmodelo"].ToString();
                    break;
                }
            }

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int intGuardar;
            //Llamamos a la capa de negocio
            intGuardar = bll.eliminarModelo(oidModelo);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }

            buscarModelos(Convert.ToInt16(ddlMarca.SelectedValue));
        }

        protected void btnModificarModelo_Click(object sender, EventArgs e)
        {
            removeElementoVacioddlMarcaEdidion();
            foreach (GridViewRow di in grdModelos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdCheckModelo");

                if (chkBx != null && chkBx.Checked)
                {
                    this.txtModelo.Text = grdModelos.DataKeys[di.RowIndex].Values["var_nombreModeloEntero"].ToString();
                    this.hOidModelo.Value = grdModelos.DataKeys[di.RowIndex].Values["int_oidmodelo"].ToString();
                    if (!string.IsNullOrEmpty(grdModelos.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()))
                    {
                        this.txtFecBajaModelo.Text = Convert.ToDateTime(grdModelos.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()).ToShortDateString();
                    }
                    this.txtModeloDesc.Text = grdModelos.DataKeys[di.RowIndex].Values["var_descripcion"].ToString();
                    this.ddlMarcaEdicion.SelectedValue = grdModelos.DataKeys[di.RowIndex].Values["int_oidmarca"].ToString();
                    break;
                }
            }
            txtModelo.Focus();
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "btnEliminarModeloDisable();grdDdlModelosDisable();desHabilitarMarcas()", true);            
            // despues se llama a una funcion javascript para la presentación de la pantalla en modo de edición.
        }

        #region ordenacionGrid

        protected void grdModelos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                grdModelos.PageIndex = e.NewPageIndex;
                recargarGrid(e.NewPageIndex);
            }
        }
        private void recargarGrid(int numPage)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridModelos"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpressionModelos))
                {
                    dataView.Sort = GridViewSortExpressionModelos + " " + GridViewSortDirectionModelos;
                }
                grdModelos.PageIndex = numPage;
                grdModelos.DataSource = dataView;
                grdModelos.DataBind();
            }
        }

        protected void grdModelos_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridModelos"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionModelos(e.SortExpression);

                grdModelos.DataSource = dataView;
                grdModelos.DataBind();
            }
        }

        private string GetSortExpressionModelos(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionModelos && GridViewSortDirectionModelos == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionModelos = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionModelos = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionModelos = sortExpression;
            return sortExpression + " " + GridViewSortDirectionModelos;
        }

        private string GridViewSortDirectionModelos
        {
            get { return ViewState["SortDirectionModelos"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionModelos"] = value; }
        }
        private string GridViewSortExpressionModelos
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }

        protected void grdModelos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionModelos)
                        {
                            if (GridViewSortDirectionModelos.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }


        protected void grdMarcas_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGridMarcas"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpressionMarcas(e.SortExpression);

                grdMarcas.DataSource = dataView;
                grdMarcas.DataBind();
            }
        }

        private string GetSortExpressionMarcas(string sortExpression)
        {
            if (sortExpression == GridViewSortExpressionMarcas && GridViewSortDirectionMarcas == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirectionMarcas = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirectionMarcas = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpressionMarcas = sortExpression;
            return sortExpression + " " + GridViewSortDirectionMarcas;
        }

        private string GridViewSortDirectionMarcas
        {
            get { return ViewState["SortDirectionMarcas"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirectionMarcas"] = value; }
        }
        private string GridViewSortExpressionMarcas
        {
            get { return ViewState["SortExpressionMarcas"] as string ?? string.Empty; }
            set { ViewState["SortExpressionMarcas"] = value; }
        }

        protected void grdMarcas_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpressionMarcas)
                        {
                            if (GridViewSortDirectionMarcas.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        #endregion

        protected void btnCancelarMarca_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "desHabilitarMantenimientoModelos();desHabilitarMantenimientoMarcas();", true);            
        }

        protected void btnCancelarModelo_Click(object sender, EventArgs e)
        {
            addElementoVacioddlMarcaEdidion();
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "desHabilitarMantenimientoMarcas();desHabilitarMantenimientoModelos()", true);            
        }

        private void addElementoVacioddlMarcaEdidion()
        {
            ddlMarcaEdicion.Items.Insert(0, new ListItem(String.Empty, String.Empty));
            ddlMarcaEdicion.SelectedIndex = 0;
        }

        private void removeElementoVacioddlMarcaEdidion()
        {
            ddlMarcaEdicion.Items.RemoveAt(0);            
        }
    }
}