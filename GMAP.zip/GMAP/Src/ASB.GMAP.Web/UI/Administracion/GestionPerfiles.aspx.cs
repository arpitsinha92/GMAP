﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Ent;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Data;

namespace ASB.GMAP.Web
{
    public partial class GestionPerfiles : System.Web.UI.Page
    {
        #region Miembros privados

        protected static ASB.GMAP.Bll.GestionAccesos bll;
        private MantMensajes manejador = new MantMensajes();

        private enum Pestana
        {
            Perfiles,
            Funciones
        };

        private List<Perfil> perfiles;
        private List<OpcionMenu> opcionesMenu;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Inicializamos la página
                inicializar();
            }
        }

        #region Manejadores de eventos de la pestaña Funciones

        protected void btnNuevaFuncion_Click(object sender, EventArgs e)
        {
            // Habilitar edición
            habilitarEdicion(Pestana.Funciones);

            limpiarGridView(gvFunciones, Pestana.Funciones);
            limpiarGridView(gvAcciones, Pestana.Funciones);
            limpiarGridView(gvMedios, Pestana.Funciones);

            limpiarTextBox(txtNombreFuncion);
            limpiarTextBox(txtFechaBajaFuncion);

            deshabilitarControl(gvFunciones);
            deshabilitarControl(btnNuevaFuncion);
            deshabilitarControl(btnModificarFuncion);
            deshabilitarControl(btnEliminarFuncion);

            txtNombreFuncion.Focus();
        }

        protected void btnModificarFuncion_Click(object sender, EventArgs e)
        {
            var funcion = obtenerIdFuncionSeleccionada();

            if (funcion == 1)
            {
                mostrarPopUp(Constantes.MENSAJEMODIFFUNCADMIN);
            }
            else
            {
                // Habilitar edición
                habilitarEdicion(Pestana.Funciones);

                deshabilitarControl(gvFunciones);
                deshabilitarControl(btnNuevaFuncion);
                deshabilitarControl(btnModificarFuncion);
                deshabilitarControl(btnEliminarFuncion);

                txtNombreFuncion.Focus();
            }
        }

        protected void btnEliminarFuncion_Click(object sender, EventArgs e)
        {
            var funcion = obtenerIdFuncionSeleccionada();

            if (funcion == 1)
            {
                mostrarPopUp(Constantes.MENSAJEMODIFFUNCADMIN);
            }
            else
            {
                mostrarConfirmPopUp(Constantes.MENSAJEBORRARFUNCION, Pestana.Funciones);
            }
        }

        protected void btnConfirmacionSiFunciones_Click(object sender, EventArgs e)
        {
            ConfirmPopUpFunciones.Hide();

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            habilitarControl(txtFechaBajaFuncion);
            habilitarControl(reqTxtFechaBajaFuncion);
            habilitarControl(cmpTxtFechaBajaFuncion);
            habilitarControl(cmpTxtFechaBajaFuncionMayorQueHoy);

            int idFuncionSeleccionada = obtenerIdFuncionSeleccionada();

            // Llamamos a la capa de negocio
            bll.eliminarFuncion(idFuncionSeleccionada, DateTime.Now);

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            // Recargamos el GridView de Funciones
            cargarFunciones();

            // Recargamos el GridView de Funciones por Perfil
            gvFuncionesPerfil.DataSource = (List<Funcion>)ViewState["funciones"];
            gvFuncionesPerfil.DataBind();

            // Limpiamos la pantalla
            restablecerPantalla(Pestana.Funciones);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnGuardarFuncion_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int idFuncionSeleccionada = obtenerIdFuncionSeleccionada();

                if (tieneMismoNombre(txtNombreFuncion, gvFunciones) && idFuncionSeleccionada == 0)
                {
                    mostrarPopUp(Constantes.MENSAJEFUNCIONDUPLICADA);
                }
                else
                {
                    var mensajes = new MensajesEntidad();
                    bool hayMensajes = false;

                    Funcion funcion = new Funcion();

                    funcion.IdFuncion = idFuncionSeleccionada;
                    funcion.Nombre = txtNombreFuncion.Text;
                    funcion.FechaBaja = String.IsNullOrEmpty(txtFechaBajaFuncion.Text) ? (DateTime?)null : Convert.ToDateTime(txtFechaBajaFuncion.Text);

                    // Añadimos las acciones seleccionadas
                    funcion.Acciones = new List<Accion>();
                    foreach (GridViewRow fila in gvAcciones.Rows)
                    {
                        CheckBox checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");

                        if (checkBox != null && checkBox.Checked)
                        {
                            Accion accion = new Accion();
                            accion.IdAccion = Convert.ToInt32(gvAcciones.DataKeys[fila.RowIndex].Values["INT_OIDACCION"]);

                            funcion.Acciones.Add(accion);
                        }
                    }

                    // Añadimos los tipos de medios seleccionados
                    funcion.TiposDeMedios = new List<TipoDeMedio>();
                    foreach (GridViewRow fila in gvMedios.Rows)
                    {
                        CheckBox checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");

                        if (checkBox != null && checkBox.Checked)
                        {
                            TipoDeMedio tipoMedio = new TipoDeMedio();
                            tipoMedio.OidTipoMedio = Convert.ToInt32(gvMedios.DataKeys[fila.RowIndex].Values["INT_OIDTIPOMEDIO"]);

                            funcion.TiposDeMedios.Add(tipoMedio);
                        }
                    }

                    // Llamamos a la capa de negocio
                    int resultado = bll.guardarFuncion(funcion);

                    // Recuperamos los mensajes del manejador
                    mensajes = bll.mostrarMensajes(ref hayMensajes);

                    // Recargamos el GridView de Funciones
                    cargarFunciones();

                    // Recargamos el GridView de Funciones por Perfil
                    gvFuncionesPerfil.DataSource = (List<Funcion>)ViewState["funciones"];
                    gvFuncionesPerfil.DataBind();

                    // Limpiamos la pantalla
                    restablecerPantalla(Pestana.Funciones);

                    if (hayMensajes)
                    {
                        mostrarPopUp(mensajes.Mensaje);
                    }
                }
            }
        }

        protected void btnCancelarFuncion_Click(object sender, EventArgs e)
        {
            restablecerPantalla(Pestana.Funciones);
        }

        protected void chkFuncionSeleccionada_CheckedChanged(object sender, EventArgs e)
        {
            var funciones = (List<Funcion>)ViewState["funciones"];

            int idFuncionSeleccionada = 0;

            // Encontramos la función seleccionada
            Funcion funcionSeleccionada = null;
            foreach (GridViewRow fila in gvFunciones.Rows)
            {
                CheckBox checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");

                if (checkBox != null && checkBox.Checked)
                {
                    idFuncionSeleccionada = Convert.ToInt32(gvFunciones.DataKeys[fila.RowIndex].Values["IdFuncion"]);
                    foreach (Funcion funcion in funciones)
                    {
                        if (funcion.IdFuncion == idFuncionSeleccionada)
                        {
                            funcionSeleccionada = funcion;
                            break;
                        }
                    }
                    break;
                }
            }

            // Limipiar los checks de Acciones y Medios
            limpiarGridView(gvAcciones, Pestana.Funciones);
            limpiarGridView(gvMedios, Pestana.Funciones);
            // Limpiar los campos de texto
            limpiarTextBox(txtNombreFuncion);
            limpiarTextBox(txtFechaBajaFuncion);

            deshabilitarControl(btnModificarFuncion);
            deshabilitarControl(btnEliminarFuncion);

            // Si hay una función seleccionada
            if (funcionSeleccionada != null)
            {
                // Habilitamos la eliminación y la edición
                habilitarControl(btnModificarFuncion);
                habilitarControl(btnEliminarFuncion);

                // Nombre y fecha de baja
                txtNombreFuncion.Text = funcionSeleccionada.Nombre;
                txtFechaBajaFuncion.Text = String.Format("{0:dd/MM/yyyy}", funcionSeleccionada.FechaBaja);

                if (funcionSeleccionada.Acciones != null)
                {
                    // Marcamos los checks en el GridView de Acciones
                    foreach (Accion accion in funcionSeleccionada.Acciones)
                    {
                        foreach (GridViewRow fila in gvAcciones.Rows)
                        {
                            CheckBox checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");

                            int idAccion = Convert.ToInt32(gvAcciones.DataKeys[fila.RowIndex].Values["INT_OIDACCION"]);
                            if (accion.IdAccion == idAccion)
                            {
                                checkBox.Checked = true;
                                break;
                            }
                        }
                    }
                }

                if (funcionSeleccionada.TiposDeMedios != null)
                {
                    // Marcamos los checks en el GridView de Medios
                    foreach (TipoDeMedio tipoMedio in funcionSeleccionada.TiposDeMedios)
                    {
                        foreach (GridViewRow fila in gvMedios.Rows)
                        {
                            CheckBox checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");

                            int idTipoMedio = Convert.ToInt32(gvMedios.DataKeys[fila.RowIndex].Values["INT_OIDTIPOMEDIO"]);
                            if (tipoMedio.OidTipoMedio == idTipoMedio)
                            {
                                checkBox.Checked = true;
                                break;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Manejadores de eventos de la pestaña Perfiles

        protected void btnNuevoPerfil_Click(object sender, EventArgs e)
        {
            // Habilitar edición
            habilitarEdicion(Pestana.Perfiles);

            limpiarGridView(gvPerfiles, Pestana.Perfiles);
            limpiarGridView(gvMenusPerfil, Pestana.Perfiles);
            limpiarGridView(gvFuncionesPerfil, Pestana.Perfiles);

            limpiarTextBox(txtNombrePerfil);
            limpiarTextBox(txtFechaBajaPerfil);

            deshabilitarControl(gvPerfiles);
            deshabilitarControl(btnNuevoPerfil);
            deshabilitarControl(btnModificarPerfil);
            deshabilitarControl(btnEliminarPerfil);

            txtNombrePerfil.Focus();
        }

        protected void btnModificarPerfil_Click(object sender, EventArgs e)
        {
            var perfil = obtenerIdPerfilSeleccionado();

            if (perfil == 1)
            {
                mostrarPopUp(Constantes.MENSAJEMODIFPERFADMIN);
            }
            else
            {
                // Habilitar edición
                habilitarEdicion(Pestana.Perfiles);

                deshabilitarControl(gvPerfiles);
                deshabilitarControl(btnNuevoPerfil);
                deshabilitarControl(btnModificarPerfil);
                deshabilitarControl(btnEliminarPerfil);

                txtNombrePerfil.Focus();
            }
        }

        protected void btnEliminarPerfil_Click(object sender, EventArgs e)
        {
            var perfil = obtenerIdPerfilSeleccionado();

            if (perfil == 1)
            {
                mostrarPopUp(Constantes.MENSAJEMODIFPERFADMIN);
            }
            else
            {
                mostrarConfirmPopUp(Constantes.MENSAJEBORRARPERFIL, Pestana.Perfiles);
            }
        }

        protected void btnConfirmacionSiPerfiles_Click(object sender, EventArgs e)
        {
            ConfirmPopUpPerfiles.Hide();

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            habilitarControl(txtFechaBajaPerfil);
            habilitarControl(reqTxtFechaBajaPerfil);
            habilitarControl(cmpTxtFechaBajaPerfil);
            habilitarControl(cmpTxtFechaBajaPerfilMayorQueHoy);

            txtFechaBajaPerfil.Text = DateTime.Now.ToShortDateString();

            int idPerfilSeleccionado = obtenerIdPerfilSeleccionado();

            // Llamamos a la capa de negocio
            bll.eliminarPerfil(idPerfilSeleccionado, Convert.ToDateTime(txtFechaBajaPerfil.Text));

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            // Recargamos el GridView de Funciones
            cargarPerfiles();

            // Limpiamos la pantalla
            restablecerPantalla(Pestana.Perfiles);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes.Mensaje);
            }
        }

        protected void btnGuardarPerfil_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int idPerfilSeleccionado = obtenerIdPerfilSeleccionado();

                if (tieneMismoNombre(txtNombrePerfil, gvPerfiles) && idPerfilSeleccionado == 0)
                {
                    mostrarPopUp(Constantes.MENSAJEPERFILDUPLICADO);
                }
                else
                {
                    var mensajes = new MensajesEntidad();
                    bool hayMensajes = false;

                    Perfil perfil = new Perfil();

                    perfil.IdPerfil = idPerfilSeleccionado;
                    perfil.Nombre = txtNombrePerfil.Text;
                    perfil.FechaBaja = String.IsNullOrEmpty(txtFechaBajaPerfil.Text) ? (DateTime?)null : Convert.ToDateTime(txtFechaBajaPerfil.Text);

                    // Añadimos las funciones seleccionadas
                    perfil.Funciones = new List<Funcion>();
                    foreach (GridViewRow fila in gvFuncionesPerfil.Rows)
                    {
                        CheckBox checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");

                        if (checkBox != null && checkBox.Checked)
                        {
                            Funcion funcion = new Funcion();
                            funcion.IdFuncion = Convert.ToInt32(gvFuncionesPerfil.DataKeys[fila.RowIndex].Values["IdFuncion"]);

                            perfil.Funciones.Add(funcion);
                        }
                    }

                    // Añadimos las opciones de menú seleccionadas
                    perfil.OpcionesMenu = new List<OpcionMenu>();
                    foreach (GridViewRow fila in gvMenusPerfil.Rows)
                    {
                        CheckBox checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");

                        if (checkBox != null && checkBox.Checked)
                        {
                            OpcionMenu opcionMenu = new OpcionMenu();
                            opcionMenu.IdOpcionMenu = Convert.ToInt32(gvMenusPerfil.DataKeys[fila.RowIndex].Values["IdOpcionMenu"]);
                            opcionMenu.Descripcion = HttpUtility.HtmlDecode(fila.Cells[1].Text);

                            perfil.OpcionesMenu.Add(opcionMenu);
                        }
                    }

                    // Llamamos a la capa de negocio
                    int resultado = bll.guardarPerfil(perfil);

                    // Recuperamos los mensajes del manejador
                    mensajes = bll.mostrarMensajes(ref hayMensajes);

                    // Recargamos el GridView de Funciones
                    cargarPerfiles();

                    // Limpiamos la pantalla
                    restablecerPantalla(Pestana.Perfiles);

                    if (hayMensajes)
                    {
                        mostrarPopUp(mensajes.Mensaje);
                    }
                }
            }
        }

        protected void btnCancelarPerfil_Click(object sender, EventArgs e)
        {
            restablecerPantalla(Pestana.Perfiles);
        }

        protected void chkPerfilSeleccionado_CheckedChanged(object sender, EventArgs e)
        {
            perfiles = (List<Perfil>)ViewState["perfiles"];

            int idPerfilSeleccionado = 0;

            // Encontramos la función seleccionada
            Perfil perfilSeleccionado = null;
            foreach (GridViewRow fila in gvPerfiles.Rows)
            {
                CheckBox checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");

                if (checkBox != null && checkBox.Checked)
                {
                    idPerfilSeleccionado = Convert.ToInt32(gvPerfiles.DataKeys[fila.RowIndex].Values["IdPerfil"]);
                    foreach (Perfil perfil in perfiles)
                    {
                        if (perfil.IdPerfil == idPerfilSeleccionado)
                        {
                            perfilSeleccionado = perfil;
                            break;
                        }
                    }
                    break;
                }
            }

            // Limipiar los checks de Funciones y Menus
            limpiarGridView(gvFuncionesPerfil, Pestana.Perfiles);
            limpiarGridView(gvMenusPerfil, Pestana.Perfiles);
            // Limpiar los campos de texto
            limpiarTextBox(txtNombrePerfil);
            limpiarTextBox(txtFechaBajaPerfil);

            deshabilitarControl(btnModificarPerfil);
            deshabilitarControl(btnEliminarPerfil);

            // Si hay un perfil seleccionado
            if (perfilSeleccionado != null)
            {
                // Habilitamos la eliminación y la edición
                habilitarControl(btnModificarPerfil);
                habilitarControl(btnEliminarPerfil);

                // Nombre y fecha de baja
                txtNombrePerfil.Text = perfilSeleccionado.Nombre;
                txtFechaBajaPerfil.Text = String.Format("{0:dd/MM/yyyy}", perfilSeleccionado.FechaBaja);

                if (perfilSeleccionado.Funciones != null)
                {
                    // Marcamos los checks en el GridView de Funciones
                    foreach (Funcion funcion in perfilSeleccionado.Funciones)
                    {
                        foreach (GridViewRow fila in gvFuncionesPerfil.Rows)
                        {
                            CheckBox checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");

                            int idFuncion = Convert.ToInt32(gvFuncionesPerfil.DataKeys[fila.RowIndex].Values["IdFuncion"]);
                            if (funcion.IdFuncion == idFuncion)
                            {
                                checkBox.Checked = true;
                                break;
                            }
                        }
                    }
                }

                // Cargamos los menus de opciones asociados al perfil
                if (perfilSeleccionado.OpcionesMenu != null)
                {
                    // Marcamos los checks en el GridView de Opciones de Menú
                    foreach (OpcionMenu opcionMenu in perfilSeleccionado.OpcionesMenu)
                    {
                        foreach (GridViewRow fila in gvMenusPerfil.Rows)
                        {
                            CheckBox checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");

                            int idOpcionMenu = Convert.ToInt32(gvMenusPerfil.DataKeys[fila.RowIndex].Values["IdOpcionMenu"]);
                            if (opcionMenu.IdOpcionMenu == idOpcionMenu)
                            {
                                checkBox.Checked = true;
                                break;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Funciones auxiliares

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_GESTION_PERFILES, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.GestionAccesos(ref manejador);

            cmpTxtFechaBajaFuncionMayorQueHoy.ValueToCompare = DateTime.Today.ToShortDateString();
            cmpTxtFechaBajaPerfilMayorQueHoy.ValueToCompare = DateTime.Today.ToShortDateString();

            #region Pestaña Funciones

            // Cargamos el GridView de Funciones
            cargarFunciones();

            // Cargamos el GridView de Medios
            var tiposMedios = bll.obtenerListaTiposMedios();
            gvMedios.DataSource = tiposMedios;
            gvMedios.DataBind();

            lblTotalTiposMedios.Text = String.Format("Total Tipos de Medios encontrados {0}", tiposMedios.Tables[0].Rows.Count);

            // Cargamos el GridView de Acciones
            var acciones = bll.obtenerListaAcciones();
            gvAcciones.DataSource = acciones;
            gvAcciones.DataBind();

            lblTotalAcciones.Text = String.Format("Total Acciones encontradas {0}", acciones.Tables[0].Rows.Count);

            #endregion

            #region Pestaña Perfiles

            // Cargamos el GridView de Perfiles
            cargarPerfiles();

            // Cargamos el GridView de Funciones por Perfil
            gvFuncionesPerfil.DataSource = (List<Funcion>)ViewState["funciones"];
            gvFuncionesPerfil.DataBind();

            // Cargamos el GridView de Menus
            opcionesMenu = bll.obtenerListaOpcionesMenu();

            gvMenusPerfil.DataSource = opcionesMenu;
            gvMenusPerfil.DataBind();

            lblTotalOpciones.Text = String.Format("Total Opciones encontradas {0}", opcionesMenu.Count);

            #endregion
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;
          
           
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MensajesEntidad> mensajes = new List<MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        private void cargarFunciones()
        {
            var funciones = bll.obtenerListaFunciones();
            ViewState["funciones"] = funciones;

            gvFunciones.DataSource = funciones;
            gvFunciones.DataBind();

            lblTotalFunciones.Text = String.Format("Total Funciones encontradas {0}", funciones.Count);
            lblTotalFuncionesPerfiles.Text = String.Format("Total Funciones encontradas {0}", funciones.Count);
        }

        private void cargarPerfiles()
        {
            perfiles = bll.obtenerListaPerfiles();
            ViewState["perfiles"] = perfiles;

            gvPerfiles.DataSource = perfiles;
            gvPerfiles.DataBind();

            lblTotalPerfiles.Text = String.Format("Total Perfiles encontrados {0}", perfiles.Count);
        }

        private void habilitarEdicion(Pestana pestana)
        {
            switch (pestana)
            {
                case Pestana.Funciones:
                    habilitarControl(txtNombreFuncion);
                    habilitarControl(txtFechaBajaFuncion);

                    habilitarControl(gvAcciones);
                    habilitarControl(gvMedios);

                    habilitarControl(reqTxtNombreFuncion);
                    habilitarControl(cmpTxtFechaBajaFuncion);
                    habilitarControl(cmpTxtFechaBajaFuncionMayorQueHoy);

                    habilitarControl(btnGuardarFuncion);
                    habilitarControl(btnCancelarFuncion);
                    break;

                case Pestana.Perfiles:
                    habilitarControl(txtNombrePerfil);
                    habilitarControl(txtFechaBajaPerfil);

                    habilitarControl(gvMenusPerfil);
                    habilitarControl(gvFuncionesPerfil);

                    habilitarControl(reqTxtNombrePerfil);
                    habilitarControl(cmpTxtFechaBajaPerfil);
                    habilitarControl(cmpTxtFechaBajaPerfilMayorQueHoy);

                    habilitarControl(btnGuardarPerfil);
                    habilitarControl(btnCancelarPerfil);
                    break;
            }
        }

        private int obtenerIdFuncionSeleccionada()
        {
            int idFuncionSeleccionada = 0;
            foreach (GridViewRow fila in gvFunciones.Rows)
            {
                CheckBox checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");

                if (checkBox != null && checkBox.Checked)
                {
                    idFuncionSeleccionada = Convert.ToInt32(gvFunciones.DataKeys[fila.RowIndex].Values["IdFuncion"]);
                    break;
                }
            }

            return idFuncionSeleccionada;
        }

        private int obtenerIdPerfilSeleccionado()
        {
            int idPerfilSeleccionado = 0;
            foreach (GridViewRow fila in gvPerfiles.Rows)
            {
                CheckBox checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");

                if (checkBox != null && checkBox.Checked)
                {
                    idPerfilSeleccionado = Convert.ToInt32(gvPerfiles.DataKeys[fila.RowIndex].Values["IdPerfil"]);
                    break;
                }
            }

            return idPerfilSeleccionado;
        }

        private void restablecerPantalla(Pestana pestana)
        {
            switch (pestana)
            {
                case Pestana.Funciones:
                    limpiarGridView(gvFunciones, pestana);
                    limpiarGridView(gvAcciones, pestana);
                    limpiarGridView(gvMedios, pestana);

                    limpiarTextBox(txtNombreFuncion);
                    limpiarTextBox(txtFechaBajaFuncion);

                    deshabilitarControl(gvAcciones);
                    deshabilitarControl(gvMedios);

                    deshabilitarControl(txtNombreFuncion);
                    deshabilitarControl(txtFechaBajaFuncion);
                    deshabilitarControl(btnGuardarFuncion);
                    deshabilitarControl(btnCancelarFuncion);

                    deshabilitarControl(btnModificarFuncion);
                    deshabilitarControl(btnEliminarFuncion);

                    deshabilitarControl(reqTxtNombreFuncion);
                    deshabilitarControl(reqTxtFechaBajaFuncion);
                    deshabilitarControl(cmpTxtFechaBajaFuncion);
                    deshabilitarControl(cmpTxtFechaBajaFuncionMayorQueHoy);

                    habilitarControl(btnNuevaFuncion);
                    habilitarControl(gvFunciones);
                    break;

                case Pestana.Perfiles:
                    limpiarGridView(gvPerfiles, pestana);
                    limpiarGridView(gvMenusPerfil, pestana);
                    limpiarGridView(gvFuncionesPerfil, pestana);

                    limpiarTextBox(txtNombrePerfil);
                    limpiarTextBox(txtFechaBajaPerfil);

                    deshabilitarControl(gvMenusPerfil);
                    deshabilitarControl(gvFuncionesPerfil);

                    deshabilitarControl(txtNombrePerfil);
                    deshabilitarControl(txtFechaBajaPerfil);
                    deshabilitarControl(btnGuardarPerfil);
                    deshabilitarControl(btnCancelarPerfil);

                    deshabilitarControl(btnModificarPerfil);
                    deshabilitarControl(btnEliminarPerfil);

                    deshabilitarControl(reqTxtNombrePerfil);
                    deshabilitarControl(reqTxtFechaBajaPerfil);
                    deshabilitarControl(cmpTxtFechaBajaPerfil);
                    deshabilitarControl(cmpTxtFechaBajaPerfilMayorQueHoy);

                    habilitarControl(btnNuevoPerfil);
                    habilitarControl(gvPerfiles);
                    break;
            }
        }

        private void deshabilitarControl(WebControl control)
        {
            control.Enabled = false;
        }

        private void habilitarControl(WebControl control)
        {
            control.Enabled = true;
        }

        private void limpiarTextBox(TextBox txt)
        {
            txt.Text = String.Empty;
        }

        private void limpiarGridView(GridView gv, Pestana pestana)
        {
            foreach (GridViewRow fila in gv.Rows)
            {
                CheckBox checkBox = null;

                if (pestana == Pestana.Funciones)
                {
                    checkBox = (CheckBox)fila.FindControl("chkFuncionSeleccionada");
                }
                else if (pestana == Pestana.Perfiles)
                {
                    checkBox = (CheckBox)fila.FindControl("chkPerfilSeleccionado");
                }

                checkBox.Checked = false;
            }
        }

        private void mostrarPopUp(string mensaje)
        {
            this.lblMensajeInfo.Text = mensaje;
            this.InfoPopUp.Show();
        }

        private void mostrarConfirmPopUp(string mensaje, Pestana origen)
        {
            switch (origen)
            {
                case Pestana.Funciones:
                    lblMensajeConfirmacionFunciones.Text = mensaje;
                    ConfirmPopUpFunciones.Show();
                    break;
                case Pestana.Perfiles:
                    lblMensajeConfirmacionPerfiles.Text = mensaje;
                    ConfirmPopUpPerfiles.Show();
                    break;
            }
        }

        private bool tieneMismoNombre(TextBox textBox, GridView gridView)
        {
            foreach (GridViewRow fila in gridView.Rows)
            {
                if (textBox.Text.Equals(Util.GetText(fila, "Nombre"), StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        #endregion
    }
}