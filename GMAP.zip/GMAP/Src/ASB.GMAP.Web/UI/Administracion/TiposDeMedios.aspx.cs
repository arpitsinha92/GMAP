﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Ent;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Combo;
using System.Data;

namespace ASB.GMAP.Web
{
    public partial class TiposDeMedios : System.Web.UI.Page
    {
        protected static ASB.GMAP.Bll.TiposDeMedios bll;
        private MantMensajes manejador = new MantMensajes();

        /// <summary>
        /// Page Load de la página
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (Session[Constantes.LOGIN_USUARIO] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            // Se muestran los mensajes de error
            mostrarMensajes();

            if (!IsPostBack)
            {
                // Llamada la método inicializar
                inicializar();
            }
        }

        /// <summary>
        /// Se realizan las acciones iniciales para cargar la página.
        /// </summary>
        public void inicializar()
        {
            Log.escribirLog(Constantes.PANTALLA_TIPOS_DE_MEDIOS, Constantes.INFORMATIVO);
            // Inicializamos la capa de negocio
            bll = new ASB.GMAP.Bll.TiposDeMedios(ref manejador);
            //Mostramos la forma inicial de los controles en pantalla
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "estadoCargaInicial();", true);
            inicializarCombos();
            val_fecBajaPosterior.ValueToCompare = DateTime.Now.ToShortDateString();
            btnBuscar_Click(null, null);
            Session[Constantes.ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS] = null;
           
           
        }

        /// <summary>
        /// Inicializamos las combos.
        /// </summary>
        public void inicializarCombos()
        {
            Combos.cargarCombosDesc(Constantes.PERSONAS, ddlCentroCoste, true);           
        }
        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            List<MB.Framework.ManejadorMensajes.MensajesEntidad> mensajes = new List<MB.Framework.ManejadorMensajes.MensajesEntidad>();
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();

                //Se llama a un javascript para mostrar la ventana de errores
                Page.ClientScript.RegisterStartupScript(this.GetType(), "myScript", "$(document).ready(function() { mostrarMensajes('" + mensaje + "'); });", true);
            }
        }

        /// <summary>
        /// Método para guardar los cambios de un Tipo de Medio.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }
            TipoDeMedio tipoDeMedio = new TipoDeMedio(Convert.ToInt16(this.hOidTipoMedio.Value), this.txtNombre.Text, this.txtDescripcion.Text,
                                                      this.txtFecBaja.Text, this.chkEntregable.Checked, this.chkMarcaModelo.Checked,
                                                      this.chkExtension.Checked, ddlCentroCoste.SelectedValue);

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            int intGuardar;
            //Llamamos a la capa de negocio
            intGuardar = bll.guardarTipoDeMedio(tipoDeMedio);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);
            ddlCentroCoste.SelectedIndex = 0;
            //deshabilitamos la parte de mantenimeinto
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "desHabilitarMantenimiento();", true);
            //Si todo ha ido correctamente inicializamos la pantalla y relanzamos la búsqueda.
            btnBuscar_Click(null, null);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }
        }

        /// <summary>
        /// Botón buscar. Se buscarán los datos definidos por el filtro.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            //Variablen en la que recuperaremos el número de registros que devuelva la consulta
            int numRegistros = 0;

            var mensajes = new MensajesEntidad();
            bool hayMensajes = false;

            //Llamamos a la capa de negocio y almacenamos el resultado en el ViewState para que el dataset
            //perdure a los postback de paginación
            ViewState["dsGrid"] = bll.buscarTiposDeMedio(this.txtBusqueda.Text, out numRegistros);
            //cargamos el grid con los datos.
            recargaGrid();
            if (numRegistros > 0)
            {
                btnModificar.Enabled = true;
                btnEliminar.Enabled = true;
            }
            else
            {
                btnModificar.Enabled = false;
                btnEliminar.Enabled = false;
            }

            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }
        }

        
        /// <summary>
        /// Evento click de la parte servidora del botón de modificar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnModificar_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow di in grdTipos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {   
                    //las columnas ocultas del grid están asociadas al mismo como dataKeys ya que sobre
                    //una columna visible = false no se puden obtener sus datos.
                    this.txtNombre.Text = grdTipos.DataKeys[di.RowIndex].Values["var_nombre"].ToString();
                    this.txtNombre.Focus();
                    this.chkEntregable.Checked = Boolean.Parse(grdTipos.DataKeys[di.RowIndex].Values["bit_entregable"].ToString());
                    this.chkMarcaModelo.Checked = Boolean.Parse(grdTipos.DataKeys[di.RowIndex].Values["bit_marcamodelo"].ToString());
                    this.hOidTipoMedio.Value = grdTipos.DataKeys[di.RowIndex].Values["int_oidtipomedio"].ToString();
                    this.txtDescripcion.Text = grdTipos.DataKeys[di.RowIndex].Values["var_descripcion"].ToString();
                    if (!string.IsNullOrEmpty(grdTipos.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()))
                    {
                        this.txtFecBaja.Text = Convert.ToDateTime(grdTipos.DataKeys[di.RowIndex].Values["dat_fbaja"].ToString()).ToShortDateString();
                    }
                    this.chkExtension.Checked = Boolean.Parse(grdTipos.DataKeys[di.RowIndex].Values["bit_exttfno"].ToString());
                    this.ddlCentroCoste.SelectedValue = grdTipos.DataKeys[di.RowIndex].Values["var_cc"].ToString();
                    break;
                }
            }
            btnEliminar.Enabled = false;
            //despues se llama a una funcion javascript para la presentación de la pantalla en modo de edición.
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            mostrarConfirmPopUp(Constantes.MENSAJEBORRARTIPOMEDIO);
        }

        protected void btnPreguntaOk_Click(object sender, EventArgs e)
        {
            ConfirmPopUp.Hide();

            // Controlamos que la sesión no haya expirado
            if (System.Web.HttpContext.Current.Session[Constantes.LOGIN_USUARIO] == null)
            {
                System.Web.HttpContext.Current.Response.Redirect(Constantes.PAG_SESSION_EXPIRED);
            }

            string oidTipoMedio = String.Empty;

            foreach (GridViewRow di in grdTipos.Rows)
            {
                CheckBox chkBx = (CheckBox)di.FindControl("grdChk");

                if (chkBx != null && chkBx.Checked)
                {
                    oidTipoMedio = grdTipos.DataKeys[di.RowIndex].Values["int_oidtipomedio"].ToString();
                    break;
                }
            }

            var mensajes = new MB.Framework.ManejadorMensajes.MensajesEntidad();
            bool hayMensajes = false;

            int intGuardar;
            //Llamamos a la capa de negocio
            intGuardar = bll.eliminarTipoDeMedio(oidTipoMedio);
            // Recuperamos los mensajes del manejador
            mensajes = bll.mostrarMensajes(ref hayMensajes);

            if (hayMensajes)
            {
                mostrarPopUp(mensajes);
            }

            btnBuscar_Click(null, null);
        }

        private void mostrarConfirmPopUp(string mensaje)
        {
            lblMensajePregunta.Text = mensaje;
            ConfirmPopUp.Show();
        }

        private void mostrarPopUp(MensajesEntidad mensajes)
        {
            this.lblMensajeInfo.Text = mensajes.Mensaje;
            this.InfoPopUp.Show();
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, "desHabilitarMantenimiento();", true);
        }



        #region ordenacion y paginacion Grid

        /// <summary>
        /// Evento de paginación del gridview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdTipos_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            if (e.NewPageIndex != -1)
            {
                grdTipos.PageIndex = e.NewPageIndex;
                recargaGrid();
            }

        }

        /// <summary>
        /// Método para recargar el grid en caso de paginación.
        /// </summary>
        private void recargaGrid()
        {
            DataTable dataTable = ((DataSet)ViewState["dsGrid"]).Tables[0];
            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if (!string.IsNullOrEmpty(GridViewSortExpression))
                {
                    dataView.Sort = GridViewSortExpression + " " + GridViewSortDirection;
                }
                grdTipos.DataSource = dataView;
                grdTipos.DataBind();

            }
        }

        protected void grdTipos_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = ((DataSet)ViewState["dsGrid"]).Tables[0];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                dataView.Sort = GetSortExpression(e.SortExpression);

                grdTipos.DataSource = dataView;
                grdTipos.DataBind();
            }
        }

        private string GetSortExpression(string sortExpression)
        {
            if (sortExpression == GridViewSortExpression && GridViewSortDirection == Constantes.GRID_ORDEN_ASC)
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_DESC;
            }
            else
            {
                GridViewSortDirection = Constantes.GRID_ORDEN_ASC;
            }
            GridViewSortExpression = sortExpression;
            return sortExpression + " " + GridViewSortDirection;
        }

        private string GridViewSortDirection
        {
            get { return ViewState["SortDirection"] as string ?? Constantes.GRID_ORDEN_ASC; }
            set { ViewState["SortDirection"] = value; }
        }
        private string GridViewSortExpression
        {
            get { return ViewState["SortExpression"] as string ?? string.Empty; }
            set { ViewState["SortExpression"] = value; }
        }

        protected void grdTipos_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                foreach (TableCell cell in e.Row.Cells)
                {
                    if (cell.Controls.Count > 0)
                    {
                        LinkButton lbSorting = (LinkButton)cell.Controls[0] as LinkButton;
                        Image sortImage = new Image();

                        if (lbSorting.CommandArgument == GridViewSortExpression)
                        {
                            if (GridViewSortDirection.Equals(Constantes.GRID_ORDEN_ASC))
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_ASC;
                            }
                            else
                            {
                                sortImage.ImageUrl = Constantes.RUTA_IMG_ORDEN_GRID_DESC;
                            }
                            cell.Controls.Add(sortImage);
                        }
                    }
                }
            }
        }

        #endregion
                
    }
}