﻿using System;
using System.Configuration;
using System.Data;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASB.GMAP.Bll;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Web;

namespace ASB.GMAP.Web.MasterPages
{
    public partial class MasterMain : System.Web.UI.MasterPage
    {
        private WSMetadirectorio.Service oWSService = new WSMetadirectorio.Service();

        #region Propiedades

        private string loginUsuario = string.Empty;
        private string passwordUsuario = string.Empty;
        private string perfil = string.Empty;
        private MantMensajes manejador = new MantMensajes();

        #endregion

        /// <summary>
        /// Gestiona el evento Init de la página. Hay que crearlo para que se ejecute antes de que carguen las páginas hijas.
        /// </summary>
        /// <param name="sender">Origen del evento.</param>
        /// <param name="e">Datos del evento.</param>
        protected void page_Init(object sender, EventArgs e)
        {
            if (Session["LOGINUSUARIO"] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED, false);
            }
            else
            {
                if (!Page.IsPostBack)
                {   
                    //Para evitar el relogeo cada vez que se carga una página
                    if (Session["intIDPerfil"] == null)
                    {
                        inicializar();
                    }
                    // Comprobamos que tiene acceso a la página
                    if (!Util.tieneAcceso(this.Context))
                    {
                        Response.Redirect(Constantes.PAG_PERFIL_NOAUTH, false);
                    }
                    this.lblUsuario.Text = Session["LOGINUSUARIO"].ToString();
                    this.lblFechaSistema.Text = DateTime.Now.ToShortDateString();
                }
            }
        }

        /// <summary>
        /// Page Load de la página.
        /// </summary>
        /// <param name="sender">Origen del evento.</param>
        /// <param name="e">Datos del evento.</param>
        protected void page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //Carga menú principal de la Aplicación
                cargarMenus();
                // Mostramos los mensajes
                mostrarMensajes();
            }
        }

        /// <summary>
        /// Inicializa las variables necesarias.
        /// </summary>
        private void inicializar()
        {
           
            // 1º Obtengo el usuario logado del sso
            if (Request.ServerVariables[Constantes.LOGON_USER] != null)
            {
                loginUsuario = Request.ServerVariables[Constantes.LOGON_USER].ToString();
            }

            // Sesión expirada
            if (Session["LOGINUSUARIO"] == null)
            {
                Response.Redirect(Constantes.PAG_SESSION_EXPIRED, false);
            }
            else
            {
                // Obtengo el usuario y password de la página de login (habrá que quitarlo con el sso)
                loginUsuario = Session["LOGINUSUARIO"].ToString();
            }

            // Obtenemos el password
            if (Session["PASSWORDUSUARIO"] != null)
            {
                passwordUsuario = Session["PASSWORDUSUARIO"].ToString();
            }


            // 2º Obtenemos el perfil de la aplicación
            if ((loginUsuario != "" && loginUsuario != null))
            {
                perfil = obtenerPerfil(loginUsuario);  // Session["intIDPerfil"].ToString();  //JMCANO
                //obtenerIDUsuario(loginUsuario);
                /// PARA PRUEBAS SOLO ///
                //perfil = loginUsuario;  //para hacer las pruebas cogemos el perfil del login
                //Session["intIDPerfil"] = perfil;
                Session["idEmpleado"] = "0002";
                
                /// PARA PRUEBAS SOLO ///
            }

            // Se comprueba si el usuario logado tiene perfil en esta aplicación, sino lo tiene se muestra un mensaje de error 
            if (perfil == string.Empty)
            {
                Response.Redirect(Constantes.PAG_PERFIL_KO, false);
            }
            else
            {   
                // Si el usuario tiene perfil para acceder a la aplicación, se verifica que funcion tiene
                //this.lblPerfilFuncion.Text = obtenerFuncion(perfil);
                this.lblPerfilFuncion.Text = "MI PERFIL";

                //Si el perfil tiene acceso a la página de Gestión de Alertas esá será la pantalla de inicio.
                if (Util.tieneAccesoGestionAlertas(Session["intIDPerfil"].ToString()))
                {
                    Response.Redirect(Constantes.PAG_GESTION_ALERTAS, false);
                }
            } 
        }

        #region Métodos privados

        /// <summary>
        /// asignamos los roles al usuario. Para nuestro caso perfil = rol
        /// </summary>
        private void asignarRolesUsuario()
        {
            string[] rolesUsuario = Session["intIDPerfil"].ToString().Split('#');
            foreach (string rol in rolesUsuario)
            {
                if (!Roles.RoleExists(rol))
                {
                    Roles.CreateRole(rol);
                }
                if (!Roles.IsUserInRole(Session["idEmpleado"].ToString(), rol))
                {
                    Roles.AddUserToRole(Session["idEmpleado"].ToString(), rol);
                }
            }
            string[] d = Roles.GetAllRoles();
            //System.Web.Security.FormsIdentity id = (System.Web.Security.FormsIdentity)HttpContext.Current.User.Identity;
            //HttpContext.Current.User = new System.Security.Principal.GenericPrincipal(id, rolesUsuario);
        }

        /// <summary>
        /// DEVUELVE EL PERFIL RECOGIÉNDOLO DEL SERVICIO WEB.
        /// </summary>
        /// <param name="LoginUsuario">Usuario Logado.</param>
        /// <returns>Devuelve el perfil.</returns>
        private string obtenerPerfil(string LoginUsuario)
        {
            string idAplicacion = ConfigurationManager.AppSettings[Constantes.ID_APLICACION].ToString();
            string perfilesUsuario = oWSService.getApplicationProfiles(LoginUsuario, idAplicacion);
            //string perfilesUsuario = String.Empty;
            //char separador = Convert.ToChar(Constantes.SEPARADOR);
            //string[] arrayPerfiles = perfilesUsuario.Split(separador);

            Session["intIDPerfil"] = perfilesUsuario;//arrayPerfiles[0].ToString();

            return Session["intIDPerfil"].ToString();
        }

        /// <summary>
        /// DEVUELVE EL ID DE USUARIO RECOGIÉNDOLO DEL SERVICIO WEB.
        /// </summary>
        /// <param name="LoginUsuario">Usuario Logado.</param>
        private void obtenerIDUsuario(string LoginUsuario)
        {
            Session["idEmpleado"] = oWSService.getProperty(LoginUsuario,"EmployeeNumber");
        }

        #endregion


        /// <summary>
        /// Método que carga el menu superior.
        /// </summary>
        protected void cargarMenus()
        {
            Menus oMenus = new Menus(ref manejador);
            try
            {
                DataTable menu;
                menu = oMenus.cargarMenu(Session["intIDPerfil"].ToString());
                foreach (DataRow menuItem in menu.Rows)
                {
                    // Esta condicion indica que son elementos padre.
                    if (menuItem[Ent.Constantes.CODIGO_MENU_PADRE].Equals(DBNull.Value))
                    {
                        MenuItem mnuMenuItem = new MenuItem();
                        mnuMenuItem.Value = menuItem[Ent.Constantes.CODIGO_MENU].ToString();
                        mnuMenuItem.Text = menuItem[Ent.Constantes.DESCRIPCION_MENU].ToString();
                        mnuMenuItem.NavigateUrl = menuItem[Ent.Constantes.URL].ToString();
                        // Agregamos el Item al menu
                        mnuPrincipal.Items.Add(mnuMenuItem);
                        // Hacemos un llamado al metodo recursivo encargado de generar el arbol del menu.
                        crearArbolMenu(ref mnuMenuItem, menu);
                    }
                }
                // Mostramos los mensajes
                mostrarMensajes();
            }
            catch (Exception err)
            {
                manejador.agregar(err);
            }
        }

        private void crearArbolMenu(ref MenuItem mnuMenuItem, DataTable dtMenuItems)
        {
            // Recorremos cada elemento del datatable para poder determinar cuales son elementos hijos
            // del menuitem dado pasado como parametro ByRef.
            foreach (DataRow drMenuItem in dtMenuItems.Rows)
            {
                if ((drMenuItem[Ent.Constantes.CODIGO_MENU_PADRE].ToString().Equals(mnuMenuItem.Value)) && (!drMenuItem[Ent.Constantes.CODIGO_MENU].Equals(drMenuItem[Ent.Constantes.CODIGO_MENU_PADRE])))
                {
                    MenuItem mnuNewMenuItem = new MenuItem();
                    mnuNewMenuItem.Value = drMenuItem[Ent.Constantes.CODIGO_MENU].ToString();
                    mnuNewMenuItem.Text = drMenuItem[Ent.Constantes.DESCRIPCION_MENU].ToString();
                    mnuNewMenuItem.NavigateUrl = drMenuItem[Ent.Constantes.URL].ToString();
                    if (mnuNewMenuItem.Text.Contains(Constantes.SPA))
                    {
                        mnuNewMenuItem.Target = "_blank";
                    }
                    // Agregamos el Nuevo MenuItem al MenuItem que viene de un nivel superior
                    mnuMenuItem.ChildItems.Add(mnuNewMenuItem);                    
                    // Llamada recursiva para ver si el nuevo menu item aun tiene elementos hijos
                    crearArbolMenu(ref mnuNewMenuItem, dtMenuItems);
                }
            }
        }

        /// <summary>
        /// Método con el que se obtiene las funciones que tiene el usuario logado.
        /// </summary>
        /// <param name="perfil">Perfil del usuario logado.</param>
        /// <returns>Funciones que tiene el usuario logado.</returns>
        private string obtenerFuncion(string perfil)
        {
            /*Menus oMenus = new Menus(ref manejador);
            string funcionPerfil = Constantes.SIN_PERMISOS;

            funcionPerfil = oMenus.obtenerFuncion(perfil);
            if (manejador.existenMensajes())
            {
                mostrarMensajes();
            }

            return funcionPerfil;*/
            return "";
        }

        /// <summary>
        /// Muestra los mensajes que se producen al carga la ventana.
        /// </summary>
        public void mostrarMensajes()
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;
            // Si existen mensajes se muestran
            if (manejador.existenMensajes())
            {
                string mensaje = manejador.Mensajes[0].Mensaje;
                string tipoMensaje = manejador.Mensajes[0].TipoMensaje.ToString();
                // Si se ha generado la excepción la guardamos
                if (manejador.Mensajes[0].Excepcion != null)
                {
                    ex = manejador.Mensajes[0].Excepcion.Message;
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());

                Response.Redirect(Constantes.PAG_ERROR_CARGA + mensaje, false);
            }


        }

 

    }
}