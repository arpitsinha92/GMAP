﻿using System;
using System.Collections.Generic;

namespace ASB.GMAP.Web
{
    public class Constantes
    {
        #region Constantes
        // PÁGINA MASTER
        public const string LOGON_USER = "LOGON_USER";
        public const string LOGIN_USUARIO = "LOGINUSUARIO";
        public const string PASSWORD_USUARIO = "PASSWORDUSUARIO";

        public const string ID_APLICACION = "IDAplicacionGMAP";
        public const string SEPARADOR = "#";

        public const string ID_PERFIL = "intIDPerfil";

        public const string SIN_PERMISOS = "N";
      
        // Menu
        public const char MENU_SUPERIOR = 'T';
        public const char MENU_IZQUIERDA = 'L';


        // PÁGINA LOGIN
        public const string MENSAJE = "Msg";
        public const string PAG_LOGIN_KO = "Login.aspx?Msg=No se ha autenticado correctamente";
        public const string PAG_LOGIN_OK = "UI/Funcional/MisCesiones.aspx";
        public const string PAG_SESSION_EXPIRED = "~/Login.aspx?Msg=La sesión ha caducado";
        public const string PAG_PERFIL_KO = "~/Login.aspx?Msg=Usuario Incorrecto";
		public const string PAG_PERFIL_NOAUTH = "~/Login.aspx?Msg=Acceso Denegado";
        public const string PAG_ERROR_CARGA = "~/Login.aspx?Msg=";
        public const string PAG_GESTION_ALERTAS = "/UI/Funcional/GestionAlertas.aspx";

        // EXCEL
        public const string FICHERO = "Listado.xls";

        //Pantallas loggin
        public const string PANTALLA_GESTION_MARCAS_MODELOS= "GestionMarcasModelos";
        public const string PANTALLA_GESTION_PERFILES = "GestionPerfiles";
        public const string PANTALLA_TIPOS_DE_MEDIOS = "TiposDeMedios";
        public const string PANTALLA_BUSQUEDA_DEPARTAMENTOS = "BusquedaDepartamentos";
        public const string PANTALLA_BUSQUEDA_PERSONAS = "BusquedaPersonas";
        public const string PANTALLA_CESION_MEDIO_DISPONIBLE = "CesionMedioDisponible";
        public const string PANTALLA_EDITAR_CESION = "EditarCesion.aspx ";
        public const string PANTALLA_EDITAR_MEDIO = "EditarMedio";
        public const string PANTALLA_FINALIZAR_CESION = "FinalizarCesion";
        public const string PANTALLA_GESTION_ALERTAS = "GestionAlertas";
        public const string PANTALLA_GESTION_DE_MEDIOS = "GestionDeMedios";
        public const string PANTALLA_GESTION_DEPARTAMENTOS = "GestionDepartamentos";
        public const string PANTALLA_GESTION_PERSONAS = "GestionPersonas";
        public const string PANTALLA_MEDIO_NUEVO = "MedioNuevo";
        public const string PANTALLA_MIS_CESIONES = "MisCesiones";
        public const string PANTALLA_INFORME_AVANZADO_DEPARTAMENTOS = "InformeAvanzadoDepartamentos";
        public const string PANTALLA_INFORME_AVANZADO_PERSONAS = "InformeAvanzadoPersonas";
        public const string PANTALLA_INFORMA_CUANTALIS = "InformeCuantalis";



        //Tipo de mensaje de Logging
        public const string INFORMATIVO = "Informativo";
        public const string ERROR_PAGINA_LOGIN = "Error en login";
        public const string ERROR_GLOBAL_ASAX = "Error en Global Asax";


        // Constantes varias
        public const Char CARACTER_SEXO_HOMBRE = 'H';
        public const Char CARACTER_SEXO_MUJER = 'M';
        public const Char CARACTER_SEXO_TODOS = 'T';
        public const String VALOR_TRUE = "true";
        public const String VALOR_FALSE = "false";
        public const String SEXO_HOMBRE = "Hombre";
        public const String SEXO_MUJER = "Mujer";
        public const String VALOR_SI = "Sí";
        public const String VALOR_NO = "No";
        public const String TEXTO_DEFECTO_COMBO = "Todos/as";
        public const String VALOR_DEFECTO_COMBO = "-1";
        public const String VALOR_DEFECTO_COMBO_ESTADO_DEPT = "-2";
        public const String DEPARTAMENTO_SIN_SELECCIONAR = "0";
        public const String READONLY = "readonly";
        public const String DISABLED = "disabled";
        public const String VALOR_DEFECTO_CMB_DEP = "Seleccione un dep.";
        public const String ACCION_VISUALIZAR = "Visualizar";
        public const String ACCION_NUEVO = "Nuevo";
        public const String ACCION_MODIFICAR = "Modificar";
        public const String ACCION_VOLVER = "volver";
        public const String TAG_ACCION = "accion";
        public const String VALOR_TODOS_COMBO = "";
        public const String SI = "Si";
        public const String NO = "No";
        public const String NO_ACTIVO = "No Activo";
        public const String GRID_ORDEN_ASC = "ASC";
        public const String GRID_ORDEN_DESC = "DESC";
        public const String ACTIVO = "Activo";
        public const String INACTIVO = "Inactivo";
        public const String SPA = "SPA";
        
        // Variables de sesión
        public const String SESION_PAG_ACT = "pag";
        public const String VALOR_UNDEFINED = "undefined";
        public const String ACCION_USER = "accion";        
        public const String VENTANAPADRE = "ventanaPadre";
        public const String VENTANAANTERIOR = "ventanaAnterior";
        public const String PARAMETROS = "parametros";
        public const String IDEMPLEADO = "idEmpleado";
        public const String ESTADO_PANTALLA_PERSONAS_DEPARTAMENTOS_MEDIOS_ALERTAS = "estadoPantallaPersonasDepartamentosMediosAlertas";


        //Variables de parámetros
        public const String OIDMEDIO = "oidMedio";
        public const String IDMEDIO = "idMedio";
        public const String INT_OIDMEDIO = "int_oidmedio";
        public const String TIPOMEDIO = "tipoMedio";
        public const String MODELO = "nomModelo";
        public const String NOMEMPLEADO = "nomEmpleado";
        public const String NOMDEPARTAMENTO = "nomDepartamento";
        public const String OIDEMPLEADO = "oidEmpleado";
        public const String OIDDEPARTAMENTO = "oidDepartamento";
        public const String NOMBREDEPARTAMENTO = "nomDepartamento";
        public const String OIDCESION = "oidCesion";
        public const String FBAJAMEDIO = "fecBajaMedio";
        public const String MIGAS_PAN = "migasPan";
        public const String MIGAS_PAN_GESTION_MEDIOS = "Gestión de Medios";
        public const String MIGAS_PAN_GESTION_PERSONAS = "Gestión de Personas";
        public const String MIGAS_PAN_GESTION_DEPARTAMENTOS = "Gestión de Departamentos";
        public const String MIGAS_PAN_CESION_MEDIO = "Cesión de medio disponible";
        public const String MIGAS_PAN_GESTION_ALERTAS = "Gestión de alertas";
        public const String MIGAS_PAN_FINALIZAR_CESION = "Finalizando cesión";
        public const String MIGAS_PAN_MEDIO_NUEVO = "Creando medio";
        public const String MIGAS_PAN_EDITAR_CESION = "Editando cesión";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_NOMBRE = "nombre";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_EMPRESA = "IdEmpresa";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_PAGINA_GRID = "numPagina";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_REGISTRO_SELECCIONADO = "oidPerDept";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_ID = "IDMedio";
        public const String PANTALLA_MEDIOS_ID = "IDMedioGestionMedios";
        public const String PANTALLA_MEDIOS_CESIONES_ACTIVAS = "cesionesActivasMedios";
        public const String PANTALLA_MEDIOS_TIPOS_MEDIO = "tiposMedioMedio";
        public const String PANTALLA_MEDIOS_TIPOS_MEDIO_TODOS = "tiposMedioTodos";
        public const String PANTALLA_MEDIOS_POR_CESION = "mediosPorCesion";
        public const String PANTALLA_MEDIOS_POR_ESTADO = "mediosPorEstado";
        public const String PANTALLA_MEDIOS_PAGINA = "paginaMedios";
        public const String PANTALLA_MEDIOS_REGISTRO_SELECCIONADO = "regSelMedio";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_TIPO_MEDIO = "tipoMedio";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_CESIONES_ACTIVAS = "cesionesActivas";
        public const String PANTALLA_PERSONAS_DEPARTAMENTOS_PAGINA_CESIONES = "numPaginaCesiones";
        public const String PANTALLA_ALERTAS_EMPLEADOS_NOMBRE = "nombreEmp";
        public const String PANTALLA_ALERTAS_EMPLEADOS_TIPO_MEDIO = "tipoMedioEmp";
        public const String PANTALLA_ALERTAS_EMPLEADOS_PRORROGADO = "prorrogadoEmp";
        public const String PANTALLA_ALERTAS_DEPARTAMENTO_NOMBRE = "nombreDept";
        public const String PANTALLA_ALERTAS_DEPARTAMENTO_TIPO_MEDIO = "tipoMedioDept";
        public const String PANTALLA_ALERTAS_DEPARTAMENTO_PRORROGADO = "prorrogadoDept";

        public const String NOMBRE_TIPO_MEDIO_COMBO_CESIONES = "VAR_NOMBRE";
        public const String ID_TIPO_MEDIO_COMBO_CESIONES = "INT_OIDTIPOMEDIO";

        //tablas para la carga de combos
        public const String TIPOSDEMEDIOS = "Tb_TiposMedios";
        public const String MARCAS = "Tb_Marcas";
        public const String EMPRESAS = "Vw_Empresas";
        public const String MODELOS = "Tb_Modelos";
        public const String PERSONAS = "Vw_Personas_ActivasyBajas";
        public const String EMPRESASDESC = "Vw_EmpresasDesc";
        public const String MARCASMODELO = "Tb_Marcas_Modelo";

        //Mensajes
        public const String MENSAJE_PERSONA_ACTIVA = "La persona seleccionada ha de estar activa.";
        public const String MENSAJE_DEPARTAMENTO_ACTIVO = "El departamento seleccionado ha de estar activo.";
        public const String MENSAJECESIONACTIVA = "La cesión seleccionada ha de estar activa.";
        public const String MENSAJEMEDIOACTIVO = "El medio seleccionado ha de estar activo.";
        public const String MENSAJEMEDIOCEDIDO = "El medio seleccionado está actualmente cedido.";
        public const String MENSAJEMEDIOCESIONACTIVA = "Por favor, elija un medio con una cesión activa.";
        public const String MENSAJEBORRARMEDIO = "¿Realmente desea eliminar este medio?";
        public const String MENSAJEMEDIONOACTIVO = "El medio ya ha sido dado de baja.";
		public const String MENSAJESELECCIONARUNO = "Por favor, seleccione una fila.";
        public const String MENSAJEBORRARFUNCION = "¿Realmente desea eliminar esta función?";
        public const String MENSAJEBORRARPERFIL = "¿Realmente desea eliminar este perfil?";
        public const String MENSAJEBORRARTIPOMEDIO = "¿Realmente desea eliminar este tipo de medio?";
        public const String MENSAJEBORRARMARCA = "¿Realmente desea eliminar esta marca?";
        public const String MENSAJEBORRARMODELO = "¿Realmente desea eliminar este modelo?";
		public const String MENSAJEMODIFPERFADMIN = "No se puede modificar ni eliminar el perfil de Administrador";
        public const String MENSAJEMODIFFUNCADMIN = "No se puede modificar ni eliminar la función de Administración";
		public const String MENSAJEFUNCIONDUPLICADA = "Ya existe una función con ese nombre. Por favor, introduzca otro distinto";
        public const String MENSAJEPERFILDUPLICADO = "Ya existe un perfil con ese nombre. Por favor, introduzca otro distinto";
        public const String MENSAJEFECHAFINPRORROGABAJAMEDIO = "La fecha de fin de prorroga ha de ser menor o igual a la fecha de baja del medio";
        public const String MENSAJEFECHAFINCESIONBAJAMEDIO = "La fecha de fin de cesión ha de ser menor o igual a la fecha de baja del medio";
        public const String MENSAJEFECHAFINCESIONEDITARMEDIO = "El medio está actualmente cedido. Por ello la fecha de baja ha de ser superior o igual a la fecha de fin de cesión.";
        public const String MENSAJEFECHAPRORROGACESIONEDITARMEDIO = "El medio está actualmente cedido. Por ello la fecha de baja ha de ser superior o igual a la fecha de fin de prorroga.";
        public const String MENSAJEFECHABAJAEDITARMEDIO = "El medio está actualmente cedido y sin fecha de finalización de cesión. Para poder editar la baja del medio es necesario que la cesión tenga una fecha de fin.";
        public const String GRIDVACIO = "No se han encontrado datos";

        // Generación de Informes
        public const String RUTA_PLANTILLA_EXCELA = "~/Plantillas/PlantillaA.xlsx";
		public const String RUTA_PLANTILLA_EXCELB = "~/Plantillas/PlantillaB.xlsx";
        public const String RUTA_PLANTILLA_EXCELC = "~/Plantillas/PlantillaC.xlsx";
        public const String RUTA_PLANTILLA_EXCELD = "~/Plantillas/PlantillaD.xlsx";
		public const String RUTA_PLANTILLA_EXCELE = "~/Plantillas/PlantillaE.xlsx";
        public const String RUTA_PLANTILLA_EXCELF = "~/Plantillas/PlantillaF.xlsx";
        //public const String RUTA_PLANTILLA_WORD = "~/Plantillas/Plantilla.docx";
        public const String RUTA_PLANTILLA_WORD = "~/Plantillas/PlantillaV3.docx";
        
        public const String RUTA_XML_ACCIONES = "~/Acciones/Acciones.xml";
        public const String RUTA_IMG_ORDEN_GRID_ASC = "~/Images/ASC.gif";
        public const String RUTA_IMG_ORDEN_GRID_DESC = "~/Images/DESC.gif";

public static List<string> CAMPOSCENTRADOS = new List<string>() {
            "F. Inicio Cesión", 
            "F. Fin Cesión", 
            "Entregado", 
            "F. Fin Prórroga", 
            "Prejub./Expat.", 
            "F. Baja Empleado",
            "FECHA INICIO",
            "FECHA FIN"
        };
        #endregion
    }
}