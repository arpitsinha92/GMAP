﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Threading;
using MB.Framework.Log;

namespace ASB.GMAP.Web
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception ex = Server.GetLastError();
            string mensaje = String.Empty;
            if (ex != null)
            {
                Log.escribirLog("MESSAGE: " + ex.Message +
                                "\nSOURCE: " + ex.Source +
                                "\nFORM: " + Request.Form.ToString() +
                                "\nQUERYSTRING: " + Request.QueryString.ToString() +
                                "\nTARGETSITE: " + ex.TargetSite +
                                "\nSTACKTRACE: " + ex.StackTrace, Constantes.ERROR_GLOBAL_ASAX);
                mensaje = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            }
            Response.Redirect(Constantes.PAG_ERROR_CARGA + "Se ha producido un error: " + mensaje);
        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}