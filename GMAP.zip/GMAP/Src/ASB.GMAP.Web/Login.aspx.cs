﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Configuration;
using System.Web.Configuration;
using MB.Framework.Log;

namespace ASB.GMAP.Web
{
    public partial class Login : System.Web.UI.Page
    {
        private WSMetadirectorio.Service oWSService = new WSMetadirectorio.Service();

        protected void Page_Load(object sender, EventArgs e)
        {

            //Para no pasar por el login
            //Session[Constantes.LOGIN_USUARIO] = "1";
            //Session[Constantes.PASSWORD_USUARIO] = "";
            //Response.Redirect(Constantes.PAG_LOGIN_OK);
            /**************************************/

            // Se borran los datos de las variables de sesión
            if (Page.IsPostBack)
                Session.Contents.RemoveAll();

            // Si me han redirigido desde la página de default porque no es válido mi usuario, muestro mensaje.
            if (Request.QueryString[Constantes.MENSAJE] != null)
            {
                lblMensaje.ForeColor = System.Drawing.Color.Red;
                lblMensaje.Text = Request.QueryString[Constantes.MENSAJE];
            }

            //if (Request.QueryString["ss"] == "1")
            //{
            //    this.MasterMain.MenuVisibilidad = false;
            //    Session.Abandon();
            //    FormsAuthentication.SignOut();
            //    Response.Redirect("https://sibeb325.madr.daimlerchrysler.com/amserver/UI/Logout");
            //}
            
           

        }

        /// <summary>
        /// Evento Click del botón iniciar sesión.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnValidar_Click(object sender, EventArgs e)
        {
            try
            {
                //Mando el usuario a la varible de session que usará posteriormente la master.page

                //FormsAuthentication.RedirectFromLoginPage("0002", false);

                // Si el usuario es valido redirigimos
                Session["LOGINUSUARIO"] = txtUsuario.Text.ToUpper();
                Session["PASSWORDUSUARIO"] = txtContrasena.Text;

                FormsAuthentication.RedirectFromLoginPage(txtUsuario.Text.ToUpper(), false);

                //Validar usuario y password
                /*Comentar la validación de usuario y password para la subida a Test y descomentar para producción **/
                if (!ValidarUsuario(txtUsuario.Text.ToUpper(), txtContrasena.Text))
                {
                    Response.Redirect(Constantes.PAG_LOGIN_KO, false);
                }

                //Configuration conf = WebConfigurationManager.OpenWebConfiguration("~");
                //SystemWebSectionGroup swsg = (SystemWebSectionGroup)conf.GetSectionGroup("location");
                //AuthorizationRule rule = new AuthorizationRule(AuthorizationRuleAction.Deny);

                //Configuration config = WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);
                //AuthorizationSection section = (AuthorizationSection)config.GetSection("system.web/authorization");

                ////ConfigurationLocation config = ConfigurationLocation;
                ////Configuration con = config.OpenConfiguration();
                ////ConfigurationLocationCollection conCollection = con.Locations;
                ////int prue = conCollection.Count;

                //ConfigurationLocationCollection loccol = section.CurrentConfiguration.Locations;

                //foreach (ConfigurationLocation loc in loccol)
                //{
                //    Configuration conf2 = loc.OpenConfiguration();
                //    AuthorizationSection section2 = (System.Web.Configuration.AuthorizationSection)conf2.GetSection("system.web/authorization");
                //    AuthorizationRule autho = new System.Web.Configuration.AuthorizationRule(System.Web.Configuration.AuthorizationRuleAction.Allow);
                //    //10. Add the New Role to Authorization Section
                //    int cont = autho.Roles.Count;
                //    autho.Roles.Add("2");
                //    int inces = section2.Rules.IndexOf(autho);
                //    section2.Rules.Add(autho);
                //    //11. Save the "sub", or the specific location inside the web.config file.
                //    conf2.Save();
                //}

                //rule.Users.Add("1");
                //swsg.Authorization.Rules.Add(rule);


                //conf.Save(ConfigurationSaveMode.Modified);
                else
                {
                    Response.Redirect(Constantes.PAG_LOGIN_OK, false);

                    // JMCANO
                    //string perfil = obtenerPerfil(txtUsuario.Text.ToUpper());

                    //if (Util.tieneAccesoGestionAlertas(perfil))
                    //{
                    //    Response.Redirect(Constantes.PAG_GESTION_ALERTAS, false);
                    //}
                    //else
                    //{ 
                    //    Response.Redirect(Constantes.PAG_LOGIN_OK, false);
                    //}
                    // END_JMCANO
                }
            }
            catch (Exception ex)
            {
                Log.escribirLog(ex.Message, Constantes.ERROR_PAGINA_LOGIN);
            }
        }

        /// <summary>
        /// DEVUELVE EL PERFIL RECOGIÉNDOLO DEL SERVICIO WEB.
        /// </summary>
        /// <param name="LoginUsuario">Usuario Logado.</param>
        /// <returns>Devuelve el perfil.</returns>
        //private string obtenerPerfil(string LoginUsuario)
        //{
        //    string idAplicacion = ConfigurationManager.AppSettings[Constantes.ID_APLICACION].ToString();
        //    string perfilesUsuario = oWSService.getApplicationProfiles(LoginUsuario, idAplicacion);
        //    //string perfilesUsuario = String.Empty;
        //    //char separador = Convert.ToChar(Constantes.SEPARADOR);
        //    //string[] arrayPerfiles = perfilesUsuario.Split(separador);

        //    Session["intIDPerfil"] = perfilesUsuario;//arrayPerfiles[0].ToString();

        //    return Session["intIDPerfil"].ToString();
        //}

        /// <summary>
        /// LLAMA AL SERVICIO WEB PARA DETERMINAR EL USUARIO
        /// </summary>
        /// <param name="LoginUsuario"></param>
        /// <param name="PasswordUsuario"></param>
        /// <returns></returns>
        private bool ValidarUsuario(string LoginUsuario, string PasswordUsuario)
        {
            return oWSService.ValidarUsuario(LoginUsuario, PasswordUsuario) == LoginUsuario; 
        }

    }
}