﻿// Variables de uso general
// Página que se está consultando actualmente
var paginaAct = 1;
// Orden que está afectando al listado
var ordenAct = "";
// Booleano que indica si el orden es descendiente o no
var ordenDescAct = false;
// Filtros que están afectando al listado
var filtrosAct = "[]";

// Realiza la llamada ajax para recuperar el listado de usuarios pasándole la página que queremos consultar, el orden
// en el que se van a mostrar los datos, si es ascendiente o descendiente, los filtros escogidos por el usuario
// y un booleano que indica si estamos pidiendo el listado porque hemos hecho una ordenación por alguna columna
function cargarListado(pag, orden, ordenDesc, filtros, esOrdenacion) {
    // Construye el objeto json con los parámetros recibidos
    var parametros = [];
    parametros.push("'pag':" + pag);
    parametros.push("'orden':'" + orden + "'");
    parametros.push("'descendiente':" + ordenDesc);
    parametros.push("'listaFiltros':" + filtros);
    // Convierte el array de parámetros en una línea de la forma { 'param1' : 'valor1', 'param2' : 'valor2', ... }
    var params = '{' + parametros.join(',') + '}';
    // Variable que almacenará la tabla recuperada
    var datosUsuario;
    // Realiza la llamada ajax
    $.ajax({
        // Los parámetros se envían por post
        type: "POST",
        // Método web que recibirá la llamada ajax
        url: "gestion_usuarios.aspx/obtenerListado",
        // Parámetros que recibirá el servicio web
        data: params,
        // Formato de la llamada (igual para todas las llamadas)
        contentType: "application/json; charset=utf-8",
        // Tipo en el que se pasarán los parámetros
        dataType: "json",
        success: function (msg) {
            // Recupera los datos
            datosUsuario = msg.d;
            // Construye un objeto javascript a partir de los datos recibidos
            var userData = $.parseJSON(datosUsuario);
            // Si userData[0] es false, todo ha ido bien
            if (userData[0] == false) {
                // Llama a la función que muestra los datos en la tabla
                rellenarCuerpoTabla(userData[1]);
                // Actualiza la página actual
                paginaAct = pag;
                // Si estamos ordenando, llama a la función que muestra la flecha en la cabecera
                // de la columna
                if (esOrdenacion) {
                    mostrarOrden(orden, ordenDesc);
                }
            }
            else {
                // Ha habido un error, así que muestra el mensaje de error en la pantalla
                $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                $("#dialog-msg").dialog("open");
                $("#dialog-msg .ui-dialog-titlebar-close").hide();
            }
        }
    });
}

// Rellena las filas de la tabla con los datos recibidos
// Recibe un array de arrays, con los registros que tiene que mostrar en cada fila
// El primer elemento del array debe ser el id que identifica la fila
function rellenarCuerpoTabla(datos) {
    var cuerpo = "";
    // Recorremos las filas de los resultados
    if (datos.length > 0) {
        for (var y = 0; y < datos.length; y++) {
            // Diferenciamos entre filas pares e impares
            if (y % 2 == 0) {
                cuerpo += "<tr class='fila_par'>";
            }
            else {
                cuerpo += "<tr class='fila_impar'>";
            }

            // Agregamos la celda con las acciones comunes (el id del elemento tiene que venir en primer lugar)
            cuerpo += "<td>";
            cuerpo += "<a onfocus='this.blur();' href='javascript:visualizar(" + datos[y][0] + ");' >";
            cuerpo += "<img src='../../Images/Botones/11pt_Search.png' alt='Visualizar' onmouseover=\"cambiar_img(this, '../../Images/Botones/11pt_Search_over.png');\" onmouseout=\"cambiar_img(this, '../../Images/Botones/11pt_Search.png');\">";
            cuerpo += "</a>";
            cuerpo += "<a onfocus='this.blur();' href='javascript:modificar(" + datos[y][0] + ");' >";
            cuerpo += "<img src='../../Images/Botones/11pt_edit.png' alt='Modificar' onmouseover=\"cambiar_img(this, '../../Images/Botones/11pt_edit_over.png');\" onmouseout=\"cambiar_img(this, '../../Images/Botones/11pt_edit.png');\">";
            cuerpo += "</a>";
            cuerpo += "<a onfocus='this.blur();' href='javascript:borrar(" + datos[y][0] + ");' >";
            cuerpo += "<img src='../../Images/Botones/11pt_delete.png' alt='Borrar' onmouseover=\"cambiar_img(this, '../../Images/Botones/11pt_delete_over.png');\" onmouseout=\"cambiar_img(this, '../../Images/Botones/11pt_delete.png');\">";
            cuerpo += "</a>";
            cuerpo += "</td>";

            // Agregamos el resto de las celdas
            for (var x = 1; x < datos[y].length; x++) {
                // Si el tamaño es mayor que 20, recortamos el campo y añadimos el tooltip
                if (datos[y][x].length > 20) {
                    cuerpo += "<td title='" + datos[y][x] + "'>" + datos[y][x].substring(0, 20) + "...</td>";
                }
                else {
                    cuerpo += "<td>" + datos[y][x] + "</td>";
                }
            }

            // Cerramos la fila
            cuerpo += "</tr>";
        }
        // Como se han recuperado datos, se muestran las cabeceras y se habilita el botón de exportar a excel
        $("#tabla_listado thead").show();
        $("#boton_exportar").show();
        $("#boton_exportarLectura").hide();
    }
    else {
        var numColumnas = $("#tabla_listado th").length;
        cuerpo += "<td colspan='" + numColumnas + "'>No se han encontrado resultados</td>";
        // Como no se han recuperado datos, se ocultan las cabeceras y se deshabilita el botón de exportar a excel
        $("#tabla_listado thead").hide();
        $("#boton_exportar").hide();
        $("#boton_exportarLectura").show();
    }

    // Cargamos el cuerpo de la tabla con el código recién generado
    $("#tabla_listado tbody").html(cuerpo);
}

// Función que recupera el número de páginas a partir de los filtros recibidos
// para montar el paginador
function cargarPaginador(pag, filtros) {
    $.ajax({
        type: "POST",
        url: "gestion_usuarios.aspx/obtenerPaginacion",
        data: "{'pag':" + pag + ",'listaFiltros':" + filtros + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            paginaAct = pag;
            rellenarPaginador(msg.d);
        }
    });
}

// Crea el paginador según el número de páginas del que disponemos y la página actual
function rellenarPaginador(numPaginas) {
    var cuerpo = "";
    if (numPaginas > 1) {

        // Si no estamos en la primera página, mostramos los enlaces a la primera página y a la página anterior
        if (paginaAct > 1) {
            // Muestra el enlace a la primera página 
            cuerpo += "<li class='primera_pag'><a onfocus='this.blur();' href='javascript:paginar(1);'>";
            cuerpo += "<img src='../../Images/Botones/first.png' onmouseover=\"javascript:cambiar_img(this, '../../Images/Botones/first_over.png');\" onmouseout=\"javascript:cambiar_img(this, '../../Images/Botones/first.png');\" />";
            cuerpo += "</a></li>";
            // Muestra el enlace a la página anterior
            cuerpo += "<li class='pagina_ant'><a onfocus='this.blur();' href='javascript:paginar(" + (paginaAct - 1) + ");'>";
            cuerpo += "<img src='../../Images/Botones/prev.png' onmouseover=\"javascript:cambiar_img(this, '../../Images/Botones/prev_over.png');\" onmouseout=\"javascript:cambiar_img(this, '../../Images/Botones/prev.png');\" />";
            cuerpo += "</a></li>";
        }

        // Montamos los enlaces a las páginas, excepto la página actual, que no debe ser un enlace
        for (var i = 1; i <= numPaginas; i++) {
            cuerpo += "<li>";
            if (i == paginaAct) {
                cuerpo += "<span class='pagina_actual'>" + i + "</span>";
            }
            else {
                cuerpo += "<a onfocus='this.blur();' href='javascript:paginar(" + i + ");'>" + i + "</a>";
            }
            cuerpo += "</li>";
        }

        // Si no estamos en la última página, mostramos los enlaces a la última página y a la página siguiente
        if (paginaAct < numPaginas) {
            // Muestra el mensaje a la página siguiente
            cuerpo += "<li class='pagina_sig'><a onfocus='this.blur();' href='javascript:paginar(" + (paginaAct + 1) + ");'>";
            cuerpo += "<img src='../../Images/Botones/next.png' onmouseover=\"javascript:cambiar_img(this, '../../Images/Botones/next_over.png');\" onmouseout=\"javascript:cambiar_img(this, '../../Images/Botones/next.png');\" />";
            cuerpo += "</a></li>";
            // Muestra el mensaje a la última página
            cuerpo += "<li class='ultima_pag'><a onfocus='this.blur();' href='javascript:paginar(" + numPaginas + ");'>";
            cuerpo += "<img src='../../Images/Botones/last.png' onmouseover=\"javascript:cambiar_img(this, '../../Images/Botones/last_over.png');\" onmouseout=\"javascript:cambiar_img(this, '../../Images/Botones/last.png');\" />";
            cuerpo += "</a></li>";
        }
        else {
            // En la última página muestra un hueco vacío donde en lugar de los botones para el siguiente y el último
            cuerpo += "<li class='relleno_pag'>&nbsp;</li>";
        }
    }
    $("#paginador").html(cuerpo);
}

// Función a la que se llama cuando se pulsa algún enlace del paginador
function paginar(pag) {
    // Cargamos el listado según la página pedida
    cargarListado(pag, ordenAct, ordenDescAct, filtrosAct, false);
    // Cargamos el paginador
    cargarPaginador(pag, filtrosAct);
}

// Función a la que se llama cuando se pulsa alguna cabecera en la tabla
function ordenar(orden) {
    // Comprueba si estamos cambiando el orden
    if (orden == ordenAct) ordenDescAct = !ordenDescAct;
    else ordenDescAct = false;
    // Carga el listado para la página actual según el nuevo orden
    cargarListado(paginaAct, orden, ordenDescAct, filtrosAct, true);
    // Carga el paginador
    cargarPaginador(paginaAct, filtrosAct);
    ordenAct = orden;
}

// Función que muestra una flecha indicando la ordenación escogida junto a la cabecera 
function mostrarOrden(orden, ordenDescAct) {
    // Mostramos la columna por la que se está ordenando
    // Primero limpiamos las columnas
    var listaColumnas = $(".columna_tabla_listado");
    // Se recorren las columnas y se eliminan los indicadores de ordenación, si los hubiera
    for (var i = 0; i < listaColumnas.length; i++) {
        var contenidoColumna = listaColumnas[i].innerHTML;
        contenidoColumna = contenidoColumna.replace("&nbsp;↓", "");
        contenidoColumna = contenidoColumna.replace("&nbsp;↑", "");
        listaColumnas[i].innerHTML = contenidoColumna;
    }
    
    // Añadimos a la columna por la que estamos ordenando el indicador de ordenación
    if (ordenDescAct == false) {
        $("#columna_" + orden).html($("#columna_" + orden).html() + "&nbsp;↓");
    }
    else {
        $("#columna_" + orden).html($("#columna_" + orden).html() + "&nbsp;↑");
    }
}

// Carga la combo de subdepartamentos a partir de la opción escogida en la combo de departamentos
function cargarSubdepartamentos() {
    // Recupera el departamento seleccionado en la combo de departamentos
    var departamentoAct = $(".ddlDepartamentos option:selected").val();
    var datosUsuario;
    if (departamentoAct != 0) {
        // Si se ha escogido un departamento, se llama a la función ajax que recupera
        // los subdepartamentos de ese departamento
        $.ajax({
            // Los parámetros se van a pasar por psot
            type: "POST",
            // Método web que recibirá la llamada ajax
            url: "gestion_usuarios.aspx/obtenerSubdepartamentos",
            // Parámetro con el departamento seleccionado
            data: "{'idDepartamento':" + departamentoAct + "}",
            // Formato de la llamada (igual para todas las llamadas)
            contentType: "application/json; charset=utf-8",
            // Indica que los parámetros que se van a enviar están en formato json
            dataType: "json",
            success: function (msg) {
                // Recupera los datos enviados por el método web
                datosUsuario = msg.d;
                // Convierte los datos a un objeto javascript
                var userData = $.parseJSON(datosUsuario);
                // Comprueba si ha habido algún error
                if (userData[0] == false) {
                    // Carga la combo de subdepartamentos y la habilita
                    //$("#ddlSubdepartamentos").html(userData[1]);
                    var valores = "";
                    var listaValores = userData[1];
                    // Crea las opciones con los valores recibidos en la combo de subdepartamentos
                    for (var i = 0; i < listaValores.length; i++) {
                        valores += "<option value='" + listaValores[i][0] + "'>" + listaValores[i][1] + "</option>";
                    }
                    // Añade las opciones a la combo
                    $("#ddlSubdepartamentos").html(valores);
                    // Habilita la combo de departamentos
                    $("#ddlSubdepartamentos").removeAttr("disabled");
                }
                else {
                    // Muestra un mensaje de error indicando el fallo recibido
                    $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                }
            }
        });
    }
    else {
        // Si no se ha escogido ningún departamento se muestra la combo vacía y deshabilitada
        $("#ddlSubdepartamentos").html("<option value='0'>Seleccione un dep.</option>");
        $("#ddlSubdepartamentos").attr("disabled", "disabled");
    }
}

// Carga la combo de subdepartamentos del formulario según el departamento escogido
// marcando la opción elegida en caso de que la hubiera
function cargarSubdepartamentosF(defaultValue) {
    // Recupera el departamento seleccionado en la combo
    var departamentoAct = $(".ddlDepartamentosF option:selected").val();
    var datosUsuario;
    if (departamentoAct != 0) {
        // Realiza la llamada ajax
        $.ajax({
            type: "POST",
            url: "gestion_usuarios.aspx/obtenerSubdepartamentos",
            data: "{'idDepartamento':" + departamentoAct + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                datosUsuario = msg.d;
                var userData = $.parseJSON(datosUsuario);
                if (userData[0] == false) {
                    //$("#ddlSubdepartamentos").html(userData[1]);
                    var valores = "";
                    var listaValores = userData[1];
                    // Construye las opciones de la combo
                    for (var i = 0; i < listaValores.length; i++) {
                        valores += "<option value='" + listaValores[i][0] + "'>" + listaValores[i][1] + "</option>";
                    }
                    // Añade las opciones a la combo
                    $("#ddlSubdepartamentosF").html(valores);
                    // Habilita la combo
                    $("#ddlSubdepartamentosF").removeAttr("disabled");
                    // Selecciona el valor recibido en la combo de subdepartamentos
                    if (defaultValue != 0) {
                        $("#ddlSubdepartamentosF").val(defaultValue);
                    }
                }
                else {
                    // muestra al usuario el mensaje de error recibido
                    $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                }                              
            }
        });
    }
    else {
        $("#ddlSubdepartamentosF").html("<option value='0'>Seleccione un dep.</option>");
        $("#ddlSubdepartamentosF").attr("disabled", "disabled");
    }
}

// Realiza la búsqueda según los filtros escogidos
function filtrar() {
    // Recupera los valores del formulario de búsqueda
    var txtNombre = $("#txtNombre").val().replace("'", "´");
    var txtApellidos = $("#txtApellidos").val().replace("'", "´");
    var txtFechaNacimiento = $("#txtFechaNacimiento").val();
    var txtDNI = $("#txtDni").val().replace("'", "´");
    var blnActivo = $("#blnActivo").is(":checked");
    var ddlDepartamentos = $(".ddlDepartamentos option:selected").val();
    var ddlSubdepartamentos  = $("#ddlSubdepartamentos  option:selected").val();
    var rdSexo = $("#contenedor_busqueda input[name='sexo']:checked").val();

    // Construye el objeto json con los valores recuperados
    var arrayJson = "[";
    arrayJson += "'" + txtNombre + "',";
    arrayJson += "'" + txtApellidos + "',";
    arrayJson += "'" + txtFechaNacimiento + "',";
    arrayJson += "'" + txtDNI + "',";
    arrayJson += "'" + blnActivo + "',";
    arrayJson += "'" + ddlDepartamentos + "',";
    arrayJson += "'" + ddlSubdepartamentos  + "',";
    arrayJson += "'" + rdSexo + "']";

    // Carga el listado con los datos que cumplen los filtros
    cargarListado(1, "", false, arrayJson, false);
    // Carga el paginador 
    cargarPaginador(1, arrayJson);
    // Guarda los filtros para un posterior uso (si ordenamos, etc...)
    filtrosAct = arrayJson;
}

// Abre el formulario de introducción de datos con los campos vacíos
function nuevo() {
    // Limpia el formulario de datos anteriores
    resetearFormulario();
    $("#dialog-form img").attr("title", "");
    $("#dialog-form img").hide();
    $("#IdUsuarioF").val(0);
    $("#txtNombreF").val("");
    $("#txtApellidosF").val("");
    $("#txtFechaNacF").val("");
    $("#txtDNIF").val("");
    $(".ddlDepartamentosF").val(0);
    cargarSubdepartamentosF(0);
    $("#rdSexoHombre").attr("checked", "checked");
    // Abre el popup del formulario
    $("#dialog-form").dialog("open");
}

// Abre el formulario para mostrar los datos de la fila elegida en modo sólo lectura
function visualizar(idUsuario) {
    resetearFormulario();
    $("#dialog-view img").attr("title", "");
    $("#dialog-view img").hide();
    var datosUsuario;
    // Pide por ajax los datos del elemento actual a partir de su id
    $.ajax({
        type: "POST",
        url: "gestion_usuarios.aspx/obtenerDatosUsuario",
        data: "{'idUsuario':" + idUsuario + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            datosUsuario = msg.d;
            var userData = $.parseJSON(datosUsuario);
            if (userData[0] == false) {
                // Si la carga ha ido bien, muestra los datos recibidos en los controles
                $("#IdUsuarioV").val(userData[1].IdUsuario);
                $("#txtNombreV").val(userData[1].Nombre);
                $("#txtApellidosV").val(userData[1].Apellidos);
                var fechaNac = new Date(parseInt(userData[1].FechaNacimiento.substr(6)));
                $("#txtFechaNacV").val(("0" + fechaNac.getDate()).slice(-2) + "/" + ("0" + (fechaNac.getMonth() + 1)).slice(-2) + "/" + fechaNac.getFullYear());
                $("#txtDNIV").val(userData[1].Dni);
                if (userData[1].BlActivo == true) {
                    $("#txtActivoV").val("Sí");
                }
                else {
                    $("#txtActivoV").val("No");
                }
                $("#txtNombreDepartamentoV").val(userData[1].Departamento.Nombre);
                $("#txtNombreSubdepartamentoV").val(userData[1].Subdepartamento.Nombre);
                if (userData[1].Sexo == 'H') {
                    $("#txtSexoV").val("Hombre");
                }
                else {
                    $("#txtSexoV").val("Mujer");
                }
                $("#dialog-view").dialog("open");
            }
            else {
                // Si algo ha fallado muestra un mensaje de error
                $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                $("#dialog-msg").dialog("open");
                $("#dialog-msg .ui-dialog-titlebar-close").hide();
            }
        }
    });
}

// Abre el formulario con los datos del elemento cargados para su modificación
function modificar(idUsuario) {
    resetearFormulario();
    $("#dialog-form img").attr("title", "");
    $("#dialog-form img").hide();
    var datosUsuario;
    // Pide por ajax los datos del elemento actual a partir de su id
    $.ajax({
        type: "POST",
        url: "gestion_usuarios.aspx/obtenerDatosUsuario",
        data: "{'idUsuario':" + idUsuario + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            datosUsuario = msg.d;
            var userData = $.parseJSON(datosUsuario);
            if (userData[0] == false) {
                $("#IdUsuarioF").val(userData[1].IdUsuario);
                $("#txtNombreF").val(userData[1].Nombre);
                $("#txtApellidosF").val(userData[1].Apellidos);
                var fechaNac = new Date(parseInt(userData[1].FechaNacimiento.substr(6)));
                $("#txtFechaNacF").val(("0" + fechaNac.getDate()).slice(-2) + "/" + ("0" + (fechaNac.getMonth() + 1)).slice(-2) + "/" + fechaNac.getFullYear());
                $("#txtDNIF").val(userData[1].Dni);
                if (userData[1].BlActivo == true) $("#blnActivoF").attr("checked", "checked");
                $(".ddlDepartamentosF").val(userData[1].Departamento.IdDepartamento);
                cargarSubdepartamentosF(userData[1].Subdepartamento.IdDepartamento);
                if (userData[1].Sexo == 'H') $("#rdSexoHombre").attr("checked", "checked");
                else $("#rdSexoMujer").attr("checked", "checked");
                $("#dialog-form").dialog("open");
            }
            else {
                $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                $("#dialog-msg").dialog("open");
                $("#dialog-msg .ui-dialog-titlebar-close").hide();
             }
        }
    });
}

// Muestra un mensaje de confirmación al usuario para que verifique que quiere borrar el elemento
function borrar(idUsuario) {
    $("#idUsuarioBorrar").val(idUsuario);
    $("#dialog-confirm").dialog("open");
}

// Cancela el borrado
function cancelarBorrado() {
    $("#dialog-confirm").dialog("close");
}

// Borra el usuario elegido
function borrarUsuario() {
    var idUsuario = $("#idUsuarioBorrar").val();
    var datosUsuario;
    // Realiza la llamada por ajax para borrar el usuario
    $.ajax({
        type: "POST",
        url: "gestion_usuarios.aspx/borrarUsuario",
        data: "{'idUsuario':" + idUsuario + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            datosUsuario = msg.d;
            var userData = $.parseJSON(datosUsuario);
            if (userData[0] == false) {
                // Si la eliminación ha sido correcta, muestra al usuario el mensaje de confirmación
                $("#dialog-confirm").dialog("close");
                $("#dialog-msg #mensaje_usuario").html("El usuario ha sido eliminado correctamente de la aplicación.");
                $("#dialog-msg").dialog("open");
                $("#dialog-msg .ui-dialog-titlebar-close").hide();
                // Recarga el listado para reflejar el cambio realizado
                cargarListado(paginaAct, ordenAct, ordenDescAct, filtrosAct, false);
                cargarPaginador(paginaAct, filtrosAct);
            }
            else {
                if (userData[1].TipoMensaje == 4) {
                    $("#dialog-confirm").dialog("close");
                    $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                }
                else {
                    $("#dialog-confirm").dialog("close");
                    $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                    cargarListado(paginaAct, ordenAct, ordenDescAct, filtrosAct, false);
                    cargarPaginador(paginaAct, filtrosAct);
                }
            }
        }
    });
}

// Limpia el formulario para eliminar datos, mensajes de error, etc...
function resetearFormulario() {
    $("#txtNombreF").removeClass("inputerror");
    $("#txtNombreError").css("display", "none");

    $("#txtApellidosF").removeClass("inputerror");
    $("#txtApellidosError").css("display", "none");

    $("#txtFechaNacF").removeClass("inputerror");
    $("#txtFechaNacError").css("display", "none");

    $("#txtDNIF").removeClass("inputerror");
    $("#txtDNIError").css("display", "none");
    $("#txtDNIVal").css("display", "none");

    $(".ddlDepartamentosF").removeClass("inputerror");
    $("#ddlDepartamentosError").css("display", "none");

    $("#ddlSubdepartamentosF").removeClass("inputerror");
    $("#ddlSubdepartamentosError").css("display", "none"); 
}

// Función que configura los calendarios que se muestran en la aplicación
jQuery(function ($) {
    $.datepicker.regional['es'] = {
        closeText: 'Cerrar',
        prevText: '&#x3c;Ant',
        nextText: 'Sig&#x3e;',
        currentText: 'Hoy',
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
        dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi&eacute;rcoles', 'Jueves', 'Viernes', 'S&aacute;bado'],
        dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mi&eacute;', 'Juv', 'Vie', 'S&aacute;b'],
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'S&aacute;'],
        weekHeader: 'Sm',
        dateFormat: 'dd/mm/yy',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    $.datepicker.setDefaults($.datepicker.regional['es']);
});

// Valida que el DNI tenga el formato adecuado
function validarFormatoDNI(valor) {
    if (/^([0-9]{8})*[a-zA-Z]+$/.test(valor)) {
        var numero = valor.substr(0, valor.length - 1);
        var let = valor.substr(valor.length - 1, 1);
        numero = numero % 23;
        var letra = 'TRWAGMYFPDXBNJZSQVHLCKET';
        letra = letra.substring(numero, numero + 1);
        if (letra == let) return true;
        else return false;
    }
    else {
        return false;
    }
}

// Valida los datos introducidos en el formulario y muestra los mensajes de error adecuados
function validarUsuario() {
    var usuarioOK = true;

    // Valida que se ha rellenado el nombre del usuario
    if ($("#txtNombreF").val() == "") {
        $("#txtNombreF").addClass("inputerror");
        $("#txtNombreError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se han rellenado los apellidos del usuario
    if ($("#txtApellidosF").val() == "") {
        $("#txtApellidosF").addClass("inputerror");
        $("#txtApellidosError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se ha rellenado la fecha de nacimiento
    if ($("#txtFechaNacF").val() == "") {
        $("#txtFechaNacF").addClass("inputerror");
        $("#txtFechaNacError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se ha rellenado el DNI
    if ($("#txtDNIF").val() == "") {
        $("#txtDNIF").addClass("inputerror");
        $("#txtDNIError").css("display", "block"); 
        usuarioOK = false;
    }
    // Valida que la longitud del dni es correcta (8 números + 1 letra)
    else if ($("#txtDNIF").val().length != 9) {
        $("#txtDNIF").addClass("inputerror");
        $("#txtDNIVal").css("display", "block");
        usuarioOK = false;
    }
    // Valida que la letra del dni corresponde con el número
    else if (!validarFormatoDNI($("#txtDNIF").val())) {
        $("#txtDNIF").addClass("inputerror");
        $("#txtDNIVal").css("display", "block");  
        usuarioOK = false;
    }    

    //  Valida que se ha seleccionado un departamento
    if ($(".ddlDepartamentosF option:selected").val() == "0") {
        $(".ddlDepartamentosF").addClass("inputerror");
        $("#ddlDepartamentosError").css("display", "block");    
        usuarioOK = false;
    }

    // Valida que se ha seleccionado un subdepartamento
    if ($("#ddlSubdepartamentosF option:selected").val() == "0") {
        $("#ddlSubdepartamentosF").addClass("inputerror");
        $("#ddlSubdepartamentosError").css("display", "block");       
        usuarioOK = false;
    }

    return usuarioOK;
}

// Guarda los datos introducidos en el formulario, pasando el id del elemento en caso de que sea una modificación
// y un id vacío en caso de que sea nuevo
function guardar() {
    $("#dialog-form img").attr("title", "");
    $("#dialog-form img").hide();

    // Antes de guardar valida los datos
    if (validarUsuario()) {
        // Construye el objeto json con los datos del formulario
        var parametros = [];
        parametros.push("'idUsuario':" + $("#IdUsuarioF").val());
        parametros.push("'nombre':'" + $("#txtNombreF").val().replace("'", "´") + "'");
        parametros.push("'apellidos':'" + $("#txtApellidosF").val().replace("'", "´") + "'");
        parametros.push("'fechaNacimiento':'" + $("#txtFechaNacF").val() + "'");
        parametros.push("'Dni':'" + $("#txtDNIF").val().replace("'", "´") + "'");
        parametros.push("'blActivo':" + ($("#blnActivoF").is(":checked")));
        parametros.push("'idDepartamento':" + $(".ddlDepartamentosF option:selected").val());
        parametros.push("'idSubdepartamento':" + $("#ddlSubdepartamentosF option:selected").val());
        if ($("#rdSexoHombre").is(":checked")) parametros.push("'sexo':'H'");
        else parametros.push("'sexo':'M'");
        // Convierte el array de parámetros en una línea de la forma { 'param1' : 'valor1', 'param2' : 'valor2', ... }
        var params = '{' + parametros.join(',') + '}';
        var datosUsuario;
        $.ajax({
            type: "POST",
            url: "gestion_usuarios.aspx/guardarUsuario",
            data: params,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                datosUsuario = msg.d;
                var userData = $.parseJSON(datosUsuario);
                if (userData[0] == false) {
                    $("#dialog-form").dialog("close");
                    $("#dialog-msg #mensaje_usuario").html("El usuario ha sido guardado correctamente");
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                    cargarListado(paginaAct, ordenAct, ordenDescAct, filtrosAct, false);
                    cargarPaginador(paginaAct, filtrosAct);
                }
                else {
                    if (userData[1].TipoMensaje == 4) {                        
                        $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                        $("#dialog-msg").dialog("open");
                        $("#dialog-msg .ui-dialog-titlebar-close").hide();
                    }
                    else {
                        $("#dialog-form").dialog("close");
                        $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                        $("#dialog-msg").dialog("open");
                        $("#dialog-msg .ui-dialog-titlebar-close").hide();
                        cargarListado(paginaAct, ordenAct, ordenDescAct, filtrosAct, false);
                        cargarPaginador(paginaAct, filtrosAct);
                    }
                }
            }
        });
    }
}

// Ajusta la altura del cuerpo de la aplicación según el tamaño de la ventana
function ajustarAltura() {
    var alturaPie = $("#pie").position().top;
    var alturaCabecera = $("#cabecera").height();
    var alturaCuerpo = $("#boton_nuevo").position().top;
    if (alturaPie > alturaCabecera + alturaCuerpo) {
        $("#cuerpo").height(alturaPie - alturaCabecera);
    }
}

// Muestra u oculta elementos según el nivel de permisos
function perfilFuncion() {
    var perfilFuncion = $("#lblPerfilFuncion").html();

    if (perfilFuncion == "L") {
        $(".Permisos").css("display", "none");
        $(".NoPermisos").css("display", "block");
    }
}

// Configuraciones básicas de la aplicación
$(document).ready(function () {
    // Pone los calendarios en español
    $.datepicker.setDefaults($.datepicker.regional["es"]);

    // Indica que el campo es un calendario
    $("#txtFechaNacimiento").datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: '-100Y',
        maxDate: 0,
        yearRange: '-100:+0'
    });

    // Indica que el campo es un calendario
    $("#txtFechaNacF").datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: '-100Y',
        maxDate: 0
    });

    // Indica que el div es un formulario de alta/modificación
    $("#dialog-form").dialog({
        autoOpen: false,
        height: 370,
        width: 410,
        modal: true,
        resizable: false
    });

    // Indica que el div es un formulario de consulta
    $("#dialog-view").dialog({
        autoOpen: false,
        height: 350,
        width: 410,
        modal: true,
        resizable: false
    });

    // Indica que el div es un diálogo de confirmación
    $("#dialog-confirm").dialog({
        autoOpen: false,
        height: 100,
        width: 300,
        modal: true,
        resizable: false
    });

    // Indica que el div es un diálogo de mensaje al usuario
    $("#dialog-msg").dialog({
        autoOpen: false,
        height: 120,
        width: 350,
        modal: true,
        resizable: false
    });

    // Carga el listado con los valores por defecto
    cargarListado(1, ordenAct, ordenDescAct, filtrosAct, false);

    // Carga el paginador
    cargarPaginador(1, filtrosAct);

    // Comprueba el nivel de permisos del usuario
    perfilFuncion();

    // Pone por defecto el radio button del sexo a "todos"
    $("#rdTodosBusq").attr("checked", "checked");

    // Asigna un evento a la función de redimensionado de la ventana para que cuando se redimensione los controles se ajusten
    $(window).resize(function () {
        ajustarAltura();
    });

    // Ajusta los controles al tamaño actual
    ajustarAltura();

    // Reajusta la página si no se ve el menú de la izquierda
    if ($("#menu_izq").html().length == 0) {
        $("#menu_izq").hide();
        $("#contenido").css("width", "970px");
        $("#cabecera_busqueda").css("width", "970px");
        $("#contenedor_busqueda table").css("margin-left", "75px");
        $("#contenedor_tabla_listado").css("width", "970px");
        $("#contenedor_tabla_listado").css("overflow", "auto");
    }

    // Oculta las líneas punteadas en los enlaces
    $("a").focus(function () { this.blur() });

});

// Cambia la imagen asociada a un elemento
function cambiar_img(elemento, img) {
    elemento.src = img;
}

// Muestra los mensajes de error al usuario
function mostrarMensajes(mensajes) {

    $("#dialog-msg #mensaje_usuario").html(mensajes);
    $("#dialog-msg").dialog("open");
    $("#dialog-msg .ui-dialog-titlebar-close").hide();
    
}
