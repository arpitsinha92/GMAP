﻿//estado de los controles en la primera carga de la página
function estadoCargaInicial() {
    $(document).ready(function () {
        /*******CESIONES********/
        //Fieldset de cesiones
        $("#MainContent_btnEmpleado").attr('disabled', true);
        $("#MainContent_btnDepartamento").attr('disabled', true);        
    });    
}


function popupPersonas(w, h) {
    var datos = new Array();
    datos = window.showModalDialog('BusquedaPersonas.aspx', '', 'dialogHeight:' + h + ' px;dialogWidth:' + w + ' px;center:Yes;help:No;resizable: No;status:No;');
    if (datos != null) {
        if (datos[0] == 'true') //Hay datos de respuesta
        {
            document.getElementById('MainContent_txtEmpleado').innerText = datos[1];
            document.getElementById('MainContent_hOidDestCesion').value = datos[2];
        }
    }
    return false;
}

function popupDepartamentos(w, h) {
    var datos = new Array();
    datos = window.showModalDialog('BusquedaDepartamentos.aspx', '', 'dialogHeight:' + h + ' px;dialogWidth:' + w + ' px;center:Yes;help:No;resizable: No;status:No;');
    if (datos != null) {
        if (datos[0] == 'true') //Hay datos de respuesta
        {
            document.getElementById('MainContent_txtDepartamento').innerText = datos[1];
            document.getElementById('MainContent_hOidDestCesion').value = datos[2];
        }
    }
    return false;
}

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOne(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    var inputs = grid.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}