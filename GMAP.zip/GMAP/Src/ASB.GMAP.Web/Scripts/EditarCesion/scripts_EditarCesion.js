﻿function popupPersonas(w, h) {
    var datos = new Array();
    datos = window.showModalDialog('BusquedaPersonas.aspx?soloInternos=true', '', 'dialogHeight:' + h + ' px;dialogWidth:' + w + ' px;center:Yes;help:No;resizable: No;status:No;');
    if (datos != null) {
        if (datos[0] == 'true') //Hay datos de respuesta
        {
            document.getElementById('MainContent_txtRespProrroga').innerText = datos[1];
            document.getElementById('MainContent_hRespProrroga').value = datos[2];
        }
    }
    return false;
}

function cerrarPopUp() {
    window.close();
}