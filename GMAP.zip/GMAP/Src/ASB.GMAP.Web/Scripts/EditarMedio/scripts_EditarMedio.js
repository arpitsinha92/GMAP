﻿var datos = new Array();

function trasladarValores(nombreApellidos, codEmp) {
    datos[0] = 'true';
    datos[1] = nombreApellidos;
    datos[2] = codEmp;
    window.returnValue = datos;
    window.close();
}

function cerrarPopUp(valor) {
    datos[0] = valor
    window.returnValue = datos;
    window.close();
}