﻿//estado de los controles en la primera carga de la página
function estadoCargaInicial() {
    $(document).ready(function () {
        /*******MARCAS********/
        //Fieldset de mantenimeinto
        $("#mntMarcas").attr('disabled', true);
        $("#MainContent_btnGuardarMarca").attr('disabled', true);
        $("#MainContent_btnCancelarMarca").attr('disabled', true);
        $("#MainContent_txtMarca").val('');
        $("#MainContent_txtMarca").attr('readOnly', true);
        $("#MainContent_txtMarca").prop('disabled', true);
        $("#MainContent_txtFecBajaMarca").val('');
        $("#MainContent_txtFecBajaMarca").attr('readOnly', true);
        $("#MainContent_txtFecBajaMarca").prop('disabled', true);        
        //Fieldset de búsqueda
        $("#divGridMarcas").attr('disabled', false);
        $("#MainContent_btnNuevoMarca").attr('disabled', false);
        $("#MainContent_btnModificarMarca").attr('disabled', false);
        $("#MainContent_btnEliminarMarca").attr('disabled', false);

        /*******MODELOS********/
        //Fieldset de mantenimeinto
        $("#mntModelos").attr('disabled', true);
        $("#MainContent_btnGuardarModelo").attr('disabled', true);
        $("#MainContent_btnCancelarModelo").attr('disabled', true);
        $("#MainContent_cboMarcaEdicion").attr('disabled', true);        
        $("#MainContent_txtModelo").val('');
        $("#MainContent_txtModelo").attr('readOnly', true);
        $("#MainContent_txtModelo").prop('disabled', true);
        $("#MainContent_txtModeloDesc").val('');
        $("#MainContent_txtModeloDesc").attr('readOnly', true);
        $("#MainContent_txtModeloDesc").prop('disabled', true);
        $("#MainContent_txtFecBajaModelo").prop('disabled', true);

        //Fieldset de búsqueda
        $("#divGridModelos").attr('disabled', false);
        $("#MainContent_btnNuevoModelo").attr('disabled', false);
        $("#MainContent_btnModificarModelo").attr('disabled', false);
        $("#MainContent_btnEliminarModelo").attr('disabled', false);
    });
}

//Habilitamos el fieldset de mantenimiento y deshabilitar el de búsqueda
function habilitarMantenimientoMarcas() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#mntMarcas").attr('disabled', false);
        $("#MainContent_btnGuardarMarca").attr('disabled', false);
        $("#MainContent_btnCancelarMarca").attr('disabled', false);
        $("#MainContent_txtMarca").removeAttr('readonly');
        $("#MainContent_txtMarca").prop('disabled', false);
        $("#MainContent_txtMarca").focus();
        $("#MainContent_txtFecBajaMarca").removeAttr('readonly');
        $("#MainContent_txtFecBajaMarca").prop('disabled', false);

        //ValidatorCalloutEnable($("#MainContent_valNombre_ValidatorCalloutExtender"), true)
        
        //Fieldset de búsqueda
        $("#MainContent_btnNuevoMarca").attr('disabled', true);
        $("#MainContent_btnModificarMarca").attr('disabled', true);
        $("#MainContent_btnEliminarMarca").attr('disabled', true);
        $("#MainContent_grdMarcas").attr('disabled', true);
    });
    desHabilitarModelos();    
    
}

//Habilitamos el fieldset de mantenimiento y deshabilitar el de búsqueda
function habilitarMantenimientoModelos() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#mntModelos").attr('disabled', false);
        $("#MainContent_btnGuardarModelo").attr('disabled', false);
        $("#MainContent_btnCancelarModelo").attr('disabled', false);
        $("#MainContent_txtModelo").removeAttr('readonly');
        $("#MainContent_txtModelo").prop('disabled', false);
        $("#MainContent_txtModelo").focus();
        $("#MainContent_txtModeloDesc").removeAttr('readonly');
        $("#MainContent_txtModeloDesc").prop('disabled', false);
        $("#MainContent_txtFecBajaModelo").removeAttr('readonly');
        $("#MainContent_txtFecBajaModelo").prop('disabled', false);
        $("#MainContent_ddlMarcaEdicion option[value='']").remove();

        //Fieldset de búsqueda
        $("#MainContent_btnNuevoModelo").attr('disabled', true);
        $("#MainContent_btnModificarModelo").attr('disabled', true);
        $("#MainContent_btnEliminarModelo").attr('disabled', true);
        $("#MainContent_grdModelos").attr('disabled', true);
        $("#MainContent_ddlMarca").attr('disabled', true);
        
    });
    desHabilitarMarcas();
}

//Deshabilitamos el fieldset de mantenimiento y habilitar el de búsqueda
function desHabilitarMantenimientoMarcas() {
    //if (guardarCancelarMarca()) {
        $(document).ready(function () {
            //Fieldset de mantenimeinto
            $("#mntMarcas").attr('disabled', true);
            $("#MainContent_btnGuardarMarca").attr('disabled', true);
            $("#MainContent_btnCancelarMarca").attr('disabled', true);
            $("#MainContent_txtMarca").val('');
            $("#MainContent_txtMarca").attr('readOnly', true);
            $("#MainContent_txtMarca").attr('disabled', true);
            $("#MainContent_txtFecBajaMarca").val('');
            $("#MainContent_txtFecBajaMarca").attr('readOnly', true);
            $("#MainContent_txtFecBajaMarca").prop('disabled', true);

//            if (Sys.Extended.UI.ValidatorCalloutBehavior._currentCallout != null)
            //                Sys.Extended.UI.ValidatorCalloutBehavior._currentCallout.dispose(); 

            //ValidatorCalloutEnable($("#MainContent_valNombre_ValidatorCalloutExtender"), false)

            //Fieldset de búsqueda
            $("#busqMarcas").attr('disabled', false);
            $("#MainContent_btnNuevoMarca").attr('disabled', false);
            $("#MainContent_btnNuevoMarca").focus();
            $("#MainContent_btnModificarMarca").attr('disabled', false);
            $("#MainContent_btnEliminarMarca").attr('disabled', false);
            $("#MainContent_grdMarcas").attr('disabled', false);
        });
        habilitarModelos();
        //}
}

//Deshabilitamos el fieldset de mantenimiento y habilitar el de búsqueda
function desHabilitarMantenimientoModelos() {
    //if (guardarCancelarModelo()) {
        $(document).ready(function () {
            //Fieldset de mantenimeinto
            $("#mntModelos").attr('disabled', true);
            $("#MainContent_btnGuardarModelo").attr('disabled', true);
            $("#MainContent_btnCancelarModelo").attr('disabled', true);
            $("#MainContent_txtModelo").attr('readonly', true);
            $("#MainContent_txtModelo").val('');
            $("#MainContent_txtModelo").prop('disabled', true);
            $("#MainContent_txtModeloDesc").attr('readonly', true);
            $("#MainContent_txtModeloDesc").val('');
            $("#MainContent_txtModeloDesc").prop('disabled', true);
            $("#MainContent_txtFecBajaModelo").attr('readonly', true);
            $("#MainContent_txtFecBajaModelo").val('');
            $("#MainContent_txtFecBajaModelo").prop('disabled', true);
//            if (Sys.Extended.UI.ValidatorCalloutBehavior._currentCallout != null)
//                Sys.Extended.UI.ValidatorCalloutBehavior._currentCallout.hide(); 

            //Fieldset de búsqueda
            $("#busqModelos").attr('disabled', false);
            $("#MainContent_btnNuevoModelo").attr('disabled', false);
            $("#MainContent_btnNuevoModelo").focus();
            $("#MainContent_btnModificarModelo").attr('disabled', false);            
            $("#MainContent_btnEliminarModelo").attr('disabled', false);
            $("#MainContent_grdModelos").attr('disabled', false);
            $("#MainContent_ddlMarca").attr('disabled', false);
        });
        habilitarMarcas();
    //}
}

//Deshabilitamos el fieldset de mantenimiento y habilitar el de búsqueda
function desHabilitarMarcas() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#mntMarcas").attr('disabled', true);
        $("#MainContent_btnGuardarMarca").attr('disabled', true);
        $("#MainContent_btnCancelarMarca").attr('disabled', true);
        $("#MainContent_txtMarca").val('');
        $("#MainContent_txtMarca").attr('readOnly', true);
        $("#MainContent_txtMarca").prop('disabled', true)
        $("#MainContent_txtFecBajaMarca").val('');
        $("#MainContent_txtFecBajaMarca").attr('readOnly', true);
        $("#MainContent_txtFecBajaMarca").prop('disabled', true);

        //Fieldset de búsqueda
        $("#MainContent_btnNuevoMarca").attr('disabled', true);
        $("#MainContent_btnModificarMarca").attr('disabled', true);
        $("#MainContent_btnEliminarMarca").attr('disabled', true);
        $("#busqMarcas").attr('disabled', true);
    });
}
//Deshabilitamos el fieldset de mantenimiento y habilitar el de búsqueda
function habilitarMarcas() {
    $(document).ready(function () {
        $("#busqMarcas").attr('disabled', false);
        $("#MainContent_btnNuevoMarca").attr('disabled', false);
        $("#MainContent_btnModificarMarca").attr('disabled', false);
        $("#MainContent_btnEliminarMarca").attr('disabled', false);
    });    
}

function desHabilitarModelos() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#MainContent_btnGuardarModelo").attr('disabled', true);
        $("#MainContent_btnCancelarModelo").attr('disabled', true);
        $("#MainContent_txtModelo").attr('readonly', true);
        $("#MainContent_txtModelo").val('');
        $("#MainContent_txtModelo").prop('disabled', true);
        $("#MainContent_txtModeloDesc").attr('readonly', true);
        $("#MainContent_txtModeloDesc").prop('disabled', true);
        $("#MainContent_txtModeloDesc").val('');
        $("#MainContent_txtFecBajaModelo").attr('readonly', true);
        $("#MainContent_txtFecBajaModelo").val('');
        $("#MainContent_txtFecBajaModelo").prop('disabled', true);
        

        //Fieldset de búsqueda        
        $("#MainContent_btnNuevoModelo").attr('disabled', true);
        $("#MainContent_btnModificarModelo").attr('disabled', true);
        $("#MainContent_btnEliminarModelo").attr('disabled', true);
        $("#busqModelos").attr('disabled', true);
        $("#MainContent_ddlMarca").attr('disabled', true);
    });
}

//Deshabilitamos el fieldset de mantenimiento y habilitar el de búsqueda
function habilitarModelos() {
    $(document).ready(function () {
        $("#busqModelos").attr('disabled', false);
        $("#MainContent_btnNuevoModelo").attr('disabled', false);
        $("#MainContent_btnModificarModelo").attr('disabled', false);
        $("#MainContent_btnEliminarModelo").attr('disabled', false);
        $("#MainContent_ddlMarca").attr('disabled', false);
    });    
}


//añadimos al value del campo hidden el oidMarca sobre el que se va a realizar una modificación
// Si al campo hidden le pasamos valor vacio será para realizar una inserción de un tipo nuevo
function establecerAccionMarcas(oidMarca) {
    $(document).ready(function () {

        $("#MainContent_hOidMarca").val(oidMarca);
    });
}

//añadimos al value del campo hidden el oidModelo sobre el que se va a realizar una modificación
// Si al campo hidden le pasamos valor vacio será para realizar una inserción de un tipo nuevo
function establecerAccionModelos(oidModelo) {
    $(document).ready(function () {

        $("#MainContent_hOidModelo").val(oidModelo);
    });
}

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOneMarca(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    document.getElementById('MainContent_btnModificarMarca').focus();
    var inputs = grid.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOneModelo(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    document.getElementById('MainContent_btnModificarModelo').focus();
    var inputs = grid.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}

function grdMarcasDisable() {
    $(document).ready(function () {
        $("#MainContent_grdMarcas").attr('disabled', true);
    });
}

function grdDdlModelosDisable() {
    $(document).ready(function () {
        $("#MainContent_grdModelos").attr('disabled', true);
        $("#MainContent_ddlMarca").attr('disabled', true);
    });
}

function btnEliminarMarcaDisable() {
    $(document).ready(function () {
        $("#MainContent_btnEliminarMarca").attr('disabled', true);
    });
}

function btnEliminarModeloDisable() {
    $(document).ready(function () {
        $("#MainContent_btnEliminarModelo").attr('disabled', true);
    });
}

function eliminarModelo() {
    var valid = false;
    $(document).ready(function () {

        if ($("#busqModelos").is(':disabled') == true)
            valid = false;
        else
            valid = true;
    });
    return valid;
}

function eliminarMarca() {
    var valid = false;
    $(document).ready(function () {

        if ($("#busqMarcas").is(':disabled') == true)
            valid = false;
        else
            valid = true;
    });
    return valid;
}

function guardarCancelarModelo() {
    var valid = false;
    $(document).ready(function () {

        if ($("#mntModelos").is(':disabled') == true)
            valid = false;
        else
            valid = true;
    });
    return valid;
}

function guardarCancelarMarca() {
    var valid = false;
    $(document).ready(function () {

        if ($("#mntMarcas").is(':disabled') == true)
            valid = false;
        else
            valid = true;
    });
    return valid;
}

function focoEnNuevoModelo() {
    $(document).ready(function () {
        if ($("#MainContent_btnNuevoModelo").is(':disabled') == false)
            $("#MainContent_btnNuevoModelo").focus();
        else
            $("#MainContent_txtModelo").focus();
    });
}

function focoEnNuevaMarca() {
    $(document).ready(function () {
        if ($("#MainContent_btnNuevoMarca").is(':disabled') == false)
            $("#MainContent_btnNuevoMarca").focus();
        else
            $("#MainContent_txtMarca").focus();
    });
}
function ocultarValidadorMarcas() {
    $("#MainContent_valNombre_ValidatorCalloutExtender_popupTable").hide();
}

function MostrarValidadorMarcas() {
    $("#MainContent_valNombre_ValidatorCalloutExtender_popupTable").show();
}



//function ValidatorCalloutEnable(validatorExtCallout, enable) {
//    if (enable) {
//        if (validatorExtCallout != null) {
//            if (!validatorExtCallout._focusAttached) {
//                $addHandler(validatorExtCallout._elementToValidate, "focus", validatorExtCallout._focusHandler);
//                validatorExtCallout._focusAttached = true;
//            }
//        }
//    }
//    else {
//        if (validatorExtCallout._focusAttached) {
//            $removeHandler(validatorExtCallout._elementToValidate, "focus", validatorExtCallout._focusHandler);
//            validatorExtCallout._focusAttached = false;
//        }
//    }
//}
