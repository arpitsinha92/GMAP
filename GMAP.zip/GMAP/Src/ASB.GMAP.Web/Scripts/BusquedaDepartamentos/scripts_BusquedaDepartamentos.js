﻿var datos = new Array();

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOne(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    var inputs = grid.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}

function trasladarValores(nombreDept, codDept) {
    datos[0] = 'true'
    datos[1] = nombreDept;
    datos[2] = codDept;
    window.returnValue = datos;
    window.close();
}

function cerrarPopUp() {
    datos[0] = 'false'
    window.returnValue = datos;
    window.close();
}