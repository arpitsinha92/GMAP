﻿//estado de los controles en la primera carga de la página
function estadoCargaInicial() {
    $(document).ready(function () {
        /*******CESIONES********/
        //Fieldset de cesiones
        $("#MainContent_btnEmpleado").attr('disabled', true);
        $("#MainContent_btnDepartamento").attr('disabled', true);
        $("#MainContent_txtFecIniCesion").val('');
        $("#MainContent_txtFecIniCesion").attr('readOnly', true);
        $("#MainContent_txtComentarios").val('');
        $("#MainContent_txtComentarios").attr('readOnly', true);
        $("#MainContent_txtEmpleado").val('');
        $("#MainContent_txtEmpleado").attr('readOnly', true);        
    });    
}

function chkCesionPulsado(chk) {
    if (chk.value == '0') {
        //Si se ha seleccionado que el medio no se cede
        $("#MainContent_btnEmpleado").attr('disabled', true);
        $("#MainContent_txtEmpleado").val('');
        $("#MainContent_txtEmpleado").attr('readOnly', true);
        $("#MainContent_btnDepartamento").attr('disabled', true);
        $("#MainContent_txtDepartamento").val('');
        $("#MainContent_txtDepartamento").attr('readOnly', true);        
        $("#MainContent_txtFecIniCesion").val('');
        $("#MainContent_txtFecIniCesion").attr('readOnly', true);
        $("#MainContent_txtComentarios").val('');
        $("#MainContent_txtComentarios").attr('readOnly', true);
        $("#MainContent_hOidDestCesion").val('');
        //deshabilitamos lo validadores
        ValidatorEnable($("#MainContent_valFecIniCesion"), false);
        ValidatorEnable($("#MainContent_valEmpleado"), false);
        ValidatorEnable($("#MainContent_valDepartamento"), false);
    }
    else {
        if (chk.value == '1') {
            //Si se ha seleccionado que el medio se cede a un empleado
            $("#MainContent_btnEmpleado").attr('disabled', false);
            $("#MainContent_btnDepartamento").attr('disabled', true);
            $("#MainContent_txtDepartamento").val('');
            $("#MainContent_txtDepartamento").attr('readOnly', true);
            //habilitamos lo validadores              
            ValidatorEnable($("#MainContent_valFecIniCesion"), true);
            ValidatorEnable($("#MainContent_valEmpleado"), true);
        }
        else {
            //Si se ha seleccionado que el medio se cede a un departamento
            $("#MainContent_btnEmpleado").attr('disabled', true);
            $("#MainContent_btnDepartamento").attr('disabled', false);
            $("#MainContent_txtEmpleado").val('');
            $("#MainContent_txtEmpleado").attr('readOnly', true);
            //habilitamos lo validadores              
            ValidatorEnable($("#MainContent_valFecIniCesion"), true);
            ValidatorEnable($("#MainContent_valDepartamento"), true);
        }
        $("#MainContent_txtFecIniCesion").removeAttr('readonly');
        $("#MainContent_txtComentarios").removeAttr('readonly');
    }
    $("#MainContent_hOidDestCesion").val('');    
}        


function popupPersonas(w, h) {
    var datos = new Array();
    datos = window.showModalDialog('BusquedaPersonas.aspx', '', 'dialogHeight:' + h + ' px;dialogWidth:' + w + ' px;center:Yes;help:No;resizable: No;status:No;');
    if (datos != null) {
        if (datos[0] == 'true') //Hay datos de respuesta
        {
            document.getElementById('MainContent_txtEmpleado').innerText = datos[1];
            document.getElementById('MainContent_hOidDestCesion').value = datos[2];
        }
    }
    return false;
}

function popupDepartamentos(w, h) {
    var datos = new Array();
    datos = window.showModalDialog('BusquedaDepartamentos.aspx', '', 'dialogHeight:' + h + ' px;dialogWidth:' + w + ' px;center:Yes;help:No;resizable: No;status:No;');
    if (datos != null) {
        if (datos[0] == 'true') //Hay datos de respuesta
        {
            document.getElementById('MainContent_txtDepartamento').innerText = datos[1];
            document.getElementById('MainContent_hOidDestCesion').value = datos[2];
        }
    }
    return false;
}

