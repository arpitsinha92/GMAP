﻿$(document).ready(function () {
    if ($("#chkTodos").is(":checked")) {
        $("#gvMedios").find("input:checkbox").each(function () {
            $(this).attr("disabled", true);
        });
    }

    // Si marcamos el checkbox "Todos" deshabilitamos gridview
    $("#chkTodos").change(function () {
        if ($("#chkTodos").is(":checked")) {
            $("#gvMedios").find("input:checkbox").each(function () {
                $(this).attr("disabled", true);
            });
        } else {
            $("#gvMedios").find("input:checkbox").each(function () {
                $(this).removeAttr("disabled");
            });
        }
    });
});

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOne(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    var inputs = grid.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}