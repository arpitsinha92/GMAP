﻿//desHabilitamos el fieldset de mantenimiento y habilitar el de búsqueda
function desHabilitarMantenimiento() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#mnt").attr('disabled', true);
        $("#MainContent_btnGuardar").attr('disabled', true);
        $("#MainContent_btnCancelar").attr('disabled', true);
        $("#MainContent_ddlCentroCoste").attr('disabled', true);
        $("#MainContent_ddlCentroCoste").prop('selectedIndex', 0);
        $("#MainContent_txtFecBaja").val('');
        $("#MainContent_txtFecBaja").attr('readOnly', true);
        $("#MainContent_txtFecBaja").prop('disabled', true);
        $("#MainContent_txtDescripcion").val('');
        $("#MainContent_txtDescripcion").attr('readOnly', true);
        $("#MainContent_txtDescripcion").prop('disabled', true);
        $("#MainContent_txtNombre").val('');
        $("#MainContent_txtNombre").attr('readOnly', true);
        $("#MainContent_txtNombre").prop('disabled', true);
        $("#MainContent_chkEntregable").attr('checked', false);
        $("#MainContent_chkMarcaModelo").attr('checked', false);
        $("#MainContent_chkExtension").attr('checked', false);
        //Fieldset de búsqueda
        $("#busq").attr('disabled', false);
        $("#MainContent_txtBusqueda").removeAttr('readonly');
        $("#MainContent_txtBusqueda").prop('disabled', false);
        $("#MainContent_btnBuscar").attr('disabled', false);
        $("#MainContent_btnNuevo").attr('disabled', false);
        $("#MainContent_btnNuevo").focus();
        $("#MainContent_btnModificar").attr('disabled', false);
        $("#MainContent_btnEliminar").attr('disabled', false);
    });
}

//estado de los controles en la primera carga de la página
function estadoCargaInicial() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#mnt").attr('disabled', true);
        $("#MainContent_btnGuardar").attr('disabled', true);
        $("#MainContent_btnCancelar").attr('disabled', true);
        $("#MainContent_ddlCentroCoste").attr('disabled', true);
        $("#MainContent_txtFecBaja").val('');
        $("#MainContent_txtFecBaja").attr('readOnly', true);
        $("#MainContent_txtFecBaja").prop('disabled', true);
        $("#MainContent_txtDescripcion").val('');
        $("#MainContent_txtDescripcion").attr('readOnly', true);
        $("#MainContent_txtDescripcion").prop('disabled', true);
        $("#MainContent_txtNombre").val('');
        $("#MainContent_txtNombre").attr('readOnly', true);
        $("#MainContent_txtNombre").prop('disabled', true);
        $("#MainContent_chkEntregable").attr('checked', false);
        $("#MainContent_chkMarcaModelo").attr('checked', false);
        $("#MainContent_chkExtension").attr('checked', false);
    });
}

//Habilitamos el fieldset de mantenimiento y deshabilitar el de búsqueda
function habilitarMantenimiento() {
    $(document).ready(function () {
        //Fieldset de mantenimeinto
        $("#mnt").attr('disabled', false);
        $("#MainContent_btnGuardar").attr('disabled', false);
        $("#MainContent_btnCancelar").attr('disabled', false);
        $("#MainContent_ddlCentroCoste").attr('disabled', false);
        $("#MainContent_txtFecBaja").removeAttr('readonly');
        $("#MainContent_txtFecBaja").prop('disabled', false);
        $("#MainContent_txtDescripcion").removeAttr('readonly');
        $("#MainContent_txtDescripcion").prop('disabled', false);
        $("#MainContent_txtNombre").removeAttr('readonly');
        $("#MainContent_txtNombre").prop('disabled', false);
        $("#MainContent_txtNombre").focus();
        
        //Fieldset de búsqueda
        $("#busq").attr('disabled', true);
        $("#MainContent_btnBuscar").attr('disabled', true);
        $("#MainContent_btnNuevo").attr('disabled', true);
        $("#MainContent_btnModificar").attr('disabled', true);
        $("#MainContent_btnEliminar").attr('disabled', true);
        $("#MainContent_txtBusqueda").attr('readOnly', true);
        $("#MainContent_txtBusqueda").prop('disabled', true);
    });    
}

//añadimos al value del campo hidden el oidTipoMedio sobre el que se va a realizar una modificación
// Si al campo hidden le pasamos valor vacio será para realizar una inserción de un tipo nuevo
function establecerAccion(oidTipoMedio) {
    $(document).ready(function () {

        $("#MainContent_hOidTipoMedio").val(oidTipoMedio);
    });
}

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOne(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    var inputs = grid.getElementsByTagName("input");
    document.getElementById('MainContent_btnModificar').focus();
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}




