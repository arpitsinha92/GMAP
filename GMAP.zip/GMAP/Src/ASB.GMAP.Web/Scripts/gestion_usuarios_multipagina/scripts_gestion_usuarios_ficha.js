﻿/// Carga la combo de subdepartamentos del formulario según el departamento escogido
// marcando la opción elegida en caso de que la hubiera
function cargarSubdepartamentos(defaultValue) {
    // Recupera el departamento seleccionado en la combo
    var departamentoAct = $(".ddlDepartamentos option:selected").val();
    var datosUsuario;
    if (departamentoAct != 0) {
        // Si se ha seleccionado un departamento, realiza la llamada ajax para recuperar sus subdepartamentos
        $.ajax({
            type: "POST",
            // Indica el método web que recuperará los subdepartamentos
            url: "gestion_usuarios_ficha.aspx/obtenerSubdepartamentos",
            // Envía el parámetro con el id del departamento seleccionado
            data: "{'idDepartamento':" + departamentoAct + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                datosUsuario = msg.d;
                var userData = $.parseJSON(datosUsuario);
                if (userData[0] == false) {
                    //$("#ddlSubdepartamentos").html(userData[1]);
                    var valores = "";
                    var listaValores = userData[1];
                    // Construye las opciones de la combo
                    for (var i = 0; i < listaValores.length; i++) {
                        valores += "<option value='" + listaValores[i][0] + "'>" + listaValores[i][1] + "</option>";
                    }
                    // Carga las opciones en la combo
                    $(".ddlSubdepartamentos").html(valores);
                    $(".ddlSubdepartamentos").removeAttr("disabled");
                    if (defaultValue != 0) {
                        $(".ddlSubdepartamentos").val(defaultValue);
                    }
                }
                else {
                    // Si ha habido algún error, lo muestra al usuario
                    $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                }
            }
        });
    }
    else {
        // Si no se ha seleccionado ningún departamento, se deshabilita la combo de subdepartamentos
        $(".ddlSubdepartamentos").html("<option value='0'>Seleccione un dep.</option>");
        $(".ddlSubdepartamentos").attr("disabled", "disabled");
    }
}

// Función que configura los calendarios que se muestran en la aplicación
jQuery(function ($) {
    $.datepicker.regional['es'] = {
        closeText: 'Cerrar',
        prevText: '&#x3c;Ant',
        nextText: 'Sig&#x3e;',
        currentText: 'Hoy',
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
        dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi&eacute;rcoles', 'Jueves', 'Viernes', 'S&aacute;bado'],
        dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mi&eacute;', 'Juv', 'Vie', 'S&aacute;b'],
        dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'S&aacute;'],
        weekHeader: 'Sm',
        dateFormat: 'dd/mm/yy',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    $.datepicker.setDefaults($.datepicker.regional['es']);
});

// Valida que el DNI tenga el formato adecuado
function validarFormatoDNI(valor) {
    if (/^([0-9]{8})*[a-zA-Z]+$/.test(valor)) {
        var numero = valor.substr(0, valor.length - 1);
        var let = valor.substr(valor.length - 1, 1);
        numero = numero % 23;
        var letra = 'TRWAGMYFPDXBNJZSQVHLCKET';
        letra = letra.substring(numero, numero + 1);
        if (letra == let) return true;
        else return false;
    }
    else {
        return false;
    }
}

// Valida los datos introducidos en el formulario y muestra los mensajes de error adecuados
function validarUsuario() {
    var usuarioOK = true;

    // Valida que se ha rellenado el nombre del usuario
    if ($(".txtNombre").val() == "") {
        $(".txtNombre").addClass("inputerror");
        $("#txtNombreError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se han rellenado los apellidos del usuario
    if ($(".txtApellidos").val() == "") {
        $(".txtApellidos").addClass("inputerror");
        $("#txtApellidosError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se ha rellenado la fecha de nacimiento
    if ($(".txtFechaNac").val() == "") {
        $(".txtFechaNac").addClass("inputerror");
        $("#txtFechaNacError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se ha rellenado el DNI
    if ($(".txtDNI").val() == "") {
        $(".txtDNI").addClass("inputerror");
        $("#txtDNIError").css("display", "block");
        usuarioOK = false;
    }
    // Valida que la longitud del dni es correcta (8 números + 1 letra)
    else if ($(".txtDNI").val().length != 9) {
        $(".txtDNI").addClass("inputerror");
        $("#txtDNIVal").css("display", "block");
        usuarioOK = false;
    }
    // Valida que la letra del dni corresponde con el número
    else if (!validarFormatoDNI($(".txtDNI").val())) {
        $(".txtDNI").addClass("inputerror");
        $("#txtDNIVal").css("display", "block");
        usuarioOK = false;
    }

    //  Valida que se ha seleccionado un departamento
    if ($(".ddlDepartamentos option:selected").val() == "0") {
        $(".ddlDepartamentos").addClass("inputerror");
        $("#ddlDepartamentosError").css("display", "block");
        usuarioOK = false;
    }

    // Valida que se ha seleccionado un subdepartamento
    if ($(".ddlSubdepartamentos option:selected").val() == "0") {
        $(".ddlSubdepartamentos").addClass("inputerror");
        $("#ddlSubdepartamentosError").css("display", "block");
        usuarioOK = false;
    }

    return usuarioOK;
}

// Guarda los datos introducidos en el formulario, pasando el id del elemento en caso de que sea una modificación
// y un id vacío en caso de que sea nuevo
function guardar() {
    $("#dialog-form img").attr("title", "");
    $("#dialog-form img").hide();

    // Antes de guardar valida los datos
    if (validarUsuario()) {
        // Construye el objeto json con los datos del formulario
        var parametros = [];
        parametros.push("'idUsuario':" + $(".IdUsuario").val());
        parametros.push("'nombre':'" + $(".txtNombre").val().replace("'", "´") + "'");
        parametros.push("'apellidos':'" + $(".txtApellidos").val().replace("'", "´") + "'");
        parametros.push("'fechaNacimiento':'" + $(".txtFechaNac").val() + "'");
        parametros.push("'Dni':'" + $(".txtDNI").val().replace("'", "´") + "'");
        parametros.push("'blActivo':" + ($(".blnActivo").is(":checked")));
        parametros.push("'idDepartamento':" + $(".ddlDepartamentos option:selected").val());
        parametros.push("'idSubdepartamento':" + $(".ddlSubdepartamentos option:selected").val());
        if ($(".rdSexoHombre").is(":checked")) parametros.push("'sexo':'H'");
        else parametros.push("'sexo':'M'");
        // Convierte el array de parámetros en una línea de la forma { 'param1' : 'valor1', 'param2' : 'valor2', ... }
        var params = '{' + parametros.join(',') + '}';
        var datosUsuario;
        $.ajax({
            type: "POST",
            url: "gestion_usuarios_ficha.aspx/guardarUsuario",
            data: params,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                // Si 
                datosUsuario = msg.d;
                var userData = $.parseJSON(datosUsuario);
                if (userData[0] == false) {
                    $("#dialog-msg #mensaje_usuario").html("El usuario ha sido guardado correctamente");
                    $("#dialog-msg").dialog("open");
                    $("#dialog-msg .ui-dialog-titlebar-close").hide();
                    
                }
                else {
                    if (userData[1].TipoMensaje == 4) {
                        $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                        $("#dialog-msg").dialog("open");
                        $("#dialog-msg .ui-dialog-titlebar-close").hide();
                        $("#dialog-msg #btnAceptar").click(function() { $('#dialog-msg').dialog('close'); });
                    }
                    else {
                        $("#dialog-msg #mensaje_usuario").html(userData[1].Mensaje);
                        $("#dialog-msg").dialog("open");
                        $("#dialog-msg .ui-dialog-titlebar-close").hide();
                        $("#dialog-msg #btnAceptar").click(function () { volver(); });
                    }
                }
            }
        });
    }
}

// Ajusta la altura del cuerpo de la aplicación según el tamaño de la ventana
function ajustarAltura() {
    var alturaPie = $("#pie").position().top;
    var alturaCabecera = $("#cabecera").height();
    if (alturaPie > alturaCabecera) {
        $("#cuerpo").height(alturaPie - alturaCabecera);
    }
}

// Muestra u oculta elementos según el nivel de permisos
function perfilFuncion() {
    var perfilFuncion = $("#lblPerfilFuncion").html();

    if (perfilFuncion == "L") {
        $(".Permisos").css("display", "none");
        $(".NoPermisos").css("display", "block");
    }
}

// Configuraciones básicas de la aplicación
$(document).ready(function () {
    // Pone los calendarios en español
    $.datepicker.setDefaults($.datepicker.regional["es"]);

    // Indica que el campo es un calendario
    $(".txtFechaNac").datepicker({
        changeMonth: true,
        changeYear: true,
        minDate: '-100Y',
        maxDate: 0
    });

    // Indica que el div es un diálogo de confirmación
    $("#dialog-confirm").dialog({
        autoOpen: false,
        height: 100,
        width: 300,
        modal: true,
        resizable: false
    });

    // Indica que el div es un diálogo de mensaje al usuario
    $("#dialog-msg").dialog({
        autoOpen: false,
        height: 120,
        width: 350,
        modal: true,
        resizable: false
    });

    // Comprueba el nivel de permisos del usuario
    perfilFuncion();

    // Asigna un evento a la función de redimensionado de la ventana para que cuando se redimensione los controles se ajusten
    $(window).resize(function () {
        ajustarAltura();
    });

    // Ajusta los controles al tamaño actual
    ajustarAltura();

    // Reajusta la página si no se ve el menú de la izquierda
    if ($("#menu_izq").html().length == 0) {
        $("#menu_izq").hide();
        $("#contenido").css("width", "970px");
        $("#cabecera_busqueda").css("width", "970px");
        $("#contenedor_busqueda table").css("margin-left", "75px");
        $("#contenedor_tabla_listado").css("width", "970px");
        $("#contenedor_tabla_listado").css("overflow", "auto");
    }

    // Oculta las líneas punteadas en los enlaces
    $("a").focus(function () { this.blur() });

});

// Cambia la imagen asociada a un elemento
function cambiar_img(elemento, img) {
    elemento.src = img;
}

// Muestra los mensajes de error al usuario
function mostrarMensajes(mensajes) {

    $("#dialog-msg #mensaje_usuario").html(mensajes);
    $("#dialog-msg").dialog("open");
    $("#dialog-msg .ui-dialog-titlebar-close").hide();

}

// Sale de la ficha y vuelve al listado
function volver() {
    location.href = "gestion_usuarios_listado.aspx?accion=volver";
    
}