﻿var datos = new Array();

//Función para que únicamente esté seleccionada una fila del grid al mismo tiempo
function CheckOne(obj) {
    var grid = obj.parentNode.parentNode.parentNode;
    var inputs = grid.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            if (obj.checked && inputs[i] != obj && inputs[i].checked) {
                inputs[i].checked = false;
            }
        }
    }
}

function trasladarValores(nombreApellidos, codEmp) {
    datos[0] = 'true';
    datos[1] = nombreApellidos;
    datos[2] = codEmp;
    window.returnValue = datos;
    window.close();
}

function cerrarPopUp() {
    datos[0] = 'false'
    window.returnValue = datos;
    window.close();
}

function popupEditarMedio(w, h) {
    var datos = new Array();
    datos = window.showModalDialog('EditarMedio.aspx', '', 'dialogHeight:' + h + ' px;dialogWidth:' + w + ' px;center:Yes;help:No;resizable: No;status:No;');
    if (datos != null) {
        if (datos[0] == 'true') //Hay datos de respuesta
        {
            //hacemos postback para refrescar el grid de cesiones
            //window.__doPostBack('MainContent_btnFiltrarCesiones', '');
            document.getElementById('MainContent_btnFiltrarCesiones').click();
        }
    }
    return false;
}