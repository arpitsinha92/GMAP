using System;
using System.Data;
using System.Configuration;
using System.Web;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Bll
{
    public class Menus: Base
    {
        private Dal.Menus dal;
        
        public Menus(ref MantMensajes mantMensajes)
        {
            dal = new Dal.Menus(ref mantMensajes);
           
        }      

        /// <summary>
        /// M�todo para obtener el menu que se debe cargar seg�n el perfil.
        /// </summary>
        /// <param name="intIdPerfil">Perfil del usuario logado.</param>
        /// <returns>DataTable con los datos del men�.</returns>
        public DataTable cargarMenu(string intIdPerfil)
        {
            // Creamos el dataSet
            DataSet menus = new DataSet();
            DataTable menu = new DataTable();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {         
                // Realizamos la llamada a cargarMenu
                menus = dal.cargarMenu(intIdPerfil);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (menus != null && menus.Tables.Count > 0)
                    {
                        menu = menus.Tables[0];
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            return menu;
        }

        /// <summary>
        /// Recuperamos la funci�n del perfil.
        /// </summary>
        /// <param name="strperfil">Pefil.</param>
        /// <returns>Devolvemos las funciones que tiene.</returns>
        public string obtenerFuncion(string strperfil)
        {            
            DataSet funcion = new DataSet();
            DataTable funcionTabla;
            bool permisosEscritura;
            bool permisosLectura;
            string funcionalidad = Constantes.SIN_PERMISOS;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamamos al obtenerFuncion
                funcion = dal.obtenerFuncion(strperfil);

                 // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (funcion != null && funcion.Tables.Count > 0)
                    {
                        funcionTabla = funcion.Tables[0];

                        foreach (DataRow drFuncion in funcionTabla.Rows)
                        {
                            // Recuperamos los permisos para el perfil
                            permisosEscritura = Convert.ToBoolean(drFuncion[Constantes.REGISTRO_ESCRITURA]);
                            permisosLectura = Convert.ToBoolean(drFuncion[Constantes.REGISTRO_LECTURA]);
                            // Si tiene permisos de lectura y escritura
                            if ((permisosEscritura) && (permisosLectura))
                            {
                                // Asignamos permisos totales
                                return funcionalidad = Constantes.PERMISOS_TOTAL;
                            }
                            // Si tiene permisos de escritura
                            else if (permisosEscritura)
                            {
                                // Asignamos permisos de escritura
                                return funcionalidad = Constantes.PERMISOS_ESCRITURA;
                            }
                            // Si tiene permisos de lectura
                            else if (permisosLectura)
                            {
                                // Asignamos permisos de lectura
                                return funcionalidad = Constantes.PERMISOS_LECTURA;
                            }                            
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }           

            return funcionalidad;
        }
    }
}