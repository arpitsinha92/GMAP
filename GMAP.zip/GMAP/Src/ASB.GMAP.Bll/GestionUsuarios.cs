﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;

namespace ASB.GMAP.Bll
{
    public class GestionUsuarios: Base
    {
        private Dal.GestionUsuarios dal;

        public GestionUsuarios(ref MantMensajes mantMensajes)
        {
            dal = new Dal.GestionUsuarios(ref mantMensajes);
           
        }        

        /// <summary>
        /// Recuperamos la lista de Departamentos
        /// </summary>
        /// <returns>Lista departamentos</returns>
        public List<Departamento> obtenerListaDepartamentos()
        {
            // Lista de departamentes
            List<Departamento> departamento = new List<Departamento>();
            // Creamos el dataSet
            DataSet listadepartamento = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {               
                // Llamada al método que accede a la base de datos
                listadepartamento = dal.obtenerListaDepartamentos();

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {

                    if (listadepartamento.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        for (int i = 0; i < listadepartamento.Tables[0].Rows.Count; i++)
                        {
                            // Añadimos los departamentos a la lista
                            departamento.Add(new Departamento(idDepartamento: Convert.ToInt16(listadepartamento.Tables[0].Rows[i][0].ToString()), idDepartamentoPadre: null, nombre: listadepartamento.Tables[0].Rows[i][1].ToString()));
                        }
                    }
                }

            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de departamentos
            return departamento;
        }
       

        /// <summary>
        /// Recuperamos la lista de Subdepartamentos
        /// </summary>
        /// <returns>Lista departamentos</returns>
        public List<Departamento> obtenerListaSubdepartamentos(int idDepartamento)
        {
            // Lista de departamentos
            List<Departamento> listSubdepartamento = new List<Departamento>();
            DataSet ds = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                ds = dal.obtenerListaSubdepartamentos(idDepartamento);

                if (!dal.Manejador.existenMensajes())
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            listSubdepartamento.Add(new Departamento(idDepartamento: Convert.ToInt16(ds.Tables[0].Rows[i][0].ToString()), idDepartamentoPadre: Convert.ToInt16(ds.Tables[0].Rows[i][1].ToString()), nombre: ds.Tables[0].Rows[i][2].ToString()));
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            return listSubdepartamento;

        }       

        /// <summary>
        /// Recuperamos los Departamentos
        /// </summary>
        /// <returns>Devuelve un dataset</returns>
        public Departamento obtenerDepartamento(int idDepartamento)
        {
            Departamento departamento = new Departamento();
            DataSet ds = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

             try
            {
                ds = dal.obtenerDepartamento(idDepartamento);

                if (!dal.Manejador.existenMensajes())
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            departamento.IdDepartamento = Convert.ToInt16(ds.Tables[0].Rows[i][0].ToString());
                            departamento.IdDepartamentoPadre = null;
                            departamento.Nombre = ds.Tables[0].Rows[i][2].ToString();

                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos la excepción
                dal.Manejador.agregar(err);
            }

            // Devolvemos el departamento
            return departamento;
        }       

        /// <summary>
        /// Recuperamos el subdepartamento para los id indicados.
        /// </summary>
        /// <param name="idDepartamento">Id del subdepartamento.</param>
        /// <param name="idDepartamentoPadre">Id del departamento.</param>
        /// <returns>Devuelve la descripción del subdepartamento.</returns>
        public Departamento obtenerSubdepartamento(int idDepartamento, int idDepartamentoPadre)
        {
            // Declaramos el subdepartamento
            Departamento subdepartamento = new Departamento();
            // Declaramos el dataset
            DataSet ds = new DataSet();
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Realizamos la llamada al método que accede a base de datos
                ds = dal.obtenerSubdepartamento(idDepartamento, idDepartamentoPadre);

                if (!dal.Manejador.existenMensajes())
                {
                    // Recuperamos los resultados
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            subdepartamento.IdDepartamento = Convert.ToInt16(ds.Tables[0].Rows[i][0].ToString());
                            subdepartamento.IdDepartamentoPadre = Convert.ToInt16(ds.Tables[0].Rows[i][1].ToString());
                            subdepartamento.Nombre = ds.Tables[0].Rows[i][2].ToString();
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos el subdepartamento
            return subdepartamento;
        }
              

       /// <summary>
       /// Recuperamos la lista de usuarios.
       /// </summary>
       /// <param name="totalFilas">Número total de usuarios.</param>
       /// <param name="total">True indica que no vamos a paginar.</param>
       /// <param name="pagina">Número de pagina a mostrar.</param>
       /// <param name="orden">Campo por el que se va a ordenar.</param>
       /// <param name="descendiente">False indica que se ordenará ascendentemente y true que se hará descendientemente.</param>
       /// <param name="filtros">Los filtros seleccionados en los criterios de búsqueda.</param>
       /// <returns>Lista de usuarios.</returns>
        public List<Usuario> obtenerUsuarios(ref Int32 totalFilas, bool total, int pagina = 1, string orden = "", bool descendiente = false, Usuario filtros = null)
        {
            List<Usuario> usuariosList = new List<Usuario>();
            DataSet ds = new DataSet();
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
           
            try
            {
                // Realizamos la llamada al método que accede a base de datos
                ds = dal.obtenerUsuarios(orden, descendiente, filtros, ref totalFilas);

                if (!dal.Manejador.existenMensajes())
                {                    
                    if (totalFilas > 0)
                    {
                        // Recuperamos los registros
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            Usuario usuarios = new Usuario();
                            Departamento departamento = new Departamento();
                            Departamento subdepartamento = new Departamento();
                            usuarios.IdUsuario = Convert.ToInt16(ds.Tables[0].Rows[i][0].ToString());
                            usuarios.Nombre = ds.Tables[0].Rows[i][1].ToString();
                            usuarios.Apellidos = ds.Tables[0].Rows[i][2].ToString();
                            usuarios.FechaNacimiento = Convert.ToDateTime(ds.Tables[0].Rows[i][3].ToString());
                            usuarios.Dni = ds.Tables[0].Rows[i][4].ToString();
                            usuarios.Activo = Convert.ToBoolean(ds.Tables[0].Rows[i][5].ToString());
                            departamento.IdDepartamento = Convert.ToInt16(ds.Tables[0].Rows[i][6].ToString());
                            departamento.Nombre = ds.Tables[0].Rows[i][7].ToString();
                            usuarios.Departamento = departamento;
                            subdepartamento.IdDepartamentoPadre = Convert.ToInt16(ds.Tables[0].Rows[i][6].ToString());
                            subdepartamento.IdDepartamento = Convert.ToInt16(ds.Tables[0].Rows[i][8].ToString());
                            subdepartamento.Nombre = ds.Tables[0].Rows[i][9].ToString();
                            usuarios.Subdepartamento = subdepartamento;
                            usuarios.Sexo = Convert.ToChar(ds.Tables[0].Rows[i][10].ToString());
                            usuariosList.Add(usuarios);
                        }
                    }


                    // Comprobamos si la página pedida entra dentro de los resultados por arriba
                    // En caso contrario devolvemos la última página
                    if (((pagina - 1) * Ent.Constantes.MAX_POR_PAGINA) > totalFilas)
                    {
                        pagina = (totalFilas / Ent.Constantes.MAX_POR_PAGINA) + 1;
                    }

                    // Comprobamos si la página pedida entra dentro de los resultados por abajo
                    if (pagina < 1)
                    {
                        pagina = 1;
                    }

                    // Si queremos paginar
                    if (!total)
                    {
                        // Devolvemos los registros de la paginación
                        usuariosList = usuariosList.Skip((pagina - 1) * Ent.Constantes.MAX_POR_PAGINA).Take(Ent.Constantes.MAX_POR_PAGINA).ToList();

                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }
            // Devolvemos los usuarios
            return usuariosList;

        }

        /// <summary>
        /// Obtenemos el usuario según su id.
        /// </summary>
        /// <param name="idUsuario">Id del usuario.</param>
        /// <returns>Usuario.</returns>
        public Usuario obtenerUsuario(int idUsuario)
        {            
            // Declaramos el subdepartamento
            Usuario usuario = new Usuario();
            // Declaramos el dataset
            DataSet dsUsuario = new DataSet();
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try 
            {
                // Accedemos a base de datos
                dsUsuario = dal.obtenerUsuario(idUsuario);
                // Si no tenemos errores continuamos
                if (!dal.Manejador.existenMensajes())
                {
                    usuario.IdUsuario = idUsuario;
                    usuario.Nombre = dsUsuario.Tables[0].Rows[0][0].ToString();
                    usuario.Apellidos = dsUsuario.Tables[0].Rows[0][1].ToString();
                    usuario.FechaNacimiento = Convert.ToDateTime(dsUsuario.Tables[0].Rows[0][2].ToString());
                    usuario.Dni = dsUsuario.Tables[0].Rows[0][3].ToString();
                    usuario.Activo = Convert.ToBoolean(dsUsuario.Tables[0].Rows[0][4].ToString());
                    int IdDepartamentoPadre = Convert.ToInt16(dsUsuario.Tables[0].Rows[0][5].ToString());
                    int IdDepartamento = Convert.ToInt16(dsUsuario.Tables[0].Rows[0][6].ToString());
                    usuario.Departamento = obtenerDepartamento(IdDepartamentoPadre);
                    usuario.Subdepartamento = obtenerSubdepartamento(IdDepartamento, IdDepartamentoPadre);
                    usuario.Sexo = Convert.ToChar(dsUsuario.Tables[0].Rows[0][7].ToString());
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }            

            return usuario;

        }

        /// <summary>
        /// Validamos si el DNI ya lo tiene otro usuario.
        /// </summary>
        /// <param name="DNI">DNI</param>
        /// <param name="IdUsuario">Id del Usuario.</param>
        /// <returns>Devuelve ok si el DNI</returns>
        public bool validarDNI(string DNI, int IdUsuario = 0)
        {
            bool dniOK = false;
            int nUsuario;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try 
            {
                // Accedemos a base de datos
                nUsuario = dal.validarDNI(DNI, IdUsuario);

                if (!dal.Manejador.existenMensajes())
                {
                    if (nUsuario == 0)
                    {
                        dniOK = true;
                    }
                }

            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            return dniOK;
        }
        

        /// <summary>
        /// Método para guardar los usuarios.
        /// </summary>
        /// <param name="usuarioAct">Usuario.</param>
        /// <returns>Devuelve si se ha guardado o actualizado correctamente.</returns>
        public int guardarUsuario(Usuario usuarioAct)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Realizamos las validaciones en la capa de negocio
                // Si ok, guardamos o actualizamos
                if (validarUsuario(usuarioAct))
                {
                    // Si IDUsuario es cero, es un usuario nuevo
                    if (usuarioAct.IdUsuario == 0)
                    {
                        // Accedemos a la capa de datos
                        intGuardar = dal.insertarUsuario(usuarioAct);
                        // Si no existen mensajes continuamos
                        if (!dal.Manejador.existenMensajes())
                        {   // Si se ha guardado correctamente
                            if (intGuardar == 1)
                            {
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);

                            }
                            else
                            {   // Si ha ocurrido algún problema
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_GUARDAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                        }
                    }
                    else
                    {
                        // Accedemos a la capa de datos
                        int nError = dal.actualizarUsuario(usuarioAct);
                        // Si no existen mensajes continuamos
                        if (!dal.Manejador.existenMensajes())
                        {   // Si se ha actualizado correctamente
                            if (nError == 1)
                            {
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                            else
                            {   // Si ha ocurrido algún problema
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                        }
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Método para el borrar usuarios.
        /// </summary>
        /// <param name="idUsuario">Id de usuario.</param>
        /// <returns>Devuelve si se ha borrado correctamente o no.</returns>
        public int borrarUsuario(int idUsuario)
        {           
            int intBorrado = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                intBorrado = dal.borrarUsuario(idUsuario);

                if (!dal.Manejador.existenMensajes())
                {
                    if (intBorrado == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ELIMINACION_CORRECTA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                    else
                    {   // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ELIMINAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intBorrado;           

        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                }
                else 
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());

            }

            return mensajes;
        }

        /// <summary>
        /// Validaciones de datos de usuario en BL.
        /// </summary>
        /// <param name="usuario">Usuario.</param>
        /// <returns>Devuelve true si los datos están informados.</returns>
        public bool validarUsuario(Usuario usuario) 
        {
            bool validarUsuario = true;
            MensajesEntidad mensaje = new MensajesEntidad();
            mensaje.TipoMensaje = Mensajes.tiposMensaje.Advertencia;

            if (usuario.Nombre == null) 
            {                              
                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.CAMPO_OBLIGATORIO_NO_INFORMADO), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                // Agregamos el mensaje a la lista
                dal.Manejador.agregar(mensaje);                
                validarUsuario = false;
            }
            if (usuario.Apellidos == null)
            {
                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.CAMPO_OBLIGATORIO_NO_INFORMADO), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                dal.Manejador.agregar(mensaje);
                validarUsuario = false;
            }
            if (usuario.Dni == null)
            {
                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.CAMPO_OBLIGATORIO_NO_INFORMADO), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                dal.Manejador.agregar(mensaje);
                validarUsuario = false;
            }
            else if (!validarDNI(usuario.Dni, Convert.ToInt16(usuario.IdUsuario)))
            {
                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_DNI), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                dal.Manejador.agregar(mensaje);
                validarUsuario = false;
            }
          
            return validarUsuario; 
        }

    }

}