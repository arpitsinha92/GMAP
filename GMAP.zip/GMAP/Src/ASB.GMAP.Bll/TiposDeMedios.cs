﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class TiposDeMedios:Base
    {
        private Dal.TiposDeMedios dal;
        public TiposDeMedios(ref MantMensajes mantMensajes)
        {
            dal = new Dal.TiposDeMedios(ref mantMensajes);
           
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la inserción
        /// </summary>
        /// <param name="tipoDeMedioAct">Tipo de medio a insertar</param>
        /// <returns></returns>
        public int guardarTipoDeMedio(TipoDeMedio tipoDeMedioAct)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                // Si OidTipoMedio es cero, es un tipo de medio nuevo
                if (tipoDeMedioAct.OidTipoMedio == 0)
                {
                    if (!existeNombreTipoMedio(tipoDeMedioAct))
                    {
                        // Accedemos a la capa de datos
                        intGuardar = dal.insertarTipoDeMedio(tipoDeMedioAct);
                        // Si no existen mensajes continuamos
                        if (!dal.Manejador.existenMensajes())
                        {   // Si se ha guardado correctamente (2 REGISTROS)
                            if (intGuardar == 2)
                            {
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);

                            }
                            else
                            {   // Si ha ocurrido algún problema
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_GUARDAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                        }
                    }
                    else
                    {
                        //Si tiene modelos con fecha de baja superior a la fecha de baja de la marca informamos al usuario
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.TIPOMEDIO_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
                //Si OidTipoMedio es <> 0 entonces estamos en una actualización de un registros existente
                else
                {
                     if (!existeNombreTipoMedio(tipoDeMedioAct))
                    {
                        //Para poder modificar la fecha de baja de tipo de medio sus medios tienen que tener una fecha de baja anterior.
                        if (tieneFecBajaAnteriorMedios(tipoDeMedioAct))
                        {
                            //Si tiene modelos con fecha de baja superior a la fecha de baja de la marca informamos al usuario
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.TIPOMEDIO_CON_FECBAJA_ANTERIOR_MEDIOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {
                            // Accedemos a la capa de datos
                            intGuardar = dal.actualizarTipoDeMedio(tipoDeMedioAct);
                            // Si no existen mensajes continuamos
                            if (!dal.Manejador.existenMensajes())
                            {   // Si se ha actualizado correctamente
                                if (intGuardar == 1)
                                {
                                    MensajesEntidad mensaje = new MensajesEntidad();
                                    mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                    // Agregamos el mensaje a la lista
                                    dal.Manejador.agregar(mensaje);
                                }
                                else
                                {   // Si ha ocurrido algún problema
                                    MensajesEntidad mensaje = new MensajesEntidad();
                                    mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                    // Agregamos el mensaje a la lista
                                    dal.Manejador.agregar(mensaje);
                                }
                            }
                        }
                    }
                     else
                     {
                         //Si tiene modelos con fecha de baja superior a la fecha de baja de la marca informamos al usuario
                         MensajesEntidad mensaje = new MensajesEntidad();
                         mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.TIPOMEDIO_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                         // Agregamos el mensaje a la lista
                         dal.Manejador.agregar(mensaje);
                     }
                }                
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Comprobamos si ya existe un tipo de medio con el mismo nombre
        /// </summary>
        /// <param name="tipoMedio">Datos del tipo de medio</param>
        /// <returns>true si existe un tipo de medio con el mismo nombre</returns>
        private bool existeNombreTipoMedio(TipoDeMedio tipoMedio)
        {
            bool result = false;

            // Accedemos a la capa de datos
            result = dal.existeNombreTipoMedio(tipoMedio);

            return result;
        }

        /// <summary>
        /// Comprobamos si la fecha de baja del tipo de medio es anterior a la fecha de baja de alguno de sus medios
        /// </summary>
        /// <param name="modelo">Datos de la marca</param>
        /// <returns>true si tiene medios con fecha de baja posterior a la fecha de baja de la marca</returns>
        private bool tieneFecBajaAnteriorMedios(TipoDeMedio tipMedio)
        {
            bool result = false;

            if (tipMedio.FecBaja.Equals(""))
            {
                //si la fecha de baja sigue vacia no hay conflicto de fechas
                result = false;
            }
            else
            {
                // Accedemos a la capa de datos
                result = dal.tieneFecBajaAnteriorMedios(tipMedio);
            }
            return result;
        }

       
        public DataSet buscarTiposDeMedio(string filtroTipoMedio, out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsBusquedaTipos = null;
            numRegistros = 0;
            try
            {   
                // Accedemos a la capa de datos
                dsBusquedaTipos = dal.buscarTiposDeMedio(filtroTipoMedio);
                //obtenemos el número de registros recuperados.
                numRegistros = dsBusquedaTipos.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsBusquedaTipos;
        }

        public int eliminarTipoDeMedio(string oidTipoMedio)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            int intEliminar = 0;
            try
            {
                // Accedemos a la capa de datos
                intEliminar = dal.eliminarTipoDeMedio(oidTipoMedio);
                // Si no existen mensajes continuamos
                if (!dal.Manejador.existenMensajes())
                {   // Si se ha guardado correctamente
                    if (intEliminar == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ELIMINACION_CORRECTA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);

                    }
                    else
                    {   // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ELIMINAR_TIPODEMEDIO), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intEliminar;
        }

        

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }
    }
}
