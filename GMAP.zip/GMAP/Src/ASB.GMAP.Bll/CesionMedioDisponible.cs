﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class CesionMedioDisponible:Base
    {
        private Dal.CesionMedioDisponible dal;
        public CesionMedioDisponible(ref MantMensajes mantMensajes)
        {
            dal = new Dal.CesionMedioDisponible(ref mantMensajes);
           
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la inserción
        /// </summary>
        /// <param name="medio">Medio a insertar</param>
        /// <param name="cesion">Cesión del medio a insertar</param>
        /// <param name="opcionGuardar"></param>
        /// <returns></returns>
        public int guardarCesionMedioDisponible(Cesion cesion, string opcionGuardar)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {                
                //Si opcionGuardar es 1 entonces tendremos que guardar el medio y crear una nueva cesión del dicho medio asociada a un empleado
                if (opcionGuardar.Equals("1"))
                {
                    // Accedemos a la capa de datos
                    intGuardar = dal.insertarMedioCedidoEmpleado(cesion);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (intGuardar == 2)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    //Si opcionGuardar es 2 entonces tendremos que guardar el medio y crear una nueva cesión del dicho medio asociada a un departamento
                    // Accedemos a la capa de datos
                    intGuardar = dal.insertarMedioCedidoDepartamento(cesion);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (intGuardar == 2)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }         
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Método para obtener el dataset con los medios según el tipo de medio al que pertenezcan
        /// </summary>
        /// <param name="oidTipoMedio">Tipo de medio al que pertenecerán los medios seleccionados</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <param name="numRegistros">Número de registros devuelto por la consulta</param>
        /// <returns></returns>
        public DataSet buscarMedios(int oidTipoMedio,string perfiles, out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsbuscarMedios = null;
            numRegistros = 0;
            try
            {
                // Accedemos a la capa de datos
                dsbuscarMedios = dal.buscarMedios(oidTipoMedio,perfiles);
                //obtenemos el número de registros recuperados.
                numRegistros = dsbuscarMedios.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsbuscarMedios;
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }
    }
}
