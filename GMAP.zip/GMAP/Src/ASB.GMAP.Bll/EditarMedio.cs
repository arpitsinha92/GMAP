﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;
using System.Collections;

namespace ASB.GMAP.Bll
{
    public class EditarMedio : Base
    {
        private Dal.EditarMedio dal;
        private DataTable dtDatosTiposDeMedios = null;

        public EditarMedio(ref MantMensajes mantMensajes)
        {
            dal = new Dal.EditarMedio(ref mantMensajes);
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar actualización
        /// </summary>
        /// <param name="medio">Medio a actualizar</param>
        /// <returns></returns>
        public int guardarMedio(Medio medio)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                if (!existeIDModeloTipoMedio(medio))
                {
                    // Accedemos a la capa de datos
                    intGuardar = dal.actualizarMedio(medio);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha guardado correctamente
                        if (intGuardar == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);

                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_GUARDAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    // Si ha ocurrido algún problema
                    MensajesEntidad mensaje = new MensajesEntidad();
                    mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.IDMEDIO_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                    // Agregamos el mensaje a la lista
                    dal.Manejador.agregar(mensaje);
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Obtenemos los datos de la cesión activa (en caso de exisitir) para el medio
        /// </summary>
        /// <param name="oidMedio">identificativo del medio</param>
        /// <returns>devolvemos las fechas de finalización de cesion y de prorroga.</returns>
        public ArrayList obtenerDatosCesionMedio(string oidMedio)
        {
            ArrayList result = new ArrayList();
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataTable dtCesion = null;
            try
            {
                // Accedemos a la capa de datos
                dtCesion = dal.obtenerDatosCesionMedio(oidMedio);
                if (dtCesion.Rows.Count > 0)
                {
                    result.Add(dtCesion.Rows[0]["int_oidcesion"].ToString());
                    result.Add(dtCesion.Rows[0]["dat_fecfin"].ToString());
                    result.Add(dtCesion.Rows[0]["dat_fecfinprorroga"].ToString());
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }


            return result;
        }

        /// <summary>
        /// Comprobamos si ya existe un medio con ID asociado al tipo de medio seleccionado
        /// </summary>
        /// <param name="medio">Datos del medio</param>
        /// <returns>true si existe un medio con ID asociado al tipo de medio seleccionado</returns>
        private bool existeIDModeloTipoMedio(Medio medio)
        {
            bool result = false;

            // Accedemos a la capa de datos
            result = dal.existeIDModeloTipoMedio(medio);

            return result;
        }

        /// <summary>
        /// LLamada a la capa de datos para obtener los datos asociados a los tipos de medios
        /// Si tiene marca y modelo, si tiene extensión y si es entregable
        /// </summary>
        /// <returns></returns>
        public void obtenerDatosTiposDeMedios()
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                // Accedemos a la capa de datos
                dtDatosTiposDeMedios = dal.obtenerDatosTiposDeMedios();
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            //return dsDatosTiposDeMedios;
        }

        /// <summary>
        /// comprobamos si el tipo de medio seleccionado tiene marca y modelo
        /// </summary>
        /// <returns></returns>
        public bool tieneMarcaModelo(int oidTipoMedio)
        {
            bool result = false;

            DataRow[] fila = dtDatosTiposDeMedios.Select(Constantes.OIDTIPOMEDIO + " = " + oidTipoMedio);

            result = Convert.ToBoolean(string.IsNullOrEmpty(fila[0][Constantes.MARCAMODELO].ToString()) ? "false" : fila[0][Constantes.MARCAMODELO].ToString());

            return result;
        }

        /// <summary>
        /// comprobamos si el tipo de medio seleccionado tiene extension
        /// </summary>
        /// <returns></returns>
        public bool tieneExtension(int oidTipoMedio)
        {
            bool result = false;

            DataRow[] fila = dtDatosTiposDeMedios.Select(Constantes.OIDTIPOMEDIO + " = " + oidTipoMedio);

            result = Convert.ToBoolean(string.IsNullOrEmpty(fila[0][Constantes.EXTENSION].ToString()) ? "false" : fila[0][Constantes.EXTENSION].ToString());

            return result;
        }

        /// <summary>
        /// comprobamos si el tipo de medio seleccionado es entregable
        /// </summary>
        /// <returns></returns>
        public bool esEntregable(int oidTipoMedio)
        {
            bool result = false;

            DataRow[] fila = dtDatosTiposDeMedios.Select(Constantes.OIDTIPOMEDIO + " = " + oidTipoMedio);

            result = Convert.ToBoolean(string.IsNullOrEmpty(fila[0][Constantes.ENTREGABLE].ToString()) ? "false" : fila[0][Constantes.ENTREGABLE].ToString());

            return result;
        }

        /// <summary>
        /// /// Recuperamos la lista de modelos asociados a la marca
        /// </summary>
        /// <param name="oidMarca">Marca para filtrar los modelos</param>
        /// <returns>lista de modelos asociados a la marca</returns>
        public List<Modelo> obtenerListaModelos(int oidMarca)
        {
            // Lista de modelos
            List<Modelo> modelo = new List<Modelo>();
            // Creamos el dataSet
            DataSet listaModelo = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                listaModelo = dal.obtenerListaModelos(oidMarca);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {

                    if (listaModelo.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        for (int i = 0; i < listaModelo.Tables[0].Rows.Count; i++)
                        {
                            // Añadimos las marcas a la lista
                            modelo.Add(new Modelo(oidModelo: Convert.ToInt16(listaModelo.Tables[0].Rows[i][Constantes.OIDMODELO]), nombre: listaModelo.Tables[0].Rows[i][Constantes.VAR_NOMBREMODELOENTERO].ToString(), descripcion: "", fecBaja: "", oidMarca: -1));
                        }
                    }
                }

            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de departamentos
            return modelo;
        }

        /// <summary>
        /// El medio está o ha estado cedido
        /// </summary>
        /// <param name="oidMedio">identificador del medio</param>
        /// <returns>true si el medio está o ha estado cedido, false si nunca ha estado cedido</returns>
        public bool tieneCesion(int oidMedio)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            bool result = false;

            try
            {
                // Accedemos a la capa de datos
                result = dal.tieneCesion(oidMedio);
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            //return dsDatosTiposDeMedios;

            return result;
        }

        /// <summary>
        /// obtenemos los datos del medio
        /// </summary>
        /// <param name="oidMedio">Identificador del medio</param>
        /// <returns></returns>
        public Medio buscarMedio(int oidMedio)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataTable dtMedio = null;
            Medio medio = null;

            try
            {

                // Accedemos a la capa de datos
                dtMedio = dal.buscarMedio(oidMedio);

                medio = new Medio(oidMedio
                                    , Convert.ToInt16(dtMedio.Rows[0]["int_oidTipoMedio"].ToString())
                                    , Convert.ToInt16(dtMedio.Rows[0]["int_oidModelo"].ToString().Equals("") ? "-1" : dtMedio.Rows[0]["int_oidModelo"].ToString())
                                    , Convert.ToInt16(dtMedio.Rows[0]["int_oidMarca"].ToString().Equals("") ? "-1" : dtMedio.Rows[0]["int_oidMarca"].ToString())
                                    , dtMedio.Rows[0]["var_codigomedio"].ToString()
                                    , dtMedio.Rows[0]["dat_falta"].ToString()
                                    , dtMedio.Rows[0]["dat_fbaja"].ToString()
                                    , dtMedio.Rows[0]["var_extension"].ToString()
                                    , dtMedio.Rows[0]["var_comentariosmedio"].ToString());
                                    //, dtMedio.Rows[0]["bit_libre"].ToString().Equals(string.Empty) ? true : Convert.ToBoolean(dtMedio.Rows[0]["bit_libre"]));

            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return medio;
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }
    }
}
