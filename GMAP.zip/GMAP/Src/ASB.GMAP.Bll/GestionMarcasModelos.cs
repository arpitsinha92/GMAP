﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class GestionMarcasModelos:Base
    {
        private Dal.GestionMarcasModelos dal;
        public GestionMarcasModelos(ref MantMensajes mantMensajes)
        {
            dal = new Dal.GestionMarcasModelos(ref mantMensajes);
           
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la inserción
        /// </summary>
        /// <param name="marca">Marca a insertar</param>
        /// <returns></returns>
        public int guardarMarca(Marca marca)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {   
                // Si OidModelo es cero, es una marca nueva
                if (marca.OidMarca == 0)
                {
                    if (!existeNombreMarca(marca))
                    {
                        // Accedemos a la capa de datos
                        intGuardar = dal.insertarMarca(marca);                   
                        // Si no existen mensajes continuamos
                        if (!dal.Manejador.existenMensajes())
                        {   // Si se ha guardado correctamente
                            if (intGuardar == 1)
                            {
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);

                            }
                            else
                            {   // Si ha ocurrido algún problema
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_GUARDAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                        }
                    }
                    else
                    {
                        // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MARCA_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
                //Si OidMarca es <> 0 entonces estamos en una actualización de un registros existente
                else
                {
                    if (!existeNombreMarca(marca))
                    {
                        //Para poder dar una marca de baja todos sus modelos tienen que estar dados de baja.
                        if (!tieneModelosDadosDeBaja(marca))
                        {
                            // Accedemos a la capa de datos
                            intGuardar = dal.actualizarMarca(marca);
                            // Si no existen mensajes continuamos
                            if (!dal.Manejador.existenMensajes())
                            {   // Si se ha actualizado correctamente
                                if (intGuardar == 1)
                                {
                                    MensajesEntidad mensaje = new MensajesEntidad();
                                    mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                    // Agregamos el mensaje a la lista
                                    dal.Manejador.agregar(mensaje);
                                }
                                else
                                {   // Si ha ocurrido algún problema
                                    MensajesEntidad mensaje = new MensajesEntidad();
                                    mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                    // Agregamos el mensaje a la lista
                                    dal.Manejador.agregar(mensaje);
                                }
                            }
                        }
                        else
                        {
                            //Si tiene modelos con fecha de baja superior a la fecha de baja de la marca informamos al usuario
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MARCA_CON_MODELOS_BAJA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                    else
                    {
                        // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MARCA_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Comprobamos si ya existe una marca con el mismo nombre
        /// </summary>
        /// <param name="marca">Datos de la marca</param>
        /// <returns>true si existe una marca con el mismo nombre</returns>
        private bool existeNombreMarca(Marca marca)
        {
            bool result = false;
           
            // Accedemos a la capa de datos
            result = dal.existeNombreMarca(marca);
            
            return result;
        }

        /// <summary>
        /// Comprobamos si la fecha de baja de la marca es anterior a alguna fecha de baja de sus
        /// modelos asociados
        /// </summary>
        /// <param name="marca">Datos de la marca</param>
        /// <returns>true si tiene modelos con fecha de baja posterior a la fecha de baja de la marca</returns>
        private bool tieneModelosDadosDeBaja(Marca marca)
        {
            bool result = false;

            if (marca.FecBaja.Equals(""))
            {
                //si la fecha de baja sigue vacia no hay conflicto de fechas
                result = false;
            }
            else
            {
                // Accedemos a la capa de datos
                result = dal.tieneModelosDadosDeBaja(marca);
            }
            return result;
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la inserción
        /// </summary>
        /// <param name="modelo">Marca a insertar</param>
        /// <returns></returns>
        public int guardarModelo(Modelo modelo)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                // Si OidModelo es cero, es un modelo nuevo
                if (modelo.OidModelo == 0)
                {
                    if (!existeNombreMarcaModelo(modelo))
                    {
                        // Accedemos a la capa de datos
                        intGuardar = dal.insertarModelo(modelo);
                        // Si no existen mensajes continuamos
                        if (!dal.Manejador.existenMensajes())
                        {   // Si se ha guardado correctamente
                            if (intGuardar == 1)
                            {
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);

                            }
                            else
                            {   // Si ha ocurrido algún problema
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_GUARDAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                        }
                    }
                    else
                    {
                        // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MODELO_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
                //Si OidModelo es <> 0 entonces estamos en una actualización de un registros existente
                else
                {
                    if (!existeNombreMarcaModelo(modelo))
                    {
                        //Para poder dar un modelo de baja todos sus medios tienen que estar dados de baja.
                        if (tieneMediosDadosDeBaja(modelo))
                        {
                            //Si tiene modelos con fecha de baja superior a la fecha de baja de la marca informamos al usuario
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MODELO_CON_MEDIOS_BAJA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {
                            //La fecha de baja del modelo no puede ser posterior a la fecha de baja de la marca
                            if (tieneFecBajaPosteriorMarca(modelo))
                            {
                                //Si tiene modelos con fecha de baja superior a la fecha de baja de la marca informamos al usuario
                                MensajesEntidad mensaje = new MensajesEntidad();
                                mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MODELO_CON_FECBAJA_POSTERIOR_MARCA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                // Agregamos el mensaje a la lista
                                dal.Manejador.agregar(mensaje);
                            }
                            else
                            {
                                // Accedemos a la capa de datos
                                intGuardar = dal.actualizarModelo(modelo);
                                // Si no existen mensajes continuamos
                                if (!dal.Manejador.existenMensajes())
                                {   // Si se ha actualizado correctamente
                                    if (intGuardar == 1)
                                    {
                                        MensajesEntidad mensaje = new MensajesEntidad();
                                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                        // Agregamos el mensaje a la lista
                                        dal.Manejador.agregar(mensaje);
                                    }
                                    else
                                    {   // Si ha ocurrido algún problema
                                        MensajesEntidad mensaje = new MensajesEntidad();
                                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                                        // Agregamos el mensaje a la lista
                                        dal.Manejador.agregar(mensaje);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.MODELO_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        
        /// <summary>
        /// Comprobamos si ya existe modelo asociado a la marca seleccionada con el mismo nombre
        /// </summary>
        /// <param name="modelo">Datos del modelo</param>
        /// <returns>true si existe un modelo asociado a la marca con el mismo nombre</returns>
        private bool existeNombreMarcaModelo(Modelo modelo)
        {
            bool result = false;
           
            // Accedemos a la capa de datos
            result = dal.existeNombreMarcaModelo(modelo);
            
            return result;
        }

        
        /// <summary>
        /// Comprobamos si la fecha de baja del modelo es posterior a la fecha de baja de la marca a la que pertenece
        /// </summary>
        /// <param name="modelo">Datos de la marca</param>
        /// <returns>true si tiene medios con fecha de baja posterior a la fecha de baja de la marca</returns>
        private bool tieneFecBajaPosteriorMarca(Modelo modelo)
        {
            bool result = false;

            if (modelo.FecBaja.Equals(""))
            {
                //si la fecha de baja sigue vacia no hay conflicto de fechas
                result = false;
            }
            else
            {
                // Accedemos a la capa de datos
                result = dal.tieneFecBajaPosteriorMarca(modelo);
            }
            return result;
        }

        /// <summary>
        /// Comprobamos si la fecha de baja del modelo es anterior a alguna fecha de baja de sus
        /// medios asociados
        /// </summary>
        /// <param name="modelo">Datos de la marca</param>
        /// <returns>true si tiene medios con fecha de baja posterior a la fecha de baja del modelo</returns>
        private bool tieneMediosDadosDeBaja(Modelo modelo)
        {
            bool result = false;

            if (modelo.FecBaja.Equals(""))
            {
                //si la fecha de baja sigue vacia no hay conflicto de fechas
                result = false;
            }
            else
            {
                // Accedemos a la capa de datos
                result = dal.tieneMediosDadosDeBaja(modelo);
            }
            return result;
        }
        
        /// <summary>
        /// Método para obtener las marcas
        /// </summary>
        /// <param name="numRegistros">Número de registros devuelto por la consulta</param>
        /// <returns></returns>
        public DataSet buscarMarcas(out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsBusquedaMarcas = null;
            numRegistros = 0;
            try
            {   
                // Accedemos a la capa de datos
                dsBusquedaMarcas = dal.buscarMarcas();
                //obtenemos el número de registros recuperados.
                numRegistros = dsBusquedaMarcas.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsBusquedaMarcas;
        }

        /// <summary>
        /// Método para obtener los modelos
        /// </summary>
        /// <param name="numRegistros">Número de registros devuelto por la consulta</param>
        /// <returns></returns>
        public DataSet buscarModelos(int oidMarca, out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsBusquedaModelos = null;
            numRegistros = 0;
            try
            {
                // Accedemos a la capa de datos
                dsBusquedaModelos = dal.buscarModelos(oidMarca);
                //obtenemos el número de registros recuperados.
                numRegistros = dsBusquedaModelos.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsBusquedaModelos;
        }
        
        
        /// <summary>
        /// Método que llamará a la capa de datos para borrar la marca seleccionada
        /// </summary>
        /// <param name="oidMarca">identificativo único de la marca a borrar</param>
        /// <returns></returns>
        public int eliminarMarca(string oidMarca)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            int intEliminar = 0;
            try
            {
                // Accedemos a la capa de datos
                intEliminar = dal.eliminarMarca(oidMarca);
                // Si no existen mensajes continuamos
                if (!dal.Manejador.existenMensajes())
                {   // Si se ha guardado correctamente
                    if (intEliminar == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ELIMINACION_CORRECTA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);

                    }
                    else
                    {   // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ELIMINAR_MARCA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intEliminar;
        }

        /// <summary>
        /// Método que llamará a la capa de datos para borrar el modelo seleccionado
        /// </summary>
        /// <param name="oidModelo">identificativo único del modelo a borrar</param>
        /// <returns></returns>
        public int eliminarModelo(string oidModelo)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            int intEliminar = 0;
            try
            {
                // Accedemos a la capa de datos
                intEliminar = dal.eliminarModelo(oidModelo);
                // Si no existen mensajes continuamos
                if (!dal.Manejador.existenMensajes())
                {   // Si se ha eliminado correctamente
                    if (intEliminar == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ELIMINACION_CORRECTA), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);

                    }
                    else
                    {   // Si ha ocurrido algún problema HABRIA QUE AÑADIR EL MENSAJE DE QUE EL MODELOS ESTA ASOCIADO A MEDIOS
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ELIMINAR_MODELO), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intEliminar;
        }

        

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        /// <summary>
        /// Recuperamos la lista de Marcas
        /// </summary>
        /// <returns>Lista Marcas</returns>
        public List<Marca> obtenerListaMarcas()
        {
            // Lista de marcas
            List<Marca> marca = new List<Marca>();
            // Creamos el dataSet
            DataSet listaMarca = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                listaMarca = dal.buscarMarcas();

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {

                    if (listaMarca.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        for (int i = 0; i < listaMarca.Tables[0].Rows.Count; i++)
                        {
                            // Añadimos las marcas a la lista
                            marca.Add(new Marca(oidMarca:Convert.ToInt16(listaMarca.Tables[0].Rows[i][0]), nombre: listaMarca.Tables[0].Rows[i][1].ToString(), fecBaja: ""));
                        }
                    }
                }

            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de departamentos
            return marca;
        }
    }
}
