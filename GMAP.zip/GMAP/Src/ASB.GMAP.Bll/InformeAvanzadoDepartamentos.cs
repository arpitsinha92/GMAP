﻿using System;
using System.Data;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Collections.Generic;

namespace ASB.GMAP.Bll
{
    public class InformeAvanzadoDepartamentos : Base
    {
        private Dal.InformeAvanzadoDepartamentos dal;

        public InformeAvanzadoDepartamentos(ref MantMensajes mantMensajes)
        {
            dal = new Dal.InformeAvanzadoDepartamentos(ref mantMensajes);
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles, out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsTiposMedios = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsTiposMedios = dal.obtenerTiposMedios(perfiles);
                //obtenemos el número de registros recuperados.
                numeroRegistros = dsTiposMedios.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsTiposMedios;
        }

        /// <summary>
        /// Obtiene la lista de empresas para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de empresas</returns>
        public DataSet obtenerEmpresas(out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsEmpresas = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsEmpresas = dal.obtenerEmpresas();
                //obtenemos el número de registros recuperados.
                numeroRegistros = dsEmpresas.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsEmpresas;
        }

        /// <summary>
        /// Busca cesiones a departamentos que cumplan los criterios especificados en los parámetros.
        /// </summary>
        /// <param name="listaEmpresas">Lista separada por comas del los id de empresas</param>
        /// <param name="listaTipoMedios">Lista separada por comas del los id de tipos de medios</param>
        /// <param name="nombre">Nombre de la persona a quien se cedió el medio</param>
        /// <param name="codigoMedio">Código del medio</param>
        /// <param name="esCesionActiva">Indica si la cesión está activa</param>
        /// <returns>Un DataSet con las cesiones encontradas</returns>
        public DataSet buscarCesionesDepartamentos(string listaEmpresas, string listaTipoMedios, string nombre, string codigoMedio, int esCesionActiva, out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsCesionesDepartamentos = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsCesionesDepartamentos = dal.buscarCesionesDepartamentos(listaEmpresas, listaTipoMedios, nombre, codigoMedio, esCesionActiva);
                //obtenemos el número de registros recuperados.
                numeroRegistros = dsCesionesDepartamentos.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsCesionesDepartamentos;
        }

        public Dictionary<string, string> obtenerMapeosExcel()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            mapeos.Add("DESC_ORGUNITENTERO", "Departamento");
            mapeos.Add("VAR_CODIGOMEDIOENTERO", "ID");
            mapeos.Add("TIPOMEDIOENTERO", "Tipo de Medio");
            mapeos.Add("MODELOENTERO", "Modelo");
            mapeos.Add("DAT_FECINI", "F. Inicio Cesión");
            mapeos.Add("DAT_FECFIN", "F. Fin Cesión");
            mapeos.Add("ENTREGABLE", "Entregado");
            mapeos.Add("AUTORIZADOPORENTERO", "Pro. Autorizado Por");
            mapeos.Add("DAT_FECFINPRORROGA", "F. Fin Prórroga");

            return mapeos;
        }
    }
}
