﻿using System;
using System.Collections.Generic;
using System.Data;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Bll
{
    public class GestionAlertas : Base
    {
        private Dal.GestionAlertas dal;

        public GestionAlertas(ref MantMensajes mantMensajes)
        {
            dal = new Dal.GestionAlertas(ref mantMensajes);
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        #region Personas

        /// <summary>
        /// Busca cesiones de médios a empleados que cumplan los criterios especificados
        /// en los parámetros.
        /// </summary>
        /// <param name="nombreEmpleado">Nombre del empleado</param>
        /// <param name="idTipoMedio">Tipo de medio cedido</param>
        /// <param name="esProrrogado">Indica si se ha prorrogado la cesión</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns>Una lista con las cesiones encontradas</returns>
        public DataSet buscarCesionesPersonas(string nombreEmpleado, int idTipoMedio, int esProrrogado,string perfiles, out int numRegistros)
        {
            // Creamos el dataSet
            DataSet dsCesionesPersonas = new DataSet();
            numRegistros = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Accedemos a la capa de datos
                dsCesionesPersonas = dal.buscarCesionesPersonas(nombreEmpleado, idTipoMedio, esProrrogado, perfiles);
                //obtenemos el número de registros recuperados.
                numRegistros = dsCesionesPersonas.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return dsCesionesPersonas;
        }

        public Dictionary<string, string> obtenerMapeosExcelPersonas()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            mapeos.Add("NOMBREEMPLEADOENTERO", "Empleado");
            mapeos.Add("STRNOMBREEMPRESAENTERO", "Empresa");
            mapeos.Add("EXPAT_JUBI", "Prejub./Expat.");
            mapeos.Add("VAR_NOMBREENTERO", "Tipo de Medio");
            mapeos.Add("VAR_CODIGMEDIOENTERO", "ID");
            mapeos.Add("DATFECHABAJA", "F. Baja Empleado");
            mapeos.Add("DAT_FECINI", "F. Inicio Cesión");
            mapeos.Add("DAT_FECFIN", "F. Fin Cesión");
            mapeos.Add("AUTORIZADOPOR", "Autorizado Por");
            mapeos.Add("DAT_FECFINPRORROGA", "F. Fin Prórroga");

            return mapeos;
        }

        #endregion

        #region Departamentos

        /// <summary>
        /// Busca cesiones de médios a departamentos que cumplan los criterios especificados
        /// en los parámetros.
        /// </summary>
        /// <param name="nombreDepartamento">Nombre del departamento</param>
        /// <param name="idTipoMedio">Tipo de medio cedido</param>
        /// <param name="esProrrogado">Indica si se ha prorrogado la cesión</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <returns>Una lista con las cesiones encontradas</returns>
        public DataSet buscarCesionesDepartamentos(string nombreDepartamento, int idTipoMedio, int esProrrogado, string perfiles, out int numRegistros)
        {
            // Creamos el dataSet
            DataSet dsCesionesDepartamentos = new DataSet();
            numRegistros = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Accedemos a la capa de datos
                dsCesionesDepartamentos = dal.buscarCesionesDepartamentos(nombreDepartamento, idTipoMedio, esProrrogado, perfiles);
                //obtenemos el número de registros recuperados.
                numRegistros = dsCesionesDepartamentos.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsCesionesDepartamentos;
        }

        public Dictionary<string, string> obtenerMapeosExcelDepartamentos()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            mapeos.Add("DESC_ORGUNITENTERO", "Departamento");
            mapeos.Add("STRNOMBREEMPRESAENTERO", "Empresa");
            mapeos.Add("VAR_NOMBREENTERO", "Tipo de Medio");
            mapeos.Add("VAR_CODIGMEDIOENTERO", "ID");
            mapeos.Add("DAT_FECINI", "F. Inicio Cesión");
            mapeos.Add("DAT_FECFIN", "F. Fin Cesión");
            mapeos.Add("AUTORIZADOPOR", "Autorizado Por");
            mapeos.Add("DAT_FECFINPRORROGA", "F. Fin Prórroga");

            return mapeos;
        }

        #endregion
    }
}
