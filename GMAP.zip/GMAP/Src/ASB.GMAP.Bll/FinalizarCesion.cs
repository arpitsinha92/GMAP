﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;
using System.Collections;

namespace ASB.GMAP.Bll
{
    public class FinalizarCesion:Base
    {
        private Dal.FinalizarCesion dal;
        public FinalizarCesion(ref MantMensajes mantMensajes)
        {
            dal = new Dal.FinalizarCesion(ref mantMensajes);
           
        }

        /// <summary>
        ///  Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la eliminación
        /// </summary>
        /// <param name="oidCesion">identificativo de la cesión a borrar</param>
        /// <param name="opcionEliminar">indicador para determinar si la cesión pertenece a un empleado
        /// o a un departamento</param>
        /// <param name="fecBajaMedio">Fecha de baja del medio</param>
        /// <returns></returns>
        public int finalizarCesion(int oidCesion,int oidMedio, string fecBajaMedio, string opcionEliminar)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                //Si opcionGuardar es 1 entonces tendremos que eliminar la cesión de dicho medio asociada a un empleado
                if (opcionEliminar.Equals("1"))
                {
                    // Accedemos a la capa de datos
                    intGuardar = dal.finalizarCesionEmpleado(oidCesion,oidMedio, fecBajaMedio);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (intGuardar == 2 || intGuardar == 3)//afecta a dos o tres registros, a la fecha de fin de cesión, fecha fin de prorroga a la fecha de baja del medio
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    //Si opcionGuardar es 2 entonces tendremos que eliminar la cesión del dicho medio asociada a un departamento
                    // Accedemos a la capa de datos
                    intGuardar = dal.finalizarCesionDepartamento(oidCesion,oidMedio, fecBajaMedio);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (intGuardar == 2 || intGuardar == 3)//afecta a dos o tres registros, a la fecha de fin de cesión, fecha fin de prorroga a la fecha de baja del medio
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        ///  Método para obtener la cesión
        /// </summary>
        /// <param name="oidCesion">identificativo de la cesión</param>
        /// <param name="strNumEmpleado">identificativo del empleado</param>
        /// <param name="id_orgunit">identificativo del Departamento</param>
        /// <returns>Un array que contendrá en la primera posición un objeto de tipo Cesion 
        /// con los datos de la misma y en la segunda posición la fecha de baja del medio;
        /// </returns>
        public ArrayList buscarCesion(int oidCesion, string strNumEmpleado, string id_orgunit)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataTable dtBusquedaCesion = null;
            Cesion cesion = null;
            ArrayList arrReturn = new ArrayList();
            string fecBajaMedio = String.Empty;
            try
            {   
                //Determinamos si la cesión ha sido a un empleado o a un departamento
                if (strNumEmpleado.Equals(""))
                {
                    // Accedemos a la capa de datos
                    dtBusquedaCesion = dal.buscarCesionDepartamento(oidCesion);
                    
                    cesion = new Cesion(Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidcesiondepartamento"].ToString())
                                        ,id_orgunit,Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidmedio"].ToString())
                                        ,dtBusquedaCesion.Rows[0]["dat_fecini"].ToString()
                                        ,dtBusquedaCesion.Rows[0]["dat_fecfin"].ToString()
                                        ,""
                                        , dtBusquedaCesion.Rows[0]["NOMBREEMPLEADO"].ToString()
                                        ,dtBusquedaCesion.Rows[0]["dat_fecfinprorroga"].ToString()
                                        ,dtBusquedaCesion.Rows[0]["var_comentarios"].ToString());
                    fecBajaMedio = dtBusquedaCesion.Rows[0]["dat_fbaja"].ToString();
                }
                else
                {
                    // Accedemos a la capa de datos
                    dtBusquedaCesion = dal.buscarCesionEmpleado(oidCesion);
                    cesion = new Cesion(Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidcesionempleado"].ToString())
                                        , id_orgunit, Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidmedio"].ToString())
                                        , dtBusquedaCesion.Rows[0]["dat_fecini"].ToString()
                                        , dtBusquedaCesion.Rows[0]["dat_fecfin"].ToString()
                                        , ""
                                        , dtBusquedaCesion.Rows[0]["NOMBREEMPLEADO"].ToString()
                                        , dtBusquedaCesion.Rows[0]["dat_fecfinprorroga"].ToString()
                                        , dtBusquedaCesion.Rows[0]["var_comentarios"].ToString());
                    fecBajaMedio = dtBusquedaCesion.Rows[0]["dat_fbaja"].ToString();
                }
                arrReturn.Add(cesion);
                arrReturn.Add(fecBajaMedio);
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return arrReturn;
        }


        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }
            return mensajes;
        }                
    }
}
