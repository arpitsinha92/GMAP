﻿using System;
using System.Collections.Generic;
using System.Data;
using ASB.GMAP.Ent;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Bll
{
    public class InformeCuantalis : Base
    {
        private Dal.InformeCuantalis dal;

        public InformeCuantalis(ref MantMensajes mantMensajes)
        {
            dal = new Dal.InformeCuantalis(ref mantMensajes);
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles, out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsTiposMedios = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsTiposMedios = dal.obtenerTiposMedios(perfiles);
                numeroRegistros = dsTiposMedios.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsTiposMedios;
        }

        public DataSet generarInforme(DateTime fechaInicio, DateTime fechaFin, int idTipoMedio, out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsCuantalis = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsCuantalis = dal.generarInforme(fechaInicio, fechaFin, idTipoMedio);
                //obtenemos el número de registros recuperados.
                if (dsCuantalis != null)
                    numeroRegistros = dsCuantalis.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsCuantalis;
        }

        public Dictionary<string, string> obtenerMapeosExcel()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            //mapeos.Add("intCodSecuen", "CODIGO SECUENCIA"); // Columna no requerida
            //mapeos.Add("intCodTipoMedio", "CODIGO TIPO MEDIO"); // Columna no requerida
            mapeos.Add("strNombreEmpresa", "EMPRESA");
            mapeos.Add("strDireccionGeneral", "DIRECCION GENERAL");
            mapeos.Add("strCentroCoste", "CENTRO COSTE");
            mapeos.Add("strApellido1", "1º APELLIDO");
            mapeos.Add("strApellido2", "2º APELLIDO");
            mapeos.Add("strNombre", "NOMBRE");
            mapeos.Add("strNumEmpleado", "Nº EMPLEADO"); // Columna no requerida
            mapeos.Add("strNumeroID", "NUMERO");
            mapeos.Add("datFIniCesion", "FECHA INICIO");
            mapeos.Add("datFFinCesion", "FECHA FIN");
            mapeos.Add("strImputacion", "IMPUTACION");
            
            return mapeos;
        }
    }
}
