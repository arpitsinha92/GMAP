﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MB.Framework.ManejadorMensajes;


namespace ASB.GMAP.Bll
{
    public class Base
    {

        #region Variables

        /// <summary>
        /// Variable para manejar los mensajes
        /// </summary>
        private MantMensajes mantmensajes;

        #endregion

        #region Propiedaes

        public MantMensajes Manejador
        {
            get { return mantmensajes; }
            set { mantmensajes = value; }
        }


        #endregion

    }
}
