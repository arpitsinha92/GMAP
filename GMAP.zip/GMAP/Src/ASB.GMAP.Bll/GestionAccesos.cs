﻿using System;
using System.Collections.Generic;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using System.Data;
using MB.Framework.Log;

namespace ASB.GMAP.Bll
{
    public class GestionAccesos : Base
    {
        private Dal.GestionAccesos dal;

        public GestionAccesos(ref MantMensajes mantMensajes)
        {
            dal = new Dal.GestionAccesos(ref mantMensajes);
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        #region Funciones

        /// <summary>
        /// Obtiene una lista con todas las funciones
        /// </summary>
        /// <returns>Un DataSet con la lista de todas las funciones</returns>
        public List<Funcion> obtenerListaFunciones()
        {
            List<Funcion> funciones = new List<Funcion>();
            // Creamos el dataSet
            DataSet dsFunciones = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsFunciones = dal.obtenerListaFunciones();

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsFunciones.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsFunciones.Tables[0].Rows)
                        {
                            // Añadimos las funciones a la lista
                            Funcion funcion = new Funcion();

                            funcion.IdFuncion = Convert.ToInt32(fila[0]);
                            funcion.Nombre = fila[1].ToString();
                            funcion.FechaBaja = fila.IsNull(2) ? (DateTime?)null : Convert.ToDateTime(fila[2]);

                            funcion.TiposDeMedios = obtenerTiposMediosPorFuncion(funcion.IdFuncion);
                            funcion.Acciones = obtenerAccionesPorFuncion(funcion.IdFuncion);

                            funciones.Add(funcion);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return funciones;
        }

        /// <summary>
        /// Obtiene una lista de todos los tipos de medios
        /// </summary>
        /// <returns>Un DataSet con todos los tipos de medios</returns>
        public DataSet obtenerListaTiposMedios()
        {
            // Creamos el dataSet
            DataSet dsTiposMedios = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsTiposMedios = dal.obtenerListaTiposMedios();
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return dsTiposMedios;
        }

        /// <summary>
        /// Obtiene una lista de todas las acciones
        /// </summary>
        /// <returns>Un DataSet con la lista de todas las acciones</returns>
        public DataSet obtenerListaAcciones()
        {
            // Creamos el dataSet
            DataSet dsAcciones = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsAcciones = dal.obtenerListaAcciones();
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return dsAcciones;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <returns></returns>
        private List<Accion> obtenerAccionesPorFuncion(int idFuncion)
        {
            // Lista de acciones
            List<Accion> acciones = new List<Accion>();
            // El DataSet
            DataSet dsAcciones = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsAcciones = dal.obtenerAccionesPorFuncion(idFuncion);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsAcciones.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsAcciones.Tables[0].Rows)
                        {
                            // Añadimos las acciones a la lista
                            Accion accion = new Accion();

                            accion.IdAccion = Convert.ToInt32(fila[0]);
                            accion.Nombre = fila[1].ToString();
                            accion.FechaBaja = fila.IsNull(2) ? (DateTime?)null : Convert.ToDateTime(fila[2]);

                            acciones.Add(accion);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de acciones
            return acciones;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idFuncion"></param>
        /// <returns></returns>
        private List<TipoDeMedio> obtenerTiposMediosPorFuncion(int idFuncion)
        {
            // Lista de acciones
            List<TipoDeMedio> tiposMedios = new List<TipoDeMedio>();
            // El DataSet
            DataSet dsTiposMedios = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsTiposMedios = dal.obtenerTiposMediosPorFuncion(idFuncion);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsTiposMedios.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsTiposMedios.Tables[0].Rows)
                        {
                            // Añadimos las acciones a la lista
                            TipoDeMedio tipoMedio = new TipoDeMedio(Convert.ToInt16(fila[0].ToString())
                                                                    , fila[1].ToString()
                                                                    , fila.IsNull(2) ? null : fila[2].ToString()
                                                                    , fila.IsNull(3) ? null : fila[3].ToString()
                                                                    , fila.IsNull(4) ? false : Convert.ToBoolean(fila[4])
                                                                    , fila.IsNull(5) ? false : Convert.ToBoolean(fila[5])
                                                                    , fila.IsNull(6) ? false : Convert.ToBoolean(fila[6])
                                                                    , fila.IsNull(7) ? null : fila[7].ToString());

                            tiposMedios.Add(tipoMedio);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de acciones
            return tiposMedios;
        }

        /// <summary>
        /// Elimina una función dado su ID
        /// </summary>
        /// <param name="idFuncion">ID de la función</param>
        /// <param name="fechaBaja">Fecha en la que se da de baja la función</param>
        /// <returns>Número de registros afectados</returns>
        public int eliminarFuncion(int idFuncion, DateTime fechaBaja)
        {
            int resultado = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                resultado = dal.eliminarFuncion(idFuncion, fechaBaja);

                if (!dal.Manejador.existenMensajes())
                {
                    if (resultado == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ELIMINACION_CORRECTA), Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                    else
                    {   // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_ELIMINAR), Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="funcion"></param>
        /// <returns></returns>
        public int guardarFuncion(Funcion funcion)
        {
            int resultado = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Realizamos las validaciones en la capa de negocio
                // Si ok, guardamos o actualizamos

                // Si IdFuncion es cero, es una función nueva
                if (funcion.IdFuncion == 0)
                {
                    // Accedemos a la capa de datos
                    resultado = dal.insertarFuncion(funcion);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha guardado correctamente
                        if (resultado == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);

                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_GUARDAR), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    // Accedemos a la capa de datos
                    resultado = dal.actualizarFuncion(funcion);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (resultado == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_ACTUALIZAR), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return resultado;
        }

        #endregion

        #region Perfiles

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<Perfil> obtenerListaPerfiles()
        {
            // Lista de perfiles
            List<Perfil> perfiles = new List<Perfil>();
            // Creamos el dataSet
            DataSet dsPerfiles = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsPerfiles = dal.obtenerListaPerfiles();

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsPerfiles.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsPerfiles.Tables[0].Rows)
                        {
                            // Añadimos las funciones a la lista
                            Perfil perfil = new Perfil();

                            perfil.IdPerfil = Convert.ToInt32(fila[0]);
                            perfil.Nombre = fila[1].ToString();
                            perfil.FechaBaja = fila.IsNull(2) ? (DateTime?)null : Convert.ToDateTime(fila[2]);

                            perfil.Funciones = obtenerFuncionesPorPerfil(perfil.IdPerfil);
                            perfil.OpcionesMenu = obtenerOpcionesMenuPorPerfil(perfil.IdPerfil);

                            perfiles.Add(perfil);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return perfiles;
        }

        public List<OpcionMenu> obtenerListaOpcionesMenu()
        {
            // Lista de perfiles
            List<OpcionMenu> opcionesMenu = new List<OpcionMenu>();
            // Creamos el dataSet
            DataSet dsOpcionesMenu = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsOpcionesMenu = dal.obtenerListaOpcionesMenu();

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsOpcionesMenu.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsOpcionesMenu.Tables[0].Rows)
                        {
                            // Añadimos las funciones a la lista
                            OpcionMenu opcionMenu = new OpcionMenu();

                            opcionMenu.IdOpcionMenu = Convert.ToInt32(fila[0]);
                            opcionMenu.IdOpcionMenuPadre = fila.IsNull(1) ? (int?)null : Convert.ToInt32(fila[1]);
                            opcionMenu.Descripcion = fila[2].ToString();
                            opcionMenu.Url = fila.IsNull(3) ? null : fila[3].ToString();
                            opcionMenu.Posicion = fila.IsNull(4) ? (int?)null : Convert.ToInt32(fila[4]);

                            opcionesMenu.Add(opcionMenu);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return opcionesMenu;
        }

        private List<OpcionMenu> obtenerOpcionesMenuPorPerfil(int idPerfil)
        {
            // Lista de acciones
            List<OpcionMenu> opcionesMenu = new List<OpcionMenu>();
            // El DataSet
            DataSet dsOpcionesMenu = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsOpcionesMenu = dal.obtenerOpcionesMenuPorPerfil(idPerfil);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsOpcionesMenu.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsOpcionesMenu.Tables[0].Rows)
                        {
                            // Añadimos las acciones a la lista
                            OpcionMenu opcionMenu = new OpcionMenu();

                            opcionMenu.IdOpcionMenu = Convert.ToInt32(fila[0]);
                            opcionMenu.IdOpcionMenuPadre = fila.IsNull(1) ? (int?)null : Convert.ToInt32(fila[1]);
                            opcionMenu.Descripcion = fila[2].ToString();
                            opcionMenu.Url = fila.IsNull(3) ? null : fila[3].ToString();
                            opcionMenu.Posicion = fila.IsNull(4) ? (int?)null : Convert.ToInt32(fila[4]);

                            opcionesMenu.Add(opcionMenu);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de acciones
            return opcionesMenu;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idPerfil"></param>
        /// <returns></returns>
        private List<Funcion> obtenerFuncionesPorPerfil(int idPerfil)
        {
            // Lista de acciones
            List<Funcion> funciones = new List<Funcion>();
            // El DataSet
            DataSet dsFunciones = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsFunciones = dal.obtenerFuncionesPorPerfil(idPerfil);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsFunciones.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsFunciones.Tables[0].Rows)
                        {
                            // Añadimos las acciones a la lista
                            Funcion funcion = new Funcion();

                            funcion.IdFuncion = Convert.ToInt32(fila[0]);
                            funcion.Nombre = fila[1].ToString();
                            funcion.FechaBaja = fila.IsNull(2) ? (DateTime?)null : Convert.ToDateTime(fila[2]);

                            funciones.Add(funcion);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de acciones
            return funciones;
        }

        /// <summary>
        /// Elimina un perfil dado su ID
        /// </summary>
        /// <param name="idPerfil">ID del perfil</param>
        /// <param name="fechaBaja">Fecha en la que se da de baja el perfil</param>
        /// <returns>Número de registros afectados</returns>
        public int eliminarPerfil(int idPerfil, DateTime fechaBaja)
        {
            int resultado = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                resultado = dal.eliminarPerfil(idPerfil, fechaBaja);

                if (!dal.Manejador.existenMensajes())
                {
                    if (resultado == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ELIMINACION_CORRECTA), Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                    else
                    {   // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_ELIMINAR), Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return resultado;
        }

        /// <summary>
        /// Guarda un perfil
        /// </summary>
        /// <param name="perfil">Objeto Perfil a guardar</param>
        /// <returns>Número de registros afectados</returns>
        public int guardarPerfil(Perfil perfil)
        {
            int resultado = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Realizamos las validaciones en la capa de negocio
                // Si ok, guardamos o actualizamos

                // Si IdPerfil es cero, es una función nueva
                if (perfil.IdPerfil == 0)
                {
                    // Accedemos a la capa de datos
                    resultado = dal.insertarPerfil(perfil);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha guardado correctamente
                        if (resultado == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);

                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_GUARDAR), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    // Accedemos a la capa de datos
                    resultado = dal.actualizarPerfil(perfil);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (resultado == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_ACTUALIZAR), Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return resultado;
        }

        #endregion

        public List<string> obtenerAccionesPorPerfil(string perfiles)
        {
            // Lista de acciones
            List<string> acciones = new List<string>();
            // El DataSet
            DataSet dsAcciones = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsAcciones = dal.obtenerAccionesPorPerfil(perfiles);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsAcciones.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsAcciones.Tables[0].Rows)
                        {
                            // Añadimos las acciones a la lista
                            acciones.Add(fila[0].ToString());
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de acciones
            return acciones;
        }

        public List<string> obtenerPaginasPorPerfil(string perfiles)
        {
            // Lista de acciones
            List<string> paginas = new List<string>();
            // El DataSet
            DataSet dsPaginas = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                dsPaginas = dal.obtenerPaginasPorPerfil(perfiles);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {
                    if (dsPaginas.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        foreach (DataRow fila in dsPaginas.Tables[0].Rows)
                        {
                            // Añadimos las acciones a la lista
                            paginas.Add(fila[0].ToString());
                        }
                    }
                }
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de acciones
            return paginas;
        }
    }
}
