﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class GestionDepartamentos:Base
    {
        private Dal.GestionDepartamentos dal;
        public GestionDepartamentos(ref MantMensajes mantMensajes)
        {
            dal = new Dal.GestionDepartamentos(ref mantMensajes);
           
        }

        /// <summary>
        /// Método para obtener los departamentos
        /// </summary>
        /// <param name="dept">Datos de filtrado de departamento</param>
        /// <param name="numRegistros">Número de registros que devuelve la consulta</param>
        /// <returns></returns>
        public DataSet buscarDepartamentos(FiltroDepartamento dept, out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsBusquedaDepartamentos = null;
            numRegistros = 0;
            try
            {
                // Accedemos a la capa de datos
                dsBusquedaDepartamentos = dal.buscarDepartamentos(dept);
                //obtenemos el número de registros recuperados.
                numRegistros = dsBusquedaDepartamentos.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsBusquedaDepartamentos;
        }

        /// <summary>
        /// Método para obtener las personas
        /// </summary>
        /// <param name="cesion">Datos de filtrado de la cesión</param>
        /// <param name="perfiles">Perfiles del usuario para filtrar los tipos de medios</param>
        /// <param name="numRegistros">Número de registros que devuelve la consulta</param>
        /// <returns></returns>
        public DataSet buscarCesiones(FiltroCesion cesion,string perfiles, out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsBusquedaCesiones = null;
            numRegistros = 0;
            try
            {
                // Accedemos a la capa de datos
                dsBusquedaCesiones = dal.buscarCesiones(cesion, perfiles);
                //obtenemos el número de registros recuperados.
                numRegistros = dsBusquedaCesiones.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsBusquedaCesiones;
        }
        
        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        public Dictionary<string, string> obtenerMapeosExcel()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            mapeos.Add("var_codigomedioEntero", "ID");
            mapeos.Add("nombreTipoMedioEntero", "Tipo de Medio");
            mapeos.Add("entregado", "Entregado");
            mapeos.Add("nombreModeloEntero", "Modelo");
            mapeos.Add("dat_fecini", "F. Inicio Cesion");
            mapeos.Add("dat_fecfin", "F. Fin Cesión");
            mapeos.Add("dat_fecfinprorroga", "F. Fin Prórroga");
            mapeos.Add("nombreempleadoEntero", "Pro. Autorizado Por");

            return mapeos;
        }
    }
}
