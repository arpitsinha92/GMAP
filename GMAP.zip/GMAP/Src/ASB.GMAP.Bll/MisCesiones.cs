﻿using System;
using System.Collections.Generic;
using System.Data;
using ASB.GMAP.Ent;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;

namespace ASB.GMAP.Bll
{
    public class MisCesiones : Base
    {
        private Dal.MisCesiones dal;

        public MisCesiones(ref MantMensajes mantMensajes)
        {
            dal = new Dal.MisCesiones(ref mantMensajes);
        }

        public MisCesiones()
        {
            dal = new Dal.MisCesiones();
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        /// <summary>
        /// Busca cesiones de médios a empleados que cumplan los criterios especificados
        /// en los parámetros.
        /// </summary>
        /// <param name="numeroEmpleado">Número de identificación del empleado</param>
        /// <param name="idTipoMedio">Tipo de medio cedido</param>
        /// <param name="esActiva">Indica si la cesión está activa</param>
        /// <returns>Una lista con las cesiones encontradas</returns>
        public DataSet buscarMisCesiones(string numeroEmpleado, int idTipoMedio, int esActiva, out int numRegistros)
        {   
            // Creamos el dataSet
            DataSet dsMisCesiones = new DataSet();
            numRegistros = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Accedemos a la capa de datos
                dsMisCesiones = dal.buscarMisCesiones(numeroEmpleado, idTipoMedio, esActiva);
                //obtenemos el número de registros recuperados.
                numRegistros = dsMisCesiones.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de funciones
            return dsMisCesiones;
        }

        public DataTable cargaComboTipoMedios(string idUsuario)
        {
            DataTable dtTipoMedio = new DataTable("TipoMedio");
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                // Accedemos a la capa de datos
                dtTipoMedio = dal.cargaComboTipoMedios(idUsuario);
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }
            return dtTipoMedio;
        }

        public Dictionary<string, string> obtenerMapeosExcel()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            mapeos.Add("TIPOENTERO", "Tipo de Medio");
            mapeos.Add("IDENTERO", "ID Medio");
            mapeos.Add("MODELOENTERO", "Modelo");
            mapeos.Add("DAT_FECINI", "F. Inicio Cesión");
            mapeos.Add("DAT_FECFIN", "F. Fin Cesión");
            mapeos.Add("ENTREGABLE", "Entregado");
            mapeos.Add("AUTORIZADORENTERO", "Autorizado Por");
            mapeos.Add("DAT_FECFINPRORROGA", "F. Fin Prórroga");

            return mapeos;
        }
    }
}
