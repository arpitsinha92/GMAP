﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class BusquedaPersonas:Base
    {
        private Dal.BusquedaPersonas dal;
        public BusquedaPersonas(ref MantMensajes mantMensajes)
        {
            dal = new Dal.BusquedaPersonas(ref mantMensajes);
           
        }


        /// <summary>
        /// Método para obtener las personas
        /// </summary>
        /// <param name="filtroPer">datos de filtrado para la búsqueda de personas</param>
        /// <param name="numRegistros">número de registros devuelto por la búsqueda</param>
        /// <returns></returns>
        public DataSet buscarPersonas(FiltroPersona filtroPer, out int numRegistros)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataSet dsBusquedaPersonas = null;
            numRegistros = 0;
            try
            {
                // Accedemos a la capa de datos
                dsBusquedaPersonas = dal.buscarPersonas(filtroPer);
                //obtenemos el número de registros recuperados.
                numRegistros = dsBusquedaPersonas.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return dsBusquedaPersonas;
        }
        
        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }
    }
}
