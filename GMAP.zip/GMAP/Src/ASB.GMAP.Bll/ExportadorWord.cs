﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace ASB.GMAP.Bll
{
    public class ExportadorWord
    {
        // Campos públicos
        public DataTable tabla;
        public string rutaPlantilla;

        // Campos privados
        private string rutaFichero; 

        private WordprocessingDocument documentoWord;
        private Body body;

        // Constructores
        public ExportadorWord(DataTable tabla, string rutaPlantilla)
        {
            this.tabla = tabla;
            this.rutaPlantilla = rutaPlantilla;

            inicializar();
        }

        private void inicializar()
        {
            rutaFichero = Path.GetTempPath() + Path.ChangeExtension(Path.GetRandomFileName(), Constantes.EXTENSION_WORD);

            // Abrimos un nuevo documento Word a partir de la plantilla
            File.Copy(rutaPlantilla, rutaFichero, true);

            FileAttributes attributes = File.GetAttributes(rutaFichero);

            // Si el fichero tiene el atributo de "Sólo lectura", se lo quitamos
            if ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
            {
                attributes = RemoveAttribute(attributes, FileAttributes.ReadOnly);
                File.SetAttributes(rutaFichero, attributes);
            }

            documentoWord = WordprocessingDocument.Open(rutaFichero, true);
            body = documentoWord.MainDocumentPart.Document.Body;
        }

        private static FileAttributes RemoveAttribute(FileAttributes attributes, FileAttributes attributesToRemove)
        {
            return attributes & ~attributesToRemove;
        }

        /// <summary>
        /// Exporta un Word a partir de un DataTable
        /// </summary>
        /// <returns>El fichero Word en forma de bytes</returns>
        public Byte[] exportarWord()
        {
            using (documentoWord)
            {
                // Rellenamos los datos del empleado
                crearDatosEmpleado();

                // Rellenamos los datos de la tabla
                crearTablaMedios();
            }

            // Devolvemos los bytes del fichero
            return convertirABytes();
        }

        /// <summary>
        /// Rellena la tabla de medios
        /// </summary>
        private void crearTablaMedios()
        {
            Table tablaMedios = body.Elements<Table>().First();
            TableRow segundaFila = tablaMedios.Elements<TableRow>().ElementAt(1);

            TableCell celdaMedios = segundaFila.Elements<TableCell>().ElementAt(0);
            TableCell celdaModelos = segundaFila.Elements<TableCell>().ElementAt(1);
            TableCell celdaID = segundaFila.Elements<TableCell>().ElementAt(2);
            TableCell celdaFecFinCes = segundaFila.Elements<TableCell>().ElementAt(3);
            TableCell celdaFecFinPrg = segundaFila.Elements<TableCell>().ElementAt(4);
            TableCell celdaAutorizado = segundaFila.Elements<TableCell>().ElementAt(5);
            TableCell celdaEntregado = segundaFila.Elements<TableCell>().ElementAt(6);

            //RunProperties styleRunProperties1 = new RunProperties();
            //RunFonts font1 = new RunFonts() { Ascii = "Arial" };
            //FontSize fontSize1 = new FontSize() { Val = "18" };
            //styleRunProperties1.Append(font1);
            //styleRunProperties1.Append(fontSize1);
            
            for (int i = 0; i < tabla.Rows.Count; i++)
            {
                //Run rn1 = new Run();
                //rn1.AppendChild(styleRunProperties1);
                //rn1.Append(new Text(tabla.Rows[i]["TipoMedio"].ToString()));
                //celdaMedios.AppendChild(new Paragraph(rn1));
                //celdaModelos.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Modelos"].ToString()))));
                //celdaID.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["IdMedio"].ToString()))));
                //if (!string.IsNullOrEmpty(tabla.Rows[i]["FecFinCes"].ToString()))
                //{
                //    celdaFecFinCes.AppendChild(new Paragraph(new Run(new Text(Convert.ToDateTime(tabla.Rows[i]["FecFinCes"].ToString()).ToShortDateString()))));
                //}
                //if (!string.IsNullOrEmpty(tabla.Rows[i]["FecFinProrroga"].ToString()))
                //{
                //    celdaFecFinPrg.AppendChild(new Paragraph(new Run(new Text(Convert.ToDateTime(tabla.Rows[i]["FecFinProrroga"].ToString()).ToShortDateString()))));
                //}
                //celdaAutorizado.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Autorizado"].ToString()))));
                //celdaEntregado.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Entregado"].ToString()))));
                if (tabla.Rows[i]["TipoMedio"].ToString().Length > 25)
                {
                    celdaMedios.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["TipoMedio"].ToString().Substring(0, 22) + "..."))));
                }
                else
                {
                    celdaMedios.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["TipoMedio"].ToString()))));
                }
                if (tabla.Rows[i]["Modelos"].ToString().Length > 19)
                {
                    celdaModelos.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Modelos"].ToString().Substring(0, 16) + "..."))));
                }
                else
                {
                    celdaModelos.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Modelos"].ToString()))));
                }
                if (tabla.Rows[i]["IdMedio"].ToString().Length >= 17)
                {
                    celdaID.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["IdMedio"].ToString().Substring(0, 14) + "..."))));
                }
                else
                {
                    celdaID.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["IdMedio"].ToString()))));
                }                
                if (!string.IsNullOrEmpty(tabla.Rows[i]["FecFinCes"].ToString()))
                {
                    celdaFecFinCes.AppendChild(new Paragraph(new Run(new Text(Convert.ToDateTime(tabla.Rows[i]["FecFinCes"].ToString()).ToShortDateString()))));
                }
                if (!string.IsNullOrEmpty(tabla.Rows[i]["FecFinProrroga"].ToString()))
                {
                    celdaFecFinPrg.AppendChild(new Paragraph(new Run(new Text(Convert.ToDateTime(tabla.Rows[i]["FecFinProrroga"].ToString()).ToShortDateString()))));
                }
                if (tabla.Rows[i]["Autorizado"].ToString().Length >= 37)
                {
                    celdaAutorizado.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Autorizado"].ToString().Substring(0, 34) + "..."))));
                }
                else
                {
                    celdaAutorizado.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Autorizado"].ToString()))));
                }
                
                celdaEntregado.AppendChild(new Paragraph(new Run(new Text(tabla.Rows[i]["Entregado"].ToString()))));
            }
        }

        /// <summary>
        /// Rellena los datos del empleado
        /// </summary>
        private void crearDatosEmpleado()
        {
            // Nombre
            Paragraph parrafoNombre = body.Elements<Paragraph>().ElementAt(2);
            Run runNombre = new Run(new Text("Nombre: "+ tabla.Rows[0].ItemArray[0].ToString()));

            parrafoNombre.AppendChild(runNombre);
            parrafoNombre.AppendChild(new Run(new TabChar()));

            // Departamento            
            Run runDepartamento = new Run(new Text("Departamento: "+tabla.Rows[0].ItemArray[1].ToString()));
            parrafoNombre.AppendChild(runDepartamento);
            

            // Empresa
            Paragraph parrafoEmpresa = body.Elements<Paragraph>().ElementAt(3);
            Run runEmpresa = new Run(new Text("Empresa: "+tabla.Rows[0].ItemArray[2].ToString()));

            parrafoEmpresa.AppendChild(runEmpresa);
            parrafoEmpresa.AppendChild(new Run(new TabChar()));

            // Categoría
            Run runCategoria = new Run(new Text("Categoría: "+tabla.Rows[0].ItemArray[3].ToString()));
            parrafoEmpresa.AppendChild(runCategoria);            
        }

        /// <summary>
        /// Convierte el fichero Word en una cadena de bytes
        /// </summary>
        /// <returns>El fichero Excel en forma de cadena de bytes</returns>
        private Byte[] convertirABytes()
        {
            Byte[] bytes;
            using (FileStream fileStream = File.OpenRead(rutaFichero))
            {
                bytes = new byte[(int)fileStream.Length];
                fileStream.Read(bytes, 0, (int)fileStream.Length);
            }

            // Borramos el fichero temporal
            File.Delete(rutaFichero);

            return bytes;
        }
    }
}
