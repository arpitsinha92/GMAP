﻿using System;
using System.Data;
using MB.Framework.Log;
using MB.Framework.ManejadorMensajes;
using System.Collections.Generic;

namespace ASB.GMAP.Bll
{
    public class GestionMedios : Base
    {
        private Dal.GestionMedios dal;

        public GestionMedios(ref MantMensajes mantMensajes)
        {
            dal = new Dal.GestionMedios(ref mantMensajes);
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }

        /// <summary>
        /// Busca medios que cumplan los criterios especificados en los parámetros.
        /// </summary>
        /// <param name="idMedio">Código identificador del medio</param>
        /// <param name="tipoCesion">Tipo de cesion: -1 -> Todas; 0 -> A personas; 1 -> A departamentos; 2 -> Disponibles</param>
        /// <param name="estado">Estado del medio: -1 -> Todas; 0 -> No activo; 1 -> Activo</param>
        /// <param name="listaTipoMedios">Lista separada por comas del los id de tipos de medios</param>
        /// <returns>Una DataSet con los medios encontrados</returns>
        public DataSet buscarMedios(string idMedio, int tipoCesion, int estado, string listaTipoMedios, int cesionesActivas, int medioLibre, string comentarios, out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsMedios = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsMedios = dal.buscarMedios(idMedio, tipoCesion, estado, listaTipoMedios, cesionesActivas, medioLibre, comentarios);
                //obtenemos el número de registros recuperados.
                numeroRegistros = dsMedios.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsMedios;
        }

        /// <summary>
        /// Obtiene la lista de tipos de medios para cargar combos, etc...
        /// </summary>
        /// <returns>Un DataSet con la lista de tipos de medios</returns>
        public DataSet obtenerTiposMedios(string perfiles, out int numeroRegistros)
        {
            // Creamos el dataSet
            DataSet dsTiposMedios = null;

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            numeroRegistros = 0;
            try
            {
                // Llamada al método que accede a la base de datos
                dsTiposMedios = dal.obtenerTiposMedios(perfiles);
                //obtenemos el número de registros recuperados.
                numeroRegistros = dsTiposMedios.Tables[0].Rows.Count;
            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de cesiones
            return dsTiposMedios;
        }

        public Dictionary<string, string> obtenerMapeosExcel()
        {
            // Renombramos las columnas del DataSet
            var mapeos = new Dictionary<string, string>();

            mapeos.Add("VAR_CODIGOMEDIOENTERO", "ID");
            mapeos.Add("TIPOMEDIOENTERO", "Tipo de Medio");
            mapeos.Add("MODELOENTERO", "Modelo");
            mapeos.Add("NOMBREEMPLEADO", "Cedido al Empleado");
            mapeos.Add("DESC_ORGUNIT", "Cedido al Departamento");
            mapeos.Add("FECINI", "F. Inicio Cesión");
            mapeos.Add("FECFIN", "F. Fin Cesión");
            mapeos.Add("AUTORIZADOPOR,", "AutorizadoPor");
            mapeos.Add("FECFINPRORROGA", "F. Fin Prórroga");

            return mapeos;
        }

        public object eliminarMedio(int idMedio)
        {
            int resultado = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                resultado = dal.eliminarMedio(idMedio, DateTime.Now);

                if (!dal.Manejador.existenMensajes())
                {
                    if (resultado == 1)
                    {
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ELIMINACION_CORRECTA), Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                    else
                    {   // Si ha ocurrido algún problema
                        MensajesEntidad mensaje = new MensajesEntidad();
                        mensaje = Mensajes.obtenerMensaje(Convert.ToInt32(Mensajes.Mensaje.ERROR_ELIMINAR), Mensajes.FicherosMensajes);
                        // Agregamos el mensaje a la lista
                        dal.Manejador.agregar(mensaje);
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return resultado;
        }
    }
}
