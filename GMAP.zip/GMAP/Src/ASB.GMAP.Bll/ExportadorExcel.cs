﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ASB.GMAP.Bll
{
    public class ExportadorExcel
    {
        // Campos públicos
        public DataTable Tabla { get; set; }
        public string RutaPlantilla { get; set; }
        public string TituloInforme { get; set; }
        public Dictionary<string, string> Filtros { get; set; }
        public Dictionary<string, string> Mapeos { get; set; }
        public List<string> CamposCentrados { get; set; }

        // Campos privados
        private string rutaFichero;
        private int indiceFilaInicio = Constantes.INDICE_FILA_INICIO_EXCEL;

        private SpreadsheetDocument documentoExcel;
        private WorkbookPart libro;
        private WorksheetPart hoja;
        private SheetData datosHoja;
        private Stylesheet hojaEstilo;

        private UInt32Value idEstiloNumero;
        private UInt32Value idEstiloDoble;
        private UInt32Value idEstiloFecha;

        // Constructores
        public ExportadorExcel(DataTable tabla, string rutaPlantilla)
        {
            this.Tabla = tabla;
            this.RutaPlantilla = rutaPlantilla;
            this.TituloInforme = string.Empty;
            this.Filtros = null;
        }

        public ExportadorExcel(DataTable tabla, string rutaPlantilla, Dictionary<string, string> filtros)
        {
            this.Tabla = tabla;
            this.RutaPlantilla = rutaPlantilla;
            this.TituloInforme = string.Empty;
            this.Filtros = filtros;
        }

        public ExportadorExcel(DataTable tabla, string rutaPlantilla, Dictionary<string, string> filtros, string tituloInforme)
        {
            this.Tabla = tabla;
            this.RutaPlantilla = rutaPlantilla;
            this.TituloInforme = tituloInforme;
            this.Filtros = filtros;
        }

        private void inicializar()
        {
            rutaFichero = Path.GetTempPath() + Path.PathSeparator + Path.ChangeExtension(Path.GetRandomFileName(), Constantes.EXTENSION_EXCEL);

            // Abrimos un nuevo documento Excel a partir de la plantilla
            File.Copy(RutaPlantilla, rutaFichero, true);

            FileAttributes attributes = File.GetAttributes(rutaFichero);

            // Se eliminar el atributo de solo lectura si lo tiene
            if ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
            {
                attributes = RemoveAttribute(attributes, FileAttributes.ReadOnly);
                File.SetAttributes(rutaFichero, attributes);
            }

            documentoExcel = SpreadsheetDocument.Open(rutaFichero, true);
            libro = documentoExcel.WorkbookPart;
            hoja = libro.WorksheetParts.Last();
            datosHoja = hoja.Worksheet.GetFirstChild<SheetData>();
            hojaEstilo = libro.WorkbookStylesPart.Stylesheet;

            idEstiloNumero = crearFormatoCelda(hojaEstilo, null, null, null, UInt32Value.FromUInt32(3));
            idEstiloDoble = crearFormatoCelda(hojaEstilo, null, null, null, UInt32Value.FromUInt32(4));
            idEstiloFecha = crearFormatoCelda(hojaEstilo, null, null, null, UInt32Value.FromUInt32(14));

            // Inicializamos los mapeos, si hay alguno
            if (Mapeos != null && Mapeos.Count > 0)
            {
                var columnasParaBorrar = new List<string>();

                for (int i = 0; i < Tabla.Columns.Count; i++)
                {
                    var encontrado = false;
                    foreach (var clave in Mapeos.Keys)
                    {
                        if (Tabla.Columns[i].ColumnName == clave)
                        {
                            Tabla.Columns[clave].ColumnName = Mapeos[clave];
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado)
                    {
                        columnasParaBorrar.Add(Tabla.Columns[i].ColumnName);
                    }
                }
                // Borramos las columnas que no estaban en el mapeo
                foreach (var columna in columnasParaBorrar)
                {
                    Tabla.Columns.Remove(columna);
                }
            }
        }

        /// <summary>
        /// Eliminar un atributo de un fichero.
        /// </summary>
        /// <param name="attributes">Fichero</param>
        /// <param name="attributesToRemove">Atributo a eliminar</param>
        /// <returns></returns>
        private static FileAttributes RemoveAttribute(FileAttributes attributes, FileAttributes attributesToRemove)
        {
            return attributes & ~attributesToRemove;
        }

        /// <summary>
        /// Exporta un Excel a partir de un DataTable
        /// </summary>
        /// <returns>El fichero Excel en forma de bytes</returns>
        public Byte[] exportarExcel()
        {
            inicializar();

            using (documentoExcel)
            {
                // Cabezera del informe
                crearCabezeraInforme();

                // Se añade un titulo opcional al informe
                if (TituloInforme != null)
                {
                    crearTituloInforme();
                }

                // Se añaden los filtros de la consulta si los hubiera
                crearFiltrosInforme();

                // Se añaden los datos del informe
                crearTablaInforme();
            }

            // Devolvemos los bytes del fichero
            return convertirABytes();
        }

        /// <summary>
        /// Exporta un Excel a partir de un DataTable
        /// </summary>
        /// <returns>El fichero Excel en forma de bytes</returns>
        public Byte[] exportarExcelIbatis()
        {
            inicializar();

            using (documentoExcel)
            {
                // Cabezera del informe
                crearCabezeraInforme();
                // Se añade un titulo opcional al informe
                if (TituloInforme != null)
                {
                    crearTituloInforme();
                }

                // Se añaden los datos del informe
                crearTablaInforme();
            }

            // Devolvemos los bytes del fichero
            return convertirABytes();
        }

        /// <summary>
        /// Crea los datos del informe
        /// </summary>
        private void crearTablaInforme()
        {
            Row filaCabezera = new Row();
            filaCabezera.RowIndex = (UInt32)indiceFilaInicio;

            UInt32Value indiceFuenteCabezera = crearFuente(hojaEstilo, "Calibri", 11, true, System.Drawing.Color.White);
            UInt32Value indiceRellenoCabezera = crearRelleno(hojaEstilo, System.Drawing.ColorTranslator.FromHtml(Constantes.COLOR_GRIS_OSCURO));
            UInt32Value indiceBordeCabezera = crearBorde(hojaEstilo, System.Drawing.Color.Black);
            UInt32Value indiceFormatoCabezera = crearFormatoCelda(hojaEstilo, indiceFuenteCabezera, indiceRellenoCabezera, indiceBordeCabezera, null, HorizontalAlignmentValues.Center);

            foreach (DataColumn columna in Tabla.Columns)
            {
                Cell celdaCabezera = crearCelda(indiceFilaInicio, Tabla.Columns.IndexOf(columna) + 1, columna.ColumnName, indiceFormatoCabezera);
                filaCabezera.AppendChild(celdaCabezera);
            }
            datosHoja.AppendChild(filaCabezera);

            // Se añaden el resto de filas del DataTable
            indiceFilaInicio++;

            SheetView vista = hoja.Worksheet.GetFirstChild<SheetViews>().GetFirstChild<SheetView>();

            Pane panel = new Pane() { VerticalSplit = indiceFilaInicio - 1, TopLeftCell = "A" + indiceFilaInicio.ToString(), ActivePane = PaneValues.BottomLeft, State = PaneStateValues.Frozen };
            vista.Append(panel);

            DataRow filaDatos;
            for (int i = 0; i < Tabla.Rows.Count; i++)
            {
                filaDatos = Tabla.Rows[i];
                datosHoja.AppendChild(crearFilaDatos(filaDatos, i + indiceFilaInicio));
            }
        }

        /// <summary>
        /// Crea los filtros del informe
        /// </summary>
        private void crearFiltrosInforme()
        {
            Row filaTituloFiltros = new Row();
            filaTituloFiltros.RowIndex = (UInt32)indiceFilaInicio;

            UInt32Value indiceFormatoCabezeraFiltro = crearFormatoCelda(hojaEstilo, null, null, crearBorde(hojaEstilo, System.Drawing.Color.Black), null);

            filaTituloFiltros.AppendChild(crearCelda(indiceFilaInicio, 1, "Filtros:", indiceFormatoCabezeraFiltro));
            for (int i = 1; i < Tabla.Columns.Count; i++)
            {
                filaTituloFiltros.AppendChild(crearCelda(indiceFilaInicio, i + 1, String.Empty, indiceFormatoCabezeraFiltro));
            }
            datosHoja.AppendChild(filaTituloFiltros);

            UInt32Value indiceFuenteFiltro = crearFuente(hojaEstilo, "Calibri", 11, false, System.Drawing.ColorTranslator.FromHtml(Constantes.COLOR_GRIS_OSCURO));
            UInt32Value indiceFormatoFiltro = crearFormatoCelda(hojaEstilo, indiceFuenteFiltro, null, null, null);

            if (Filtros != null)
            {
                foreach (string clave in Filtros.Keys)
                {
                    indiceFilaInicio++;

                    Row filaFiltro = new Row();
                    filaFiltro.RowIndex = (UInt32)indiceFilaInicio;

                    Cell celdaClave = crearCelda(indiceFilaInicio, 1, clave, indiceFormatoFiltro);
                    Cell celdaValor = crearCelda(indiceFilaInicio, 2, Filtros[clave], indiceFormatoFiltro);

                    filaFiltro.AppendChild(celdaClave);
                    filaFiltro.AppendChild(celdaValor);

                    datosHoja.AppendChild(filaFiltro);
                }
            }
            else
            {
                Row filaFiltro = new Row();
                filaFiltro.RowIndex = (UInt32)indiceFilaInicio;

                Cell celdaTexto = crearCelda(++indiceFilaInicio, 1, "Ninguno", indiceFormatoFiltro);

                filaFiltro.AppendChild(celdaTexto);

                datosHoja.AppendChild(filaFiltro);
            }

            indiceFilaInicio += 2;
        }

        /// <summary>
        /// Crea el titulo del informe
        /// </summary>
        private void crearTituloInforme()
        {
            Row filaTitulo = new Row();
            filaTitulo.RowIndex = (UInt32)indiceFilaInicio;

            UInt32Value indiceFuenteTitulo = crearFuente(hojaEstilo, "Calibri", 14, true, System.Drawing.ColorTranslator.FromHtml(Constantes.COLOR_GRIS_OSCURO));
            UInt32Value indiceFormatoTitulo = crearFormatoCelda(hojaEstilo, indiceFuenteTitulo, null, null, null);

            filaTitulo.AppendChild(crearCelda(indiceFilaInicio, 1, TituloInforme, indiceFormatoTitulo));
            datosHoja.AppendChild(filaTitulo);

            indiceFilaInicio += 2;
        }

        /// <summary>
        /// Crea la cabezera del informe
        /// </summary>
        private void crearCabezeraInforme()
        {
            Row filaCabezeraInforme = datosHoja.Elements<Row>().First();
            UInt32Value indiceFormatoCabezeraInforme = crearFormatoCelda(hojaEstilo, null, crearRelleno(hojaEstilo, System.Drawing.ColorTranslator.FromHtml(Constantes.COLOR_ARROW_SILVER)), null, null);
            for (int i = 1; i < Tabla.Columns.Count; i++)
            {
                filaCabezeraInforme.AppendChild(crearCelda(indiceFilaInicio, i + 1, String.Empty, indiceFormatoCabezeraInforme));
            }
            indiceFilaInicio++;

            Row filaSubCabezeraInforme = datosHoja.Elements<Row>().ElementAt(1);
            UInt32Value indiceFormatoSubCabezeraInforme = crearFormatoCelda(hojaEstilo, null, crearRelleno(hojaEstilo, System.Drawing.Color.Black), null, null);
            for (int i = 0; i < Tabla.Columns.Count; i++)
            {
                filaSubCabezeraInforme.AppendChild(crearCelda(indiceFilaInicio, i + 1, String.Empty, indiceFormatoSubCabezeraInforme));
            }
            indiceFilaInicio++;
        }

        /// <summary>
        /// Crea una fila de datos del fichero Excel a partir de una fila de un DataTable
        /// </summary>
        /// <param name="filaDatos">Fila de un DataTable</param>
        /// <param name="indiceFila">Índice de la fila de Excel</param>
        /// <returns>Una referencia a un objeto Row con los datos especificados</returns>
        private Row crearFilaDatos(DataRow filaDatos, int indiceFila)
        {
            Row fila = new Row { RowIndex = (UInt32)indiceFila };

            Nullable<uint> indiceEstilo = null;
            //double valorDoble;
            //int valorEntero;
            DateTime valorFecha;

            UInt32Value indiceFormatoCentrado = crearFormatoCelda(hojaEstilo, null, null, null, null, HorizontalAlignmentValues.Center);

            for (int i = 0; i < filaDatos.Table.Columns.Count; i++)
            {
                //Cell celda = crearCelda(indiceFila, i + 1, filaDatos[i], null);
                Cell celda;

                if (CamposCentrados != null && CamposCentrados.Count > 0)
                {
                    indiceEstilo = CamposCentrados.Contains(filaDatos.Table.Columns[i].ColumnName) ? (uint?)indiceFormatoCentrado : null; 
                }

                if (DateTime.TryParse(filaDatos[i].ToString(), out valorFecha))
                {
                    //celda = crearCelda(indiceFila, i + 1, valorFecha.ToOADate().ToString(), indiceEstilo);
                    celda = crearCelda(indiceFila, i + 1, valorFecha.ToShortDateString(), indiceEstilo);
                }
                //else if (int.TryParse(filaDatos[i].ToString(), out valorEntero))
                //{
                //    indiceEstilo = idEstiloNumero;
                //    celda = crearCelda(indiceFila, i + 1, valorEntero, indiceEstilo);
                //}
                //else if (Double.TryParse(filaDatos[i].ToString(), out valorDoble))
                //{
                //    indiceEstilo = idEstiloDoble;
                //    celda = crearCelda(indiceFila, i + 1, valorDoble, indiceEstilo);
                //}
                else
                {
                    celda = crearCelda(indiceFila, i + 1, filaDatos[i], indiceEstilo);
                }

                fila.AppendChild(celda);
                indiceEstilo = null;
            }

            return fila;
        }

        /// <summary>
        /// Crea una celda de texto para insertar en una hoja Excel
        /// </summary>
        /// <param name="indiceFila">Índice de la fila donde se creará la celda</param>
        /// <param name="indiceColumna">Índice de la columna donde se creará la celda</param>
        /// <param name="valor">El valor textual que contendrá la celda</param>
        /// <param name="indiceEstilo">El índice del formato de la celda</param>
        /// <returns>Una referencia a un objeto Cell con los atributos especificados</returns>
        private Cell crearCelda(int indiceFila, int indiceColumna, object valorCelda, Nullable<uint> indiceEstilo)
        {
            Cell celda = new Cell();

            celda.DataType = CellValues.InlineString;
            celda.CellReference = obtenerLetraColumna(indiceColumna) + indiceFila;

            //CellValue valor = new CellValue();
            //valor.Text = valorCelda.ToString();
            InlineString cadenaEnLinea = new InlineString();
            Text texto = new Text();

            texto.Text = valorCelda.ToString();
            cadenaEnLinea.AppendChild(texto);
            if (indiceEstilo.HasValue)
            {
                celda.StyleIndex = indiceEstilo.Value;
            }
            celda.AppendChild(cadenaEnLinea);

            return celda;
        }

        /// <summary>
        /// Obtiene el nombre de una columna Excel a partir de su índice
        /// </summary>
        /// <param name="indiceColumna">El índice de la columna</param>
        /// <returns>Una cadena tipo: "A", "AB", "XFD", etc..</returns>
        private string obtenerLetraColumna(int indiceColumna)
        {
            int dividendo = indiceColumna;
            string letraColumna = String.Empty;
            int modificador = 0;

            while (dividendo > 0)
            {
                modificador = (dividendo - 1) % 26;
                letraColumna = Convert.ToChar(65 + modificador).ToString() + letraColumna;
                dividendo = (int)((dividendo - modificador) / 26);
            }

            return letraColumna;
        }

        /// <summary>
        /// Añade un tipo de fuente a la hoja de estilo pasada como parámetro
        /// </summary>
        /// <param name="hojaEstilo">Hoja de estilo a la que se añade la fuente</param>
        /// <param name="nombreFuente">Nombre de la fuente</param>
        /// <param name="tamanoFuente">Tamaño de la fuente</param>
        /// <param name="esNegrita">Indica si la fuente está en negrita</param>
        /// <param name="colorFuente">Color de la fuente</param>
        /// <returns>El índice de la fuente recién creada en la hoja de estilo</returns>
        private UInt32Value crearFuente(Stylesheet hojaEstilo,
                                        string nombreFuente,
                                        Nullable<double> tamanoFuente,
                                        bool esNegrita,
                                        System.Drawing.Color colorFuente)
        {
            Font fuente = new Font();

            if (!string.IsNullOrEmpty(nombreFuente))
            {
                FontName nombre = new FontName() { Val = nombreFuente };
                fuente.Append(nombre);
            }

            if (tamanoFuente.HasValue)
            {
                FontSize tamano = new FontSize() { Val = tamanoFuente };
                fuente.Append(tamano);
            }

            if (esNegrita == true)
            {
                Bold negrita = new Bold();
                fuente.Append(negrita);
            }

            if (colorFuente != null)
            {
                Color color = new Color()
                {
                    Rgb = new HexBinaryValue()
                    {
                        Value = System.Drawing.ColorTranslator.ToHtml(
                        System.Drawing.Color.FromArgb(colorFuente.A,
                        colorFuente.R,
                        colorFuente.G,
                        colorFuente.B)).Replace("#", "")
                    }
                };
                fuente.Append(color);
            }

            hojaEstilo.Fonts.Append(fuente);

            return hojaEstilo.Fonts.Count++;
        }

        /// <summary>
        /// Añade un relleno a la hoja de estilo pasada como parámetro
        /// </summary>
        /// <param name="hojaEstilo">Hoja de estilo a la que se añade el relleno</param>
        /// <param name="colorRelleno">Color del relleno</param>
        /// <returns>El índice del relleno recién creado en la hoja de estilo</returns>
        private UInt32Value crearRelleno(Stylesheet hojaEstilo,
                                         System.Drawing.Color colorRelleno)
        {
            Fill relleno = new Fill(
                new PatternFill(
                    new ForegroundColor()
                    {
                        Rgb = new HexBinaryValue()
                        {
                            Value = System.Drawing.ColorTranslator.ToHtml(
                            System.Drawing.Color.FromArgb(colorRelleno.A,
                            colorRelleno.R,
                            colorRelleno.G,
                            colorRelleno.B)).Replace("#", "")
                        }
                    })
                {
                    PatternType = PatternValues.Solid
                }
            );
            hojaEstilo.Fills.Append(relleno);

            return hojaEstilo.Fills.Count++;
        }

        /// <summary>
        /// Añade un borde a la hoja de estilo pasada como parámetro
        /// </summary>
        /// <param name="hojaEstilo">Hoja de estilo a la que se añade el borde</param>
        /// <param name="colorBorde">Color del borde</param>
        /// <param name="tipoBorde">Tipo de borde</param>
        /// <param name="izquierdo">Borde izquierdo</param>
        /// <param name="derecho">Borde derecho</param>
        /// <param name="superior">Borde superior</param>
        /// <param name="inferior">Borde inferior</param>
        /// <returns></returns>
        private UInt32Value crearBorde(Stylesheet hojaEstilo,
                                       System.Drawing.Color colorBorde,
                                       BorderStyleValues tipoBorde = BorderStyleValues.Thin,
                                       bool izquierdo = false,
                                       bool derecho = false,
                                       bool superior = false,
                                       bool inferior = true)
        {
            Border borde = new Border();
            Color color = new Color()
            {
                Rgb = new HexBinaryValue()
                {
                    Value = System.Drawing.ColorTranslator.ToHtml(
                    System.Drawing.Color.FromArgb(colorBorde.A,
                    colorBorde.R,
                    colorBorde.G,
                    colorBorde.B)).Replace("#", "")
                }
            };

            if (izquierdo == true)
            {
                LeftBorder bordeIzquierdo = new LeftBorder() { Style = tipoBorde };
                bordeIzquierdo.Append(color);
                borde.Append(bordeIzquierdo);
            }

            if (derecho == true)
            {
                RightBorder bordeDerecho = new RightBorder() { Style = tipoBorde };
                bordeDerecho.Append(color);
                borde.Append(bordeDerecho);
            }

            if (superior == true)
            {
                TopBorder bordeSuperior = new TopBorder() { Style = tipoBorde };
                bordeSuperior.Append(color);
                borde.Append(bordeSuperior);
            }

            if (inferior == true)
            {
                BottomBorder bordeInferior = new BottomBorder() { Style = tipoBorde };
                bordeInferior.Append(color);
                borde.Append(bordeInferior);
            }

            hojaEstilo.Borders.Append(borde);

            return hojaEstilo.Borders.Count++;
        }

        /// <summary>
        /// Añade un formato de celda a la hoja de estilo pasada como parámetro
        /// </summary>
        /// <param name="hojaEstilo">Hoja de estilo a la que se añade el relleno</param>
        /// <param name="indiceFuente">Índice de la fuente en la hoja de estilo</param>
        /// <param name="indiceRelleno">Índice del relleno en la hoja de estilo</param>
        /// <param name="idFormatoNumero">Identificador del formato de número</param>
        /// <returns>El índice del formato recién creado en la hoja de estilo</returns>
        private UInt32Value crearFormatoCelda(Stylesheet hojaEstilo,
                                              UInt32Value indiceFuente,
                                              UInt32Value indiceRelleno,
                                              UInt32Value indiceBorde,
                                              UInt32Value idFormatoNumero,
                                              HorizontalAlignmentValues alineacionHorizontal = HorizontalAlignmentValues.Left,
                                              VerticalAlignmentValues alineacionVertical = VerticalAlignmentValues.Bottom)
        {
            CellFormat formatoCelda = new CellFormat();

            if (indiceFuente != null)
                formatoCelda.FontId = indiceFuente;

            if (indiceRelleno != null)
                formatoCelda.FillId = indiceRelleno;

            if (indiceBorde != null)
                formatoCelda.BorderId = indiceBorde;

            if (idFormatoNumero != null)
            {
                formatoCelda.NumberFormatId = idFormatoNumero;
                formatoCelda.ApplyNumberFormat = BooleanValue.FromBoolean(true);
            }

            formatoCelda.Alignment = new Alignment()
            {
                Horizontal = alineacionHorizontal,
                Vertical = alineacionVertical
            };

            hojaEstilo.CellFormats.Append(formatoCelda);

            return hojaEstilo.CellFormats.Count++;
        }

        /// <summary>
        /// Convierte el fichero Excel en una cadena de bytes
        /// </summary>
        /// <returns>El fichero Excel en forma de cadena de bytes</returns>
        private Byte[] convertirABytes()
        {
            Byte[] bytes;
            using (FileStream fileStream = File.OpenRead(rutaFichero))
            {
                bytes = new byte[(int)fileStream.Length];
                fileStream.Read(bytes, 0, (int)fileStream.Length);
            }

            // Borramos el fichero temporal
            File.Delete(rutaFichero);

            return bytes;
        }
    }
}
