﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class NuevoMedio:Base
    {
        private Dal.NuevoMedio dal;
        private DataTable dtDatosTiposDeMedios = null;
 
        public NuevoMedio(ref MantMensajes mantMensajes)
        {
            dal = new Dal.NuevoMedio(ref mantMensajes);
           
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la inserción
        /// </summary>
        /// <param name="medio">Medio a insertar</param>
        /// <returns></returns>
        public int guardarMedioNuevo(Medio medio)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                if (!existeIDModeloTipoMedio(medio))
                {
                    // Accedemos a la capa de datos
                    intGuardar = dal.insertarMedio(medio);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha guardado correctamente
                        if (intGuardar == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.GUARDADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);

                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_GUARDAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    // Si ha ocurrido algún problema
                    MensajesEntidad mensaje = new MensajesEntidad();
                    mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.IDMEDIO_EXISTE), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                    // Agregamos el mensaje a la lista
                    dal.Manejador.agregar(mensaje);
                }                          
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Comprobamos si ya existe un medio con ID asociado al tipo de medio seleccionado
        /// </summary>
        /// <param name="medio">Datos del medio</param>
        /// <returns>true si existe un medio con ID asociado al tipo de medio seleccionado</returns>
        private bool existeIDModeloTipoMedio(Medio medio)
        {
            bool result = false;

            // Accedemos a la capa de datos
            result = dal.existeIDModeloTipoMedio(medio);

            return result;
        }

        /// <summary>
        /// LLamada a la capa de datos para obtener los datos asociados a los tipos de medios
        /// Si tiene marca y modelo, si tiene extensión y si es entregable
        /// </summary>
        /// <returns></returns>
        public void obtenerDatosTiposDeMedios()
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();               
            try
            {
                // Accedemos a la capa de datos
                dtDatosTiposDeMedios = dal.obtenerDatosTiposDeMedios();
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            //return dsDatosTiposDeMedios;
        }

        /// <summary>
        /// comprobamos si el tipo de medio seleccionado tiene marca y modelo
        /// </summary>
        /// <returns></returns>
        public bool tieneMarcaModelo(int oidTipoMedio)
        {
            bool result = false;

            DataRow[] fila = dtDatosTiposDeMedios.Select(Constantes.OIDTIPOMEDIO + " = " + oidTipoMedio);

            result = Convert.ToBoolean(string.IsNullOrEmpty(fila[0][Constantes.MARCAMODELO].ToString()) ? "false" : fila[0][Constantes.MARCAMODELO].ToString());

            return result;
        }

        /// <summary>
        /// comprobamos si el tipo de medio seleccionado tiene extension
        /// </summary>
        /// <returns></returns>
        public bool tieneExtension(int oidTipoMedio)
        {
            bool result = false;

            DataRow[] fila = dtDatosTiposDeMedios.Select(Constantes.OIDTIPOMEDIO + " = " + oidTipoMedio);

            result = Convert.ToBoolean(string.IsNullOrEmpty(fila[0][Constantes.EXTENSION].ToString()) ? "false" : fila[0][Constantes.EXTENSION].ToString());

            return result;
        }

        /// <summary>
        /// comprobamos si el tipo de medio seleccionado es entregable
        /// </summary>
        /// <returns></returns>
        public bool esEntregable(int oidTipoMedio)
        {
            bool result = false;

            DataRow[] fila = dtDatosTiposDeMedios.Select(Constantes.OIDTIPOMEDIO + " = " + oidTipoMedio);

            result = Convert.ToBoolean(string.IsNullOrEmpty(fila[0][Constantes.ENTREGABLE].ToString()) ? "false" : fila[0][Constantes.ENTREGABLE].ToString());

            return result;
        }

        /// <summary>
        /// /// Recuperamos la lista de modelos asociados a la marca
        /// </summary>
        /// <param name="oidMarca">Marca para filtrar los modelos</param>
        /// <returns>lista de modelos asociados a la marca</returns>
        public List<Modelo> obtenerListaModelos(int oidMarca)
        {
            // Lista de modelos
            List<Modelo> modelo = new List<Modelo>();
            // Creamos el dataSet
            DataSet listaModelo = new DataSet();

            // Limpiamos los mensajes
            dal.Manejador.limpiar();

            try
            {
                // Llamada al método que accede a la base de datos
                listaModelo = dal.obtenerListaModelos(oidMarca);

                // Si no tenemos errores procedemos
                if (!dal.Manejador.existenMensajes())
                {

                    if (listaModelo.Tables[0].Rows.Count > 0)
                    {   // Recorremos las filas recuperadas
                        for (int i = 0; i < listaModelo.Tables[0].Rows.Count; i++)
                        {
                            // Añadimos las marcas a la lista
                            modelo.Add(new Modelo(oidModelo: Convert.ToInt16(listaModelo.Tables[0].Rows[i][1]), nombre: listaModelo.Tables[0].Rows[i][0].ToString(),descripcion:"", fecBaja: "", oidMarca: -1));
                        }
                    }
                }

            }
            catch (Exception err)
            {
                // Agregamos las excepciones
                dal.Manejador.agregar(err);
            }

            // Devolvemos la lista de departamentos
            return modelo;
        }

        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }

            return mensajes;
        }
    }
}
