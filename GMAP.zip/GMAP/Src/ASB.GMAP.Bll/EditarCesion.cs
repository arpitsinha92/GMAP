﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ASB.GMAP.Dal;
using ASB.GMAP.Ent;
using MB.Framework.ManejadorMensajes;
using MB.Framework.Log;
using System.Data;

namespace ASB.GMAP.Bll
{
    public class EditarCesion:Base
    {
        private Dal.EditarCesion dal;
        public EditarCesion(ref MantMensajes mantMensajes)
        {
            dal = new Dal.EditarCesion(ref mantMensajes);
           
        }

        /// <summary>
        /// Método mediante el cual se hacen las comprobaciones pertinentes 
        /// y se llama a la capa de datos para realizar la actualización
        /// </summary>
        /// <param name="cesion">Cesion a actualizar</param>
        /// <returns></returns>
        public int actualizarCesion(Cesion cesion, string opcionGuardar)
        {
            int intGuardar = 0;
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            try
            {
                //Si opcionGuardar es 1 entonces tendremos que guardar la cesión de dicho medio asociada a un empleado
                if (opcionGuardar.Equals("1"))
                {
                    // Accedemos a la capa de datos
                    intGuardar = dal.actualizarCesionEmpleado(cesion);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (intGuardar == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
                else
                {
                    //Si opcionGuardar es 2 entonces tendremos que guardar la cesión del dicho medio asociada a un departamento
                    // Accedemos a la capa de datos
                    intGuardar = dal.actualizarCesionDepartamento(cesion);
                    // Si no existen mensajes continuamos
                    if (!dal.Manejador.existenMensajes())
                    {   // Si se ha actualizado correctamente
                        if (intGuardar == 1)
                        {
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ACTUALIZADO_CORRECTO_DATOS), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                        else
                        {   // Si ha ocurrido algún problema
                            MensajesEntidad mensaje = new MensajesEntidad();
                            mensaje = MB.Framework.ManejadorMensajes.Mensajes.obtenerMensaje(Convert.ToInt32(MB.Framework.ManejadorMensajes.Mensajes.Mensaje.ERROR_ACTUALIZAR), MB.Framework.ManejadorMensajes.Mensajes.FicherosMensajes);
                            // Agregamos el mensaje a la lista
                            dal.Manejador.agregar(mensaje);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }

            return intGuardar;
        }

        /// <summary>
        /// Método para obtener los datos de la cesión
        /// </summary>
        /// <param name="oidMedio">Identificador le medio cedido</param>
        /// <param name="strNumEmpleado">Empleado al que se le ha cedido el medio</param>
        /// <param name="id_orgunit">Departamento al que se le ha cedido el medio</param>
        /// <returns></returns>
        //public Cesion buscarCesion(int oidMedio, string strNumEmpleado, string id_orgunit)
        //{
        //    // Limpiamos los mensajes
        //    dal.Manejador.limpiar();
        //    DataTable dtBusquedaCesion = null;
        //    Cesion cesion = null;
            
        //    try
        //    {   
        //        //Determinamos si la cesión ha sido a un empleado o a un departamento
        //        if (strNumEmpleado.Equals(""))
        //        {
        //            // Accedemos a la capa de datos
        //            dtBusquedaCesion = dal.buscarCesionDepartamento(oidMedio, id_orgunit);
                    
        //            cesion = new Cesion(Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidcesiondepartamento"].ToString())
        //                                ,id_orgunit,oidMedio
        //                                ,dtBusquedaCesion.Rows[0]["dat_fecini"].ToString()
        //                                ,dtBusquedaCesion.Rows[0]["dat_fecfin"].ToString()
        //                                ,dtBusquedaCesion.Rows[0]["STRNUMEMP"].ToString()
        //                                ,dtBusquedaCesion.Rows[0]["nombreEmpleado"].ToString()
        //                                ,dtBusquedaCesion.Rows[0]["dat_fecfinprorroga"].ToString()
        //                                ,dtBusquedaCesion.Rows[0]["var_comentarios"].ToString());
        //        }
        //        else
        //        {
        //            // Accedemos a la capa de datos
        //            dtBusquedaCesion = dal.buscarCesionEmpleado(oidMedio, strNumEmpleado);
        //            cesion = new Cesion(Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidcesionempleado"].ToString())
        //                                , id_orgunit, oidMedio
        //                                , dtBusquedaCesion.Rows[0]["dat_fecini"].ToString()
        //                                , dtBusquedaCesion.Rows[0]["dat_fecfin"].ToString()
        //                                , dtBusquedaCesion.Rows[0]["STRNUMEMP"].ToString()
        //                                , dtBusquedaCesion.Rows[0]["nombreEmpleado"].ToString()
        //                                , dtBusquedaCesion.Rows[0]["dat_fecfinprorroga"].ToString()
        //                                , dtBusquedaCesion.Rows[0]["var_comentarios"].ToString());
        //        }
        //    }
        //    catch (Exception err)
        //    {
        //        dal.Manejador.agregar(err);
        //    }
        //    return cesion;
        //}

        /// <summary>
        /// Método para obtener los datos de la cesión
        /// </summary>
        /// <param name="oidCesion">Identificador de la cesión</param>
        /// <param name="strNumEmpleado">Empleado al que se le ha cedido el medio</param>
        /// <param name="id_orgunit">Departamento al que se le ha cedido el medio</param>
        /// <returns></returns>
        public Cesion buscarCesion(int oidCesion, string strNumEmpleado, string id_orgunit)
        {
            // Limpiamos los mensajes
            dal.Manejador.limpiar();
            DataTable dtBusquedaCesion = null;
            Cesion cesion = null;

            try
            {
                //Determinamos si la cesión ha sido a un empleado o a un departamento
                if (strNumEmpleado.Equals(""))
                {
                    // Accedemos a la capa de datos
                    dtBusquedaCesion = dal.buscarCesionDepartamento(oidCesion);

                    cesion = new Cesion(Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidcesiondepartamento"].ToString())
                                        , id_orgunit, Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidMedio"].ToString())
                                        , dtBusquedaCesion.Rows[0]["dat_fecini"].ToString()
                                        , dtBusquedaCesion.Rows[0]["dat_fecfin"].ToString()
                                        , dtBusquedaCesion.Rows[0]["STRNUMEMPLEADO"].ToString()
                                        , dtBusquedaCesion.Rows[0]["nombreEmpleado"].ToString()
                                        , dtBusquedaCesion.Rows[0]["dat_fecfinprorroga"].ToString()
                                        , dtBusquedaCesion.Rows[0]["var_comentarios"].ToString());
                }
                else
                {
                    // Accedemos a la capa de datos
                    dtBusquedaCesion = dal.buscarCesionEmpleado(oidCesion);
                    cesion = new Cesion(Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidcesionempleado"].ToString())
                                        , id_orgunit, Convert.ToInt16(dtBusquedaCesion.Rows[0]["int_oidMedio"].ToString())
                                        , dtBusquedaCesion.Rows[0]["dat_fecini"].ToString()
                                        , dtBusquedaCesion.Rows[0]["dat_fecfin"].ToString()
                                        , dtBusquedaCesion.Rows[0]["STRNUMEMPLEADO"].ToString()
                                        , dtBusquedaCesion.Rows[0]["nombreEmpleado"].ToString()
                                        , dtBusquedaCesion.Rows[0]["dat_fecfinprorroga"].ToString()
                                        , dtBusquedaCesion.Rows[0]["var_comentarios"].ToString());
                }
            }
            catch (Exception err)
            {
                dal.Manejador.agregar(err);
            }
            return cesion;
        }


        /// <summary>
        /// Método para mostrar los mensajes de error.
        /// </summary>
        /// <param name="hayMensajes">True si hay mensajes de error y false si no hay mensajes.</param>
        /// <returns>Entidad con los mensajes.</returns>
        public MensajesEntidad mostrarMensajes(ref bool hayMensajes)
        {
            MensajesEntidad mensajes = new MensajesEntidad();
            string ex = null;

            if (dal.Manejador.existenMensajes())
            {
                hayMensajes = true;
                mensajes.Mensaje = dal.Manejador.Mensajes[0].Mensaje;
                mensajes.TipoMensaje = dal.Manejador.Mensajes[0].TipoMensaje;
                // Si se ha generado la excepción la guardamos
                if (dal.Manejador.Mensajes[0].Excepcion != null)
                {
                    ex = dal.Manejador.Mensajes[0].Excepcion.Message;
                    Elmah.ErrorSignal.FromCurrentContext().Raise(dal.Manejador.Mensajes[0].Excepcion);
                }
                else
                {
                    // Si no se ha producido una excepción, guardaremos el mensaje 
                    ex = mensajes.Mensaje.ToString();
                }
                // Escribiremos en el log las excepciones o mensajes que se han producido
                Log.escribirLog(ex, mensajes.TipoMensaje.ToString());
            }
            return mensajes;
        }                
    }
}
