﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASB.GMAP.Bll
{
    public class Constantes
    {
        // Permisos
        public const string PERMISOS_TOTAL = "T";
        public const string PERMISOS_ESCRITURA = "E";
        public const string PERMISOS_LECTURA = "L";
        public const string SIN_PERMISOS = "N";

        // Columnas registros 
        public const string REGISTRO_ESCRITURA = "blnescritura";
        public const string REGISTRO_LECTURA = "blnLectura";

        //Campos de tabla
        public const string OIDTIPOMEDIO = "int_oidtipomedio";
        public const string OIDMODELO = "int_oidModelo";
        public const string VAR_NOMBREMODELOENTERO = "var_nombreModeloEntero";
        public const string MARCAMODELO = "bit_marcamodelo";
        public const string EXTENSION = "bit_exttfno";
        public const string ENTREGABLE = "bit_entregable";

        // Constantes de la clase de Utilidades
        public const string EXTENSION_EXCEL = ".xlsx";
        public const string EXTENSION_WORD = ".docx";
        public const int INDICE_FILA_INICIO_EXCEL = 1;
        public const string COLOR_ARROW_SILVER = "#676D75";
        public const string COLOR_GRIS_OSCURO = "#808080";

    }
}
